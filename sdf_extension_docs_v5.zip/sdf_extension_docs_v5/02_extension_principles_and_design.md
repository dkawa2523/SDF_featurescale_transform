# 02. 拡張方針・コア設計・仕様案（v3 詳細版）

本章では、既存 `wafergeo` を **汎用的・単純・利用しやすい共通基盤** として強化するための  
拡張後アーキテクチャを **実装可能な粒度** で定義します。

狙いは 3 つです。

1. 実装者が「どのクラスを作るか」を迷わないこと  
2. レビューアが「責務分離が正しいか」を確認しやすいこと  
3. 第三者が「なぜこの設計なのか」を追えること  

---

## 1. この章で答える問い

この章では、次の問いに答えます。

- canonical geometry は何か
- TSDF / UDF / profile / contour は canonical か view か
- core に残す抽象は何個か
- 各抽象は何を持ち、何を持たないか
- signed / unsigned の意味はどこで固定するか
- artifact と spec の互換性をどう維持するか
- 既存 repo を壊さずにどこまで段階移行できるか

---

## 2. 設計の前提と制約

### 2.1 扱いたい対象
対象は、主に以下です。

- エッチング後の 3D 形状
- 成膜後の 3D 形状
- mesh / label volume / SEM contour など複数表現
- simulation 結果と SEM 実測の比較
- surrogate 学習用の教師 package 生成
- 外部 optimizer から呼び出される objective evaluator

### 2.2 core に入れないもの
次は core の責務にしません。

- 学習 loop 本体
- optimizer 本体
- SEM image intensity simulator
- process-specific observer class 群
- 形状ごとに分岐する `if trench: ... elif via: ...`
- 重い registration / elastic warping
- exploratory な neural SDF 学習器の内蔵

### 2.3 重要な設計原則
本提案では次を守ります。

1. **canonical は raw signed distance**
2. **TSDF は view**
3. **open contour には unsigned distance を認める**
4. **observer kind は少なく、observer bundle で使い勝手を上げる**
5. **metric は component 化し、最終スコアはそれらの合成とする**
6. **process-specific な意味は geometry function に吸収する**
7. **未実装 option を spec に見せない**

---

## 3. なぜ raw SDF を canonical にするのか

既存 repo では、TSDF の存在感が強く、実装上も `TSDFVolume` が中心に見えます。  
しかし基盤設計としては、canonical を TSDF に置くより **raw SDF** に置いた方が有利です。

### 3.1 raw SDF を canonical にする利点
- 1 つの `mu` に縛られない
- zero level set の意味が明確
- normal / curvature / interface distance に自然に接続できる
- TSDF / tanh / logsigned など複数 view を後から作れる
- downstream 学習器が変わっても teacher を再作成しやすい

### 3.2 TSDF を canonical にしない理由
TSDF は便利ですが、あくまで **帯域制限された view** です。

- `mu` を変えると値の意味が変わる
- 飽和領域では遠方情報が落ちる
- narrow band の外はほぼ同じ値になりやすい
- 角部 detail と大域形状を単一 `mu` で両立しにくい

したがって、raw SDF を保持しつつ、TSDF は view として必要な数だけ派生する方が安全です。

---

## 4. core に残す最小抽象

本提案で core に残す抽象は **4 つ** です。

1. `Field3D`
2. `Obs2D` / `ObserverBundle`
3. `MetricBundle`
4. `DatasetPackageV2`

この 4 つで geometry core を閉じます。

```mermaid
flowchart LR
    A[Ingest / Label / Mesh / SEM contour]
    B[Field3D\nraw SDF canonical]
    C[DistanceViews\nTSDF/UDF/tanh/logsigned]
    D[ObserverBundle]
    E[Obs2D]
    F[MetricBundle]
    G[DatasetPackageV2]
    H[Assimilation objective]
    I[Surrogate export]

    A --> B
    B --> C
    B --> D
    C --> D
    D --> E
    E --> F
    F --> H
    B --> G
    C --> G
    E --> G
    G --> I
```

### 4.1 直観的な理解
- `Field3D`: 3D geometry の正準表現
- `Obs2D`: 比較に使う 2D 観測表現
- `MetricBundle`: 何をどの単位で比較するか
- `DatasetPackageV2`: 学習や解析へ渡す最終パッケージ

---

## 5. 型設計の全体像

### 5.1 GridMeta
すべての geometry / observation は grid metadata を明示的に持ちます。  
shape と spacing の暗黙依存を避けるためです。

```python
from dataclasses import dataclass
from typing import Literal

@dataclass(frozen=True)
class GridMeta:
    shape_zyx: tuple[int, int, int]
    spacing_nm_zyx: tuple[float, float, float]
    origin_nm_zyx: tuple[float, float, float]
    axis_order: Literal["zyx"] = "zyx"
    frame: Literal["simulation", "measurement", "canonical"] = "canonical"
```

### 5.2 RoleSpec
材料 ID をそのまま core に引き回すと、プロセスごとの意味が混ざります。  
そのため、upstream で raw material id を **canonical role** に写像します。

```python
@dataclass(frozen=True)
class RoleSpec:
    raw_material_to_role: dict[int, int]
    role_id_to_name: dict[int, str]
    void_role_id: int
```

推奨する role 名の例:

- `void`
- `target`
- `mask`
- `liner_or_film`
- `fill_or_other`

この role 空間は **小さく固定的** であることが重要です。  
工程固有材料名の解釈は upstream に閉じ込めます。

### 5.3 Field3D
`Field3D` は canonical geometry の本体です。

```python
from dataclasses import dataclass, field
from typing import Any

@dataclass
class Field3D:
    grid: GridMeta
    roles: RoleSpec

    # shape: [R, Z, Y, X], float32
    sdf_nm: "np.ndarray"

    # optional, same shape as sdf_nm
    udf_nm: "np.ndarray | None" = None

    # optional scalar fields, shape: [Z, Y, X] or [R, Z, Y, X]
    scalar_fields: dict[str, "np.ndarray"] = field(default_factory=dict)

    # optional interface-specific fields
    interface_fields: dict[str, "np.ndarray"] = field(default_factory=dict)

    # mask of valid/support voxels, shape [Z, Y, X], bool
    support_mask: "np.ndarray | None" = None

    # QA summaries
    qa: dict[str, Any] = field(default_factory=dict)

    # provenance
    meta: dict[str, Any] = field(default_factory=dict)
```

#### `Field3D` が持つべき意味
- `sdf_nm[r, z, y, x]` は role `r` に対する signed distance
- 各 role の zero level set がその境界候補になる
- `scalar_fields` は geometry から generic に派生した補助量
- `interface_fields` は必要時のみ使う optional 拡張
- `qa` は数値品質や coverage 情報を持つ

#### `Field3D` が持たないもの
- 学習用 augmentation
- loss weight
- observer specific な中間 mask
- optimizer state
- process-specific 解釈語

### 5.4 DistanceViews
`Field3D` の raw SDF から、学習しやすい view を作る層です。

```python
@dataclass
class DistanceViews:
    tsdf_views: dict[str, "np.ndarray"]  # e.g. small/mid/large
    tanh_views: dict[str, "np.ndarray"]
    logsigned_views: dict[str, tuple["np.ndarray", "np.ndarray"]]
    meta: dict[str, Any]
```

この層は **派生表現専用** であり、canonical ではありません。

### 5.5 Obs2D
比較や SEM 同化で使う 2D の観測表現です。

```python
@dataclass
class Obs2D:
    grid2d_shape_yx: tuple[int, int]
    spacing_nm_yx: tuple[float, float]
    origin_nm_yx: tuple[float, float]
    axis_order: str  # usually "yx"

    # shape [Y, X], float32
    distance2d_nm: "np.ndarray"

    # optional
    mask2d: "np.ndarray | None" = None
    contours_xy_nm: list["np.ndarray"] | None = None
    confidence: "np.ndarray | None" = None

    # alignment applied to this observation
    transform: dict[str, Any] | None = None

    debug_maps: dict[str, "np.ndarray"] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)
```

#### `distance2d_nm` を中心にする理由
`mask2d` や `contour` は補助的には有用ですが、  
比較の中心は距離場に寄せた方が一貫性が高いです。

- signed 比較ができる
- unsigned 比較も同じ API で扱える
- smoothing や interpolation を自然に扱える
- contour と mask の間をまたいで共通化できる

### 5.6 ObserverBundle
複数 observer の結果を一括で保持します。

```python
@dataclass
class ObserverBundle:
    topdown_exposed: Obs2D | None = None
    center_slice: Obs2D | None = None
    orthogonal_slice: Obs2D | None = None
    extra_slices: dict[str, Obs2D] = field(default_factory=dict)

    profiles: dict[str, "ProfileBundle"] = field(default_factory=dict)
    corners: dict[str, "CornerBundle"] = field(default_factory=dict)

    qa: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)
```

**重要:** observer kind は増やしすぎません。  
core に持つのは `topdown_exposed` と `slice` 系だけです。  
必要な組み合わせは helper が bundle 化します。

### 5.7 MetricBundle
最終スコアを 1 個の loss に潰す前に、component を保持します。

```python
@dataclass
class MetricComponent:
    name: str
    value: float
    unit: str
    support: dict[str, float]
    diagnostics: dict[str, Any] = field(default_factory=dict)

@dataclass
class MetricBundle:
    field: dict[str, MetricComponent] = field(default_factory=dict)
    curve: dict[str, MetricComponent] = field(default_factory=dict)
    profile: dict[str, MetricComponent] = field(default_factory=dict)
    corner: dict[str, MetricComponent] = field(default_factory=dict)
    topology: dict[str, MetricComponent] = field(default_factory=dict)
    total: MetricComponent | None = None
    meta: dict[str, Any] = field(default_factory=dict)
```

### 5.8 DatasetPackageV2
サロゲートや解析へ渡すための export 形式です。

```python
@dataclass
class DatasetPackageV2:
    field_path: str
    distance_views_path: str | None
    observer_bundle_path: str | None
    metric_targets_path: str | None
    mesh_path: str | None
    query_samples_path: str | None
    profile_table_path: str | None
    meta_path: str
```

---

## 6. canonical / view / derived の境界

設計が複雑になる最大要因は、**どれが主役でどれが派生かが曖昧なこと** です。  
本提案では次のように固定します。

| 種別 | 含まれるもの | 役割 |
|---|---|---|
| canonical | raw SDF (`Field3D.sdf_nm`) | もっとも意味が安定した geometry 本体 |
| derived-but-core | `scalar_fields`, `support_mask`, `qa` | canonical から一貫して導ける補助情報 |
| view | TSDF, tanh-distance, logsigned-distance, UDF | downstream の都合で作る表現 |
| observation | `Obs2D`, contour, confidence | comparison / assimilation 用の表現 |
| metric | field / curve / profile / corner | objective の構成要素 |
| export | mesh, query samples, npz/json | 外部利用のためのパッケージ |

この境界を文書で固定しておくと、設計レビューがかなり楽になります。

---

## 7. signed / unsigned の意味をどこで固定するか

### 7.1 signed distance の意味
signed distance は、必ず role に対する inside/outside を前提にします。

- inside: 負
- boundary: 0
- outside: 正

これは `Field3D` で固定します。

### 7.2 unsigned distance の意味
unsigned distance は inside/outside を持ちません。  
これは以下のケースで使います。

- open contour の SEM
- 部分観測しかない観測輪郭
- closed mask に無理やり変換したくない場合

unsigned distance は `Obs2D.distance2d_nm` にも持たせられますが、  
`meta["distance_semantics"]` で必ず `signed` / `unsigned` を明示します。

### 7.3 混同を防ぐルール
- `Field3D.sdf_nm` は signed only
- `Field3D.udf_nm` は unsigned only
- `Obs2D.distance2d_nm` は signed または unsigned のどちらでもよい
- ただし semantics を metadata に必須保存する
- metric 側は signed/unsigned の混在比較を許さない

---

## 8. observer kind を増やしすぎない方針

「etch 用 observer」「deposition 用 observer」「via 用 observer」を増やすと、  
一見便利に見えて、すぐに保守不能になります。

そこで core では observer kind を以下に限定します。

1. `topdown_exposed`
2. `slice`

必要な実用性は **bundle helper** と **profile/corner extractor** で出します。

```mermaid
flowchart TD
    A[Field3D] --> B[topdown_exposed]
    A --> C[slice]
    B --> D[Obs2D]
    C --> E[Obs2D]
    E --> F[profile extractor]
    E --> G[corner extractor]
    D --> H[ObserverBundle]
    E --> H
    F --> H
    G --> H
```

### なぜこれで十分か
多くの形状差は、最終的に次へ落ちます。

- 上面の見え方
- 断面の形
- 深さ方向 profile
- 角部 / 底部 / 入口部の局所差

これらは `topdown_exposed + slice + profile + corner` で表現できます。

---

## 9. scalar field の設計方針

`scalar_fields` は process-specific にはしません。  
すべて generic geometry quantity として定義します。

推奨する first-class scalar field:

| 名前 | shape | 意味 |
|---|---|---|
| `depth_from_top_nm` | `[Z,Y,X]` | top surface からの深さ |
| `top_height_nm` | `[Y,X]` または `[Z,Y,X]`派生 | topdown で見える最上位高さ |
| `local_gap_nm` | `[Z,Y,X]` | 向かい合う面までの局所距離 |
| `local_thickness_nm` | `[Z,Y,X]` | 一定定義に基づく局所厚み |
| `exposed_role_id` | `[Y,X]` 相当 | top から最初に見える role |
| `distance_to_sidewall_nm` | `[Z,Y,X]` | 局所 sidewall までの距離 |

### なぜ process-specific 名を避けるのか
たとえば `microtrench_depth` は etch 用語ですが、  
core ではこれは `corner + local_gap + curvature` の組み合わせとして扱う方が汎用的です。

---

## 10. artifact 設計

artifact は「後から見返しても何を計算したかが分かる」ことが重要です。

### 10.1 推奨 artifact tree
```text
artifacts/
  2026-04-05_run001/
    spec.yaml
    effective_spec.yaml
    manifest.json

    field/
      field3d.npz
      field3d_meta.json
      qa_field.json

    views/
      tsdf_small.npz
      tsdf_mid.npz
      tsdf_large.npz
      views_meta.json

    observe/
      topdown_exposed.npz
      center_slice.npz
      orthogonal_slice.npz
      profile_width.csv
      profile_wall_angle.csv
      corner_summary.json
      qa_observe.json

    metrics/
      metric_bundle.json
      field_component.csv
      profile_component.csv
      corner_component.csv

    export/
      surrogate_manifest.json
      query_samples.parquet
      mesh_surface.ply
```

### 10.2 `effective_spec` が重要な理由
spec に option が書かれていても、backend や mode によって実際には無効なことがあります。  
それを防ぐため、**解釈後に確定した spec** を `effective_spec.yaml` として保存します。

このファイルがないと、「設定したつもり」と「実際に動いた設定」がズレやすくなります。

---

## 11. spec versioning と互換方針

### 11.1 versioning ルール
- major: artifact 互換を壊す
- minor: 後方互換を保った機能追加
- patch: バグ修正や metadata 追加

### 11.2 互換方針
- 既存 `TSDFVolume` API は **legacy shim** として残す
- 新実装は `Field3D` を canonical にする
- export 側で旧形式も生成可能にする
- 非対応 option は silent ignore せず fail-fast にする

---

## 12. validation 設計

本基盤では validation をかなり重視します。  
なぜなら、SEM 比較や surrogate export では silent mismatch が最も危険だからです。

### 12.1 入力 validation
- spacing が有限かつ正
- shape と array 次元が一致しているか
- role mapping に void が含まれているか
- binary mask の値域が妥当か
- contour が空でないか
- point 列が nan を含まないか

### 12.2 field validation
- `sdf_nm.shape == (R,Z,Y,X)`
- `support_mask.shape == (Z,Y,X)` if present
- finite ratio > threshold
- narrow band 内 gradient の統計が異常でない
- role 間で明らかな矛盾がない

### 12.3 observation validation
- `distance2d_nm` の semantics が明示されている
- alignment 後 grid が metadata に反映されている
- contour と mask がある場合、互いに大きく矛盾しない
- confidence の shape が一致する

### 12.4 metric validation
- signed と unsigned を混ぜていない
- support intersection が一定以上ある
- profile 有効点率が一定以上ある
- corner 点が過度に欠損していない

---

## 13. なぜこの設計が半導体形状に向くのか

半導体加工形状では、重要な差は必ずしも面積差や CD 差だけではありません。  
現場で問題になるのはむしろ次です。

- 側壁のわずかな bowing
- 入口の necking / overhang
- 底部の rounding や microtrench
- bottom / sidewall / top の厚み差
- pinch-off 前後の closure
- open contour SEM の形状解釈

このため、3D canonical + 2D observation + profile/corner metrics の三層分離が有効です。

### 13.1 例: etch
etch の bowing は `width(z)` と `wall_angle(z)` に現れます。  
bottom rounding は `curvature(z)` と corner descriptor に現れます。  
microtrench は bottom 近傍の `gap/curvature` 変化に現れます。

### 13.2 例: deposition
conformality は `thickness(z)` に現れます。  
入口閉塞は `gap(z)` や top corner に現れます。  
seam/void は optional topology と `gap(z)` のゼロ交差で追えます。

つまり core に必要なのは process 名ではなく、  
**geometry function とその観測・比較基盤** です。

---

## 14. 何をやらないかを明記する

設計をシンプルに保つには、「何をしないか」を明記することが重要です。

### 14.1 core でやらないこと
- `EtchObserver`, `DepositionObserver` のような class を作らない
- `MicrotrenchLoss`, `PinchOffLoss` のような process-specific loss を作らない
- spline-heavy / optimization-heavy な registration を入れない
- neural SDF 学習器を core に持ち込まない

### 14.2 代わりにやること
- geometry function を generic にする
- optional features は helper / plugin / export 側へ逃がす
- Field / Obs / Metric / Export の 4 層で閉じる

---

## 15. 実装順の原則

設計は大きいですが、実装は段階導入できます。

```mermaid
flowchart LR
    A[Phase 0\nSpec整理] --> B[Phase 1\nField3D導入]
    B --> C[Phase 2\nObs2D/SEM unsigned]
    C --> D[Phase 3\nProfile/Corner/MetricBundle]
    D --> E[Phase 4\nAssimilation/Surrogate移行]
    E --> F[Phase 5\nOptional backend/future hooks]
```

### 15.1 先にやるべきこと
- fail-fast validation
- `effective_spec`
- `Field3D`
- raw SDF canonical
- 3-scale TSDF views
- `Obs2D.distance2d_nm` 中心設計

### 15.2 後回しでよいこと
- optional ITK backend
- optional CuPy backend
- interface field の fully generic 化
- sparse/adaptive storage

---

## 16. 本章の結論

v3 で最も重要なのは、次の 1 行に要約できます。

> **「geometry の canonical を raw SDF に固定し、その上に minimal な observer と解釈可能な metric を積む」**

これにより、

- implementation しやすい
- review しやすい
- downstream が増えても壊れにくい
- semiconductor 固有の重要差が見える

という、基盤として本当に重要な性質を同時に満たせます。

次章では、この設計を支える具体手法を  
**「なぜその手法なのか」「どの欠点を補うのか」** まで掘り下げて説明します。
