# v5 addendum

この addendum は、v4 までの設計 docs に対して、v5 で追加した以下を要約します。

- 実コード差分のスケルトン一式
- repo 内 knowledge base として使う短い docs tree
- 短い root AGENTS + nested AGENTS
- trigger 品質を上げた modular skills
- parallel role / subagent spec

詳しくは次を参照してください。
- `22_repo_patch_skeleton_overview.md`
- `23_agents_and_skills_optimization_notes.md`
- `24_subagent_role_specs.md`
- `repo_patch_skeleton/*`
