# SDF_featurescale_transform / wafergeo 拡張版統合レポート v3

本ファイルは、個別ドキュメント群の統合サマリーです。  
v3 では特に、**設計・手法・実装契約を実装可能な粒度へ引き上げた** ことが更新点です。

---

## 0. 目次

- [00_README.md](00_README.md)
- [01_current_repo_analysis.md](01_current_repo_analysis.md)
- [02_extension_principles_and_design.md](02_extension_principles_and_design.md)
- [03_methods_field_observer_metric.md](03_methods_field_observer_metric.md)
- [04_repo_modifications_implementation_plan.md](04_repo_modifications_implementation_plan.md)
- [05_data_assimilation_surrogate_future.md](05_data_assimilation_surrogate_future.md)
- [06_reference_catalog.md](06_reference_catalog.md)
- [07_appendix_example_specs_and_reports.md](07_appendix_example_specs_and_reports.md)
- [08_role_based_review.md](08_role_based_review.md)
- [09_implementation_task_list.md](09_implementation_task_list.md)
- [10_issue_pr_breakdown.md](10_issue_pr_breakdown.md)
- [11_algorithm_specs_and_pseudocode.md](11_algorithm_specs_and_pseudocode.md)
- [12_third_party_handbook_and_examples.md](12_third_party_handbook_and_examples.md)
- [13_public_api_contracts.md](13_public_api_contracts.md)

---

## 1. 一言でまとめた結論

既存 repo は方向性としてかなり良いです。  
拡張の本質は、**プロセス別特殊処理を増やすことではなく、共通幾何基盤を強くすること** にあります。

### 最も重要な設計変更
1. canonical を **raw SDF** に寄せる  
2. TSDF は **固定 3 scale view** にする  
3. SEM は **unsigned curve distance** を第一級にする  
4. observer kind は増やさず **bundle helper + profile/corner extractor** を作る  
5. metrics を **field + curve + profile + corner (+ topology)** に上げる  
6. surrogate export を **dense / query / mesh / Obs2D / profile** に広げる  

---

## 2. v3 で何が増えたか

v2 から v3 で増えたものは、主に次です。

- `Field3D / Obs2D / MetricBundle / DatasetPackageV2` の **責務と shape 契約**
- 各アルゴリズムの **疑似コード**
- 既存 repo への **file-by-file 差分設計**
- 第三者に説明しやすい **平易なハンドブック**
- 実装者向けの **public API 契約**

これにより、「提案としては理解できるが、実装粒度では曖昧」という状態を解消しています。

---

## 3. 既存 repo の強み

- artifact-driven
- `Obs2D` comparison domain を持つ
- geometry / metrics / assimilation / surrogate の責務分離がある
- 多材料 TSDF と boundary features を持つ
- docs 側に将来拡張の構想がすでに多い

---

## 4. 既存 repo の主な課題

- TSDF 中心で canonical が raw SDF より前に出ている
- 単一 `mu_nm` が局所 detail と大域形状を両立しにくい
- `pair_code` が離散的で界面学習には粗い
- hard voxel 起点で subvoxel 情報が弱い
- observer が上面 / 粗い断面中心で、bottom / sidewall / closure が見えにくい
- metrics が TSDF / contour / CD 中心で、工程重要差が埋もれる
- spec と実装のズレ、stub backend がある

---

## 5. 拡張後の core 抽象

```mermaid
flowchart LR
    A[Field3D\nraw SDF canonical]
    B[DistanceViews\nTSDF small/mid/large]
    C[Obs2D\nsigned/unsigned distance2d]
    D[ObserverBundle\nTopdown + Slice + Profiles + Corners]
    E[MetricBundle\nField + Curve + Profile + Corner]
    F[DatasetPackageV2\nDense / Query / Mesh / Obs2D / Profile]

    A --> B
    A --> D
    D --> C
    D --> E
    A --> F
```

---

## 6. なぜこの設計が半導体形状に効くのか

### エッチ
- bowing → `width(z)`, `wall_angle(z)`
- bottom rounding → `curvature(z)`, `corner`
- microtrench → bottom side の `gap/curvature/corner`

### 成膜
- conformality → `pair_separation(z)` / `thickness(z)`
- overhang → top corner
- pinch-off → `gap(z)` の収縮
- seam/void 前兆 → `gap(z)` と optional topology

### SEM 同化
- closed contour → signed
- open contour → unsigned
- similarity2d で minimal alignment
- component-wise loss で原因分解

---

## 7. loss がどう変わるか

従来:
- TSDF
- contour
- CD

拡張版:
- `L_field`
- `L_curve`
- `L_profile`
- `L_corner`
- optional `L_topology`

これにより、  
「CD は合うが profile が悪い」「平均膜厚は合うが overhang が悪い」といったケースを objective に載せられます。

---

## 8. 実装優先順位

1. spec / capability / fail-fast 整理  
2. `Field3D` と raw SDF canonical  
3. 3-scale TSDF view  
4. `Obs2D.distance2d_nm` 中心化  
5. SEM unsigned route  
6. profile / corner extractor  
7. `MetricBundle`  
8. assimilation / surrogate 移行  

---

## 9. どの文書を読めば何が分かるか

| 知りたいこと | 読むべき文書 |
|---|---|
| 既存 repo のどこが課題か | `01_current_repo_analysis.md` |
| 拡張後の責務・型設計 | `02_extension_principles_and_design.md` |
| 手法の意味と有用性 | `03_methods_field_observer_metric.md` |
| 既存 file をどう変えるか | `04_repo_modifications_implementation_plan.md` |
| データ同化・サロゲートへの価値 | `05_data_assimilation_surrogate_future.md` |
| 具体 spec / artifact 例 | `07_appendix_example_specs_and_reports.md` |
| 実装タスクと受け入れ条件 | `09_implementation_task_list.md` |
| PR 粒度 | `10_issue_pr_breakdown.md` |
| 疑似コード | `11_algorithm_specs_and_pseudocode.md` |
| 第三者向け説明 | `12_third_party_handbook_and_examples.md` |
| shape / error 契約 | `13_public_api_contracts.md` |

---

## 10. 最後の結論

この提案の本質は、  
**「SDF を使うこと」ではなく、「SDF を中心に geometry, observation, metric を共通基盤化すること」** です。

その結果として、

- データ同化では objective の方向が工程妥当になる
- サロゲートでは teacher 形式の自由度が上がる
- 第三者レビューでは意味の追跡がしやすくなる
- 実装では process-specific 分岐を増やさずに済む

という価値が生まれます。

v3 では、この設計を実装直前の粒度まで落としたので、  
次の段階ではそのまま Issue / PR / コードへ移し替えられるはずです。
