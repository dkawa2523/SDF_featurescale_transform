# 12. 第三者向けハンドブックと具体例

本章は、`wafergeo` の設計や手法を **プロジェクト外の第三者** が理解しやすいようにまとめた説明用ドキュメントです。  
研究開発、製造、品質、データサイエンス、アーキテクトのいずれの立場でも、  
「この拡張で何が良くなるのか」を短時間で把握できることを狙っています。

---

## 1. まず一言で言うと何をする基盤か

この基盤は、**ウェハー加工後の形状を、raw SDF を中心に統一的に表現し、SEM 輪郭や simulation 断面との違いを“意味のある形で”比較できるようにするもの** です。

単に「形が似ているか」を見るのではなく、

- どの深さで幅が違うか
- どの sidewall angle が違うか
- bottom edge がどれだけ丸いか
- top で overhang が強いか
- gap がどこで閉じ始めるか

まで、比較対象として見えるようにします。

---

## 2. なぜ CD だけでは足りないのか

CD は重要です。  
ただし、CD は断面の情報を **幅 1 本** に圧縮した量なので、  
次のような違いを見逃しやすいです。

```mermaid
flowchart TD
    A[同じCD] --> B[異なる側壁角]
    A --> C[異なるbottom rounding]
    A --> D[異なるbowing]
    A --> E[異なるoverhang]
```

つまり、「CD は合っている」ことと「形状が良い」ことは同じではありません。

---

## 3. この拡張で何が変わるのか

### 3.1 既存の見方
- multi-material TSDF
- contour 距離
- CD

### 3.2 拡張後の見方
- raw SDF canonical
- 3 スケール TSDF view
- signed / unsigned distance2d
- topdown + slice + profile + corner
- field + curve + profile + corner loss

### 3.3 直感的な違い
```mermaid
flowchart LR
    A[従来\n幅が近いか] --> B[拡張版\n幅・角度・丸み・角部・gap が近いか]
```

---

## 4. 例 1: エッチ trench で CD は合うが bowing が違う

### 4.1 状況
2 つの断面 A, B があり、top と bottom の CD はほぼ同じだが、  
B は中腹で sidewall が膨らんでいるとします。

### 4.2 従来評価
- top CD: 近い
- bottom CD: 近い
- mean Chamfer: それなり

一見、そんなに悪く見えません。

### 4.3 拡張版評価
- `width(z)` → 中腹で差が大きい
- `wall_angle(z)` → 中腹の角度が崩れる
- `field_loss` → narrow band で差が増える

### 4.4 価値
これにより「CD は合うのに profile が悪い」を objective に載せられます。  
これはエッチ条件最適化やデータ同化で非常に重要です。

---

## 5. 例 2: bottom rounding の違い

### 5.1 状況
底面の edge が、片方は鋭く、片方は丸い。

### 5.2 従来評価
- 幅は近い
- contour の大域差は小さい
- しかし bottom quality は違う

### 5.3 拡張版評価
- `curvature(z)` → bottom 付近で変化
- `bottom_left/bottom_right corner` → radius_like が変わる
- `corner_loss` → bottom edge 差を直接拾う

### 5.4 価値
電気特性や後工程への影響が大きい局所差を、  
評価から落とさずに済みます。

---

## 6. 例 3: 成膜の average thickness は合うが入口 overhang が違う

### 6.1 状況
2 つの成膜結果で平均膜厚は近いが、  
片方は入口で overhang が強く、gap が早く閉じ始めている。

### 6.2 従来評価
- mean thickness: 近い
- topdown opening: まだ似て見える
- bottom thickness: そこまで大差なし

### 6.3 拡張版評価
- `gap(z)` → top 側で急激に狭い
- `top corner descriptor` → 曲率・半径が変わる
- `profile_loss + corner_loss` → closure 前兆を拾う

### 6.4 価値
pinch-off や seam/void の前兆を、  
「まだ完全に閉じていない段階」でも objective に載せられます。

---

## 7. 例 4: open SEM contour をどう扱うか

### 7.1 状況
SEM から得られた輪郭が、底部や片側だけしか見えていない open contour である。

### 7.2 従来の無理な扱い
- contour を閉じる
- mask に変換する
- signed distance を作る

この方法は inside/outside を人工的に作るため、  
本来ない geometry 仮定を入れてしまいます。

### 7.3 拡張版の扱い
- open contour は open contour のまま扱う
- `unsigned_curve` として `Obs2D.distance2d_nm` を作る
- simulation 側も必要なら unsigned へ寄せて比較する

### 7.4 価値
観測にない仮定を入れずに済むため、  
SEM 同化の objective がより素直になります。

---

## 8. なぜ raw SDF を中心にするのか

第三者向けに平易に言うと、raw SDF は  
**「境界からの距離を、その内側か外側かも含めて表した地図」** です。

- 境界上は 0
- 内側は負
- 外側は正

この地図を基準にしておくと、  
そこから TSDF、輪郭、厚み、角度、丸みなどを一貫して作れます。

一方 TSDF は、raw SDF の一部だけを強調した見方です。  
便利ですが、基準にするには情報が落ちやすいです。

---

## 9. この設計が「汎用」で「シンプル」な理由

一見すると機能が増えているように見えますが、  
core に残す概念は実は少なくなっています。

### core に残るもの
- `Field3D`
- `Obs2D`
- `MetricBundle`
- `DatasetPackageV2`

### core に残さないもの
- process 専用 observer
- process 専用 loss
- SEM intensity simulator
- 学習器本体

つまり、「工程固有ロジックを詰め込んだ巨大システム」ではなく、  
**geometry 基盤だけを強くした設計** です。

---

## 10. データ同化にとっての価値

データ同化では、simulation 側のパラメータを調整して、  
観測側の形状に近づけたいわけです。

ここで objective が CD だけだと、optimizer は CD を合わせる方向にしか動きません。  
その結果、

- profile はまだ悪い
- bottom rounding が残る
- top overhang が残る

ということが起きます。

本提案では objective が

- field
- curve
- profile
- corner

に分かれるため、  
**optimizer が「どの geometry を直す方向へ動くべきか」がより工程妥当になる** という価値があります。

---

## 11. サロゲートにとっての価値

サロゲートでは、何を教師にするかが重要です。  
この基盤は同じ sample から、複数の教師形式を出せます。

### 出せるもの
- raw SDF
- 3-scale TSDF
- 2D distance maps
- contour
- profile table
- corner table
- query samples
- mesh

### なぜ有利か
将来、どのモデルを使うかはまだ確定していなくても、  
**教師 package の段階で選択肢を閉じない** ためです。

- dense voxel model
- implicit neural field
- point/query model
- graph/mesh model
- operator model

に後からつなぎやすくなります。

---

## 12. この拡張で増えるレポートの意味

拡張版では、最終 score だけでなく component report が出ます。  
これは単なるデバッグ情報ではありません。

### 12.1 field が大きい
- broad shape 差
- alignment 差
- narrow band 全体の mismatch

### 12.2 curve が大きい
- contour localization 差
- boundary 位置のずれ

### 12.3 profile が大きい
- 深さ依存の形状差
- bowing / taper / thickness の差

### 12.4 corner が大きい
- 角部 / 丸み / overhang / bottom edge の差

この分解があると、工程担当者とも会話しやすくなります。

---

## 13. どこまで実装すれば価値が出るか

全部を一気に入れる必要はありません。  
最小でも次まで入ればかなり価値が出ます。

1. `Field3D`（raw SDF canonical）
2. 3-scale TSDF
3. `Obs2D.distance2d_nm`
4. center slice
5. `width(z)` / `wall_angle(z)`
6. `corner_descriptor`
7. `field + profile + corner` loss

この段階で、CD だけでは見えない多くの mismatch を拾えるようになります。

---

## 14. よくある誤解

### 誤解 1: 「SDF を使うなら neural SDF まで一気に行くべき」
そうではありません。  
まず raw SDF を **teacher / canonical** として強くする方が、  
検証しやすく再現性も高いです。

### 誤解 2: 「プロセスごとに専用 metric が必要」
必ずしもそうではありません。  
多くは `width / angle / curvature / gap / thickness / corner` の組み合わせで十分です。

### 誤解 3: 「詳細化すると設計が複雑になる」
複雑になるのは、概念が増えるからではなく、  
責務の境界が曖昧なまま機能を足すからです。  
この提案はむしろ責務を減らしています。

---

## 15. 第三者に説明するときの短い言い方

短く言うなら、次の説明が使えます。

> この拡張版は、ウェハー加工形状を raw SDF で正規化し、  
> topdown や断面だけでなく、深さ方向 profile と corner まで観測・比較できるようにする基盤です。  
> これにより、CD だけでは見えない bottom rounding、bowing、overhang、gap closure などを objective に載せられます。

---

## 16. 本章の結論

第三者向けに最も大事なのは、  
**「この設計は多機能に見えて、実はかなり少ない抽象で整理されている」** と伝えることです。

- geometry canonical は `Field3D`
- 観測 canonical は `Obs2D`
- 比較 canonical は `MetricBundle`

この 3 層を押さえれば、本提案の価値はかなり理解しやすくなります。
