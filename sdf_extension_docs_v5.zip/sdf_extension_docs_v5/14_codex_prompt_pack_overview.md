# 14. Codex prompt pack overview

本章は、これまでに作成した設計資料を **Codex で実装に落とすための実務用レイヤ** です。  
v1〜v3 が「設計・手法・改修方針・Issue/PR 分解」を中心にまとめていたのに対し、v4 ではそれを **Codex にそのまま渡しやすい prompt / AGENTS / skill / runbook** に変換しています。

---

## 1. 何を追加したか

v4 では、次を追加しています。

1. `codex_assets/AGENTS.md`  
   - repo root に置く前提の指示書
2. `codex_assets/prompts/`  
   - master prompt  
   - Issue 単位 prompt  
   - reviewer prompt  
   - PR 完了 prompt
3. `codex_assets/skills/`  
   - optional な custom skill の叩き台
4. `14`〜`21` の説明文書  
   - prompt の使い方
   - 並列ロール運用
   - MCP / ネットワーク / safety
   - AGENTS / skills の使い方
   - prompt index / runbook / Codex 参考文献

---

## 2. この prompt pack の位置づけ

この prompt pack は、**docs を読み込ませれば自動で正しく実装してくれる魔法の箱** ではありません。  
代わりに、Codex が

- 何を正とすべきか
- どの docs を先に読むべきか
- どのファイルを触るべきか
- 何をやってはいけないか
- 何が完了条件か

を迷いにくくするための **実務的な scaffolding** です。

---

## 3. 使い方の全体像

```mermaid
flowchart TD
    A[docs bundle を repo から参照可能にする] --> B[AGENTS.md を repo root に置く]
    B --> C[OpenAI docs MCP を設定する]
    C --> D[00_master_orchestrator.md を流す]
    D --> E[Issue 単位 prompt を流す]
    E --> F[reviewer prompt を別タスクで流す]
    F --> G[94_pr_body_and_finish.md でまとめる]
```

---

## 4. Codex 向けに prompt をどう設計したか

本 pack の prompt は、次の方針で書いています。

### 4.1 直接的で短い命令を優先する
Codex / reasoning model は、冗長な chain-of-thought 指示よりも、**目的・制約・成功条件が明確な prompt** の方が扱いやすいです。  
そのため、各 prompt では

- この task の目的
- 先に読む docs
- 変更対象ファイル
- 必須要件
- 受け入れ条件
- やらないこと
- 出力形式

を固定しています。

### 4.2 1 task 1 prompt に寄せる
大きい prompt 1 本で全部やらせると、PR が太り、review が難しくなります。  
そのため、v3 の Issue 分解をそのまま prompt file に落としています。

### 4.3 reviewer を別 task 化する
Codex cloud は task を並列実行しやすいので、  
実装担当 prompt と reviewer prompt を分ける方が有効です。  
本 pack では、これを **手動サブエージェント運用** として整理しています。

### 4.4 AGENTS.md を常駐 guardrail にする
Issue prompt は task 固有ですが、repo 全体で繰り返し守るべき原則は `AGENTS.md` に寄せています。  
これにより、毎回 prompt に同じルールを長く書かずに済みます。

### 4.5 skills は optional
skills は有用ですが、環境依存があります。  
そのため、本 pack では

- 第一優先: `AGENTS.md`
- 第二優先: Issue prompt
- 第三優先: skill

という位置づけにしています。

---

## 5. この pack が特に効く場面

### 5.1 既存 repo に設計 docs を反映したいとき
設計 docs だけだと、Codex はどこから実装を始めるか迷いがちです。  
Issue prompt を使うと、着手点を固定できます。

### 5.2 並列で reviewer を走らせたいとき
Architect / DS / Process / QA 観点を reviewer prompt として分離しているので、  
後から「設計は合っているが observability が弱い」といった指摘を出しやすくなります。

### 5.3 docs と code を同期したいとき
各 prompt で docs / artifact / schema 更新を要求しているため、  
「コードだけ直って docs が古い」状態になりにくくなります。

---

## 6. 最初に使うべきファイル

最初に読む順は次です。

1. `00_README.md`
2. `14_codex_prompt_pack_overview.md`
3. `15_codex_orchestration_and_parallel_roles.md`
4. `16_codex_setup_mcp_network_and_safety.md`
5. `17_codex_AGENTS_and_repo_instructions.md`
6. `19_codex_prompt_index.md`
7. `codex_assets/AGENTS.md`
8. `codex_assets/prompts/00_master_orchestrator.md`

---

## 7. 設計 docs との対応

| 設計 docs | v4 で追加した実務 assets |
|---|---|
| `02_extension_principles_and_design.md` | `AGENTS.md`, architecture review prompt |
| `03_methods_field_observer_metric.md` | DS / process reviewer prompt, metric skill |
| `04_repo_modifications_implementation_plan.md` | issue prompt の target file 部分 |
| `09_implementation_task_list.md` | issue prompt の受け入れ条件 |
| `10_issue_pr_breakdown.md` | task 単位 prompt と branch 名 |
| `13_public_api_contracts.md` | artifact / schema / API guardrail |

---

## 8. この pack の非目標

- Codex の built-in 機能を全面的に抽象化すること
- repo の実装を自動生成し切ること
- issue tracking / branching / CI を自動運用すること
- skill discovery の環境差を完全に隠蔽すること

---

## 9. まとめ

v4 で追加したものは、設計自体の変更ではなく、**設計を実装へ移すときの摩擦を下げる operational layer** です。  
この pack を使うと、

- 最初の一歩が決まりやすい
- PR が太りにくい
- reviewer 観点を平行に回しやすい
- docs / artifact / code の同期が崩れにくい

という利点があります。
