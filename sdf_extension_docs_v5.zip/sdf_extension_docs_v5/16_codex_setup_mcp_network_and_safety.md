# 16. Codex setup, MCP, network, and safety

本章は、Codex でこの docs bundle を使う前の **環境セットアップと安全運用** をまとめます。

---

## 1. 最小セットアップ

### 1.1 AGENTS.md を repo root に置く
この bundle の `codex_assets/AGENTS.md` を repo root にコピーするか、既存 `AGENTS.md` に統合してください。

### 1.2 OpenAI developer docs MCP を設定する
Codex では OpenAI docs を MCP 経由で読めます。  
この repo 実装自体に必須ではありませんが、Codex / MCP / OpenAI API 関連の補足を参照したいときに有用です。

#### Codex CLI
```bash
codex mcp add openaiDeveloperDocs --url https://developers.openai.com/mcp
codex mcp list
```

#### `~/.codex/config.toml`
```toml
[mcp_servers.openaiDeveloperDocs]
url = "https://developers.openai.com/mcp"
```

#### VS Code Agent mode
`.vscode/mcp.json` 例:
```json
{
  "servers": {
    "openaiDeveloperDocs": {
      "type": "http",
      "url": "https://developers.openai.com/mcp"
    }
  }
}
```

---

## 2. AGENTS.md に入れておくと有用な 1 行

OpenAI docs MCP の guide では、次の一文を `AGENTS.md` に入れることが推奨されています。

```md
Always use the OpenAI developer documentation MCP server if you need to work with the OpenAI API, ChatGPT Apps SDK, Codex, or related docs without me having to explicitly ask.
```

この bundle の `codex_assets/AGENTS.md` には、すでにこの趣旨を入れています。

---

## 3. ネットワーク設定の基本方針

この repo の拡張実装では、**ネットワークは基本 off** を推奨します。  
理由は 2 つあります。

1. 設計 docs と repo 本体で完結する task が多い
2. issue / web page / arbitrary README 経由の prompt injection リスクを避けたい

### 3.1 Internet を使う場面
- 依存関係の install が必要なとき
- optional backend の公式 docs を最小限確認するとき
- OpenAI official docs MCP を読むとき

### 3.2 Internet を使わない方がよい場面
- 実装 task の大半
- issue body や外部 blog を直接読ませる運用
- 任意サイトからコード片を拾わせる運用

### 3.3 allowlist の考え方
Codex cloud の network access は、必要なドメインだけ allowlist する方が安全です。  
この repo では、まず **none / common dependencies + 必要最小限の追加** を原則にしてください。

### 3.4 HTTP methods
可能なら `GET / HEAD / OPTIONS` に限定してください。  
書き込み系メソッドを開ける必要は通常ありません。

---

## 4. prompt injection への注意

外部 issue URL や README、任意 web page をそのまま読ませると、  
そこに埋め込まれた悪意ある命令に引っ張られるリスクがあります。

この repo では、次を推奨します。

- issue URL を直接渡す代わりに、必要部分だけ prompt に貼る
- 外部 docs は公式 docs MCP か trusted source に限定する
- 実装 task では internet off を基本にする

---

## 5. Codex CLI approval mode の使い分け

Codex CLI には、少なくとも次の approval mode があります。

- Suggest
- Auto Edit
- Full Auto

この repo では次を推奨します。

| 作業 | 推奨 mode |
|---|---|
| repo 読解 / plan 作成 | Suggest |
| 小〜中規模の実装 | Auto Edit |
| まとまった機械的置換 + tests | Auto Edit or Full Auto |
| optional backend や依存追加 | Suggest or Auto Edit |
| docs-only update | Suggest or Auto Edit |

### 基本方針
- Phase 0〜3 は **Auto Edit** が扱いやすい
- dependency install や広い diff を伴うものは **Suggest** から始める
- Full Auto は sandbox / version control / acceptance criteria が揃っている時だけ使う

---

## 6. この repo での実用 default

### 実装開始時
- internet: off
- mode: ask → code
- reasoning: high

### reviewer task
- internet: off
- mode: ask
- reasoning: medium or high

### docs / artifact 整理
- internet: off
- mode: code
- reasoning: medium

---

## 7. まとめ

この repo の Codex 運用では、**repo local docs + AGENTS.md + issue prompt** が主役です。  
MCP と network は補助的に使い、外部入力を増やしすぎない方が安全で安定します。
