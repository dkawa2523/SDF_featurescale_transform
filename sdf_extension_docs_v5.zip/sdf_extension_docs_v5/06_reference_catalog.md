# 06. 参考文献・調査ソース一覧

本章は、本提案の背景となる repo 読解と外部文献を整理したカタログです。  
分類は次の通りです。

- A. 対象 repo と実装読解
- B. 距離変換 / SDF 基盤
- C. implicit / UDF / surface reconstruction
- D. loss / topology
- E. 半導体エッチ / 成膜 / gap-fill / profile 制御
- F. surrogate / operator / digital twin

> 注: URL は 2026-04-04 時点で参照したものです。  
> production 採用時は DOI / 公式 project page / official repo を優先して再確認してください。

---

# A. 対象 repo と実装読解

## Repo-01. 対象リポジトリ
- 名称: `dkawa2523/SDF_featurescale_transform`
- URL: https://github.com/dkawa2523/SDF_featurescale_transform
- 用途: repo 全体構造、docs 一覧、コード配置確認

## Repo-02. `pyproject.toml`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/pyproject.toml
- 用途: package 名 `wafergeo`、optional dependencies、project scope 確認

## Repo-03. `0_design.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/0_design.md
- 用途: layer structure / artifact-driven design / comparison domain の把握

## Repo-04. `2_sdf.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/2_sdf.md
- 用途: material-wise SDF / TSDF / `d_boundary` / `pair_code` の思想把握

## Repo-05. `2-1_sdf_extend.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/2-1_sdf_extend.md
- 用途: exact EDT, Maurer, JFA, OpenVDB, mesh→SDF, polyline SDF の拡張構想

## Repo-06. `4_observer.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/4_observer.md
- 用途: geometry→Obs2D 統一方針

## Repo-07. `5_Metrics.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/5_Metrics.md
- 用途: Obs2D-vs-Obs2D metric layer の責務整理

## Repo-08. `6_SEM_prepare.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/6_SEM_prepare.md
- 用途: mask TSDF と analytic polyline distance の両構想

## Repo-09. `7_assimilation.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/7_assimilation.md
- 用途: optimizer 本体ではなく objective evaluator としての位置づけ

## Repo-10. `8_surrogate.md`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/8_surrogate.md
- 用途: learning code ではなく package generator であることの確認

## Repo-11. `wafergeo/sdf/tsdf.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/sdf/tsdf.py
- 用途: `to_tsdf`, `from_tsdf`, `label_from_tsdf` 実装確認

## Repo-12. `wafergeo/sdf/edt.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/sdf/edt.py
- 用途: signed distance 構成方法確認

## Repo-13. `wafergeo/sdf/boundary_features.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/sdf/boundary_features.py
- 用途: `d_boundary`, `pair_code` 実装確認

## Repo-14. `wafergeo/observe/topdown.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/observe/topdown.py
- 用途: exposed material / height map / mask2d / tsdf2d / contour の確認

## Repo-15. `wafergeo/observe/slice.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/observe/slice.py
- 用途: fixed slice observer の確認

## Repo-16. `wafergeo/metrics/tsdf_loss.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/metrics/tsdf_loss.py
- 用途: narrow-band TSDF loss の確認

## Repo-17. `wafergeo/metrics/contour_metrics.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/metrics/contour_metrics.py
- 用途: contour metric の確認

## Repo-18. `wafergeo/metrics/cd_metrics.py`
- URL: https://raw.githubusercontent.com/dkawa2523/SDF_featurescale_transform/main/wafergeo/metrics/cd_metrics.py
- 用途: line-scan CD metric の確認

---

# B. 距離変換 / SDF 基盤

## Ref-B01. SciPy exact EDT
- Title: `scipy.ndimage.distance_transform_edt`
- URL: https://docs.scipy.org/doc/scipy-1.15.3/reference/generated/scipy.ndimage.distance_transform_edt.html
- 要点:
  - Exact Euclidean distance transform
  - `sampling` による spacing 指定
- 使い方:
  - 標準 exact EDT backend の根拠

## Ref-B02. CuPy exact EDT
- Title: `cupyx.scipy.ndimage.distance_transform_edt`
- URL: https://docs.cupy.dev/en/latest/reference/generated/cupyx.scipy.ndimage.distance_transform_edt.html
- 要点:
  - GPU 上の exact EDT
  - spacing 対応
- 使い方:
  - optional GPU exact backend 候補

## Ref-B03. ITK Signed Maurer Distance Map
- Title: `itk::SignedMaurerDistanceMapImageFilter`
- URL: https://docs.itk.org/projects/doxygen/en/v5.3.0/classitk_1_1SignedMaurerDistanceMapImageFilter.html
- 要点:
  - arbitrary dimension
  - linear-time exact EDT
  - spacing / sign convention あり
- 使い方:
  - optional exact backend 候補

## Ref-B04. Maurer et al. 2003
- Title: `A Linear Time Algorithm for Computing Exact Euclidean Distance Transforms of Binary Images in Arbitrary Dimensions`
- DOI: 10.1109/TPAMI.2003.1177156
- 使い方:
  - exact EDT の理論的根拠

---

# C. Implicit / UDF / surface reconstruction

## Ref-C01. Neuralangelo
- Title: `Neuralangelo: High-Fidelity Neural Surface Reconstruction`
- Project: https://research.nvidia.com/labs/dir/neuralangelo/
- Publication: https://research.nvidia.com/publication/2023-06_neuralangelo-high-fidelity-neural-surface-reconstruction
- DOI: 10.1109/CVPR52729.2023.00817
- 要点:
  - multi-resolution hash grids
  - coarse-to-fine optimization
  - eikonal + curvature regularization
- 使い方:
  - multi-scale implicit downstream の代表例

## Ref-C02. SDFStudio
- Title: `SDFStudio: A Unified Framework for Surface Reconstruction`
- Official repo / project: https://github.com/autonomousvision/sdfstudio
- 要点:
  - MLP / tri-plane / multi-res feature grid
  - unified framework
- 使い方:
  - downstream export 接続先の代表例

## Ref-C03. NeuralUDF
- Title: `NeuralUDF: Learning Unsigned Distance Fields for Multi-View Reconstruction of Surfaces With Arbitrary Topologies`
- CVPR page: https://cvpr.thecvf.com/virtual/2023/poster/23277
- Project page: https://www.xxlong.site/NeuralUDF/
- 要点:
  - arbitrary topology / open surface に UDF を使う
- 使い方:
  - SEM / open contour route の理論背景

## Ref-C04. NeUDF
- Title: `NeUDF: Learning Neural Unsigned Distance Fields With Volume Rendering`
- PubMed: https://pubmed.ncbi.nlm.nih.gov/38015705/
- DOI: 10.1109/TPAMI.2023.3335353
- 使い方:
  - UDF-based neural rendering の代表

## Ref-C05. NoKSR
- Title: `NoKSR: Kernel-Free Neural Surface Reconstruction via Point Cloud Serialization`
- OpenReview: https://openreview.net/forum?id=Z8bwCg6tJH
- dblp: https://dblp.org/rec/conf/3dim/LiSGXRT25.html
- DOI: 10.1109/3DV66043.2025.00057
- 要点:
  - point cloud serialization
  - multi-scale token aggregation
  - point→SDF reconstruction
- 使い方:
  - point-based downstream 候補

## Ref-C06. ViscoReg
- Title: `ViscoReg: Neural Signed Distance Functions via Viscosity Solutions`
- OpenReview: https://openreview.net/forum?id=0xObmDmsKY
- 状態: ICLR 2026 投稿中 / review 中
- 注意:
  - promising だが現時点では production-ready とみなさない
- 使い方:
  - research watchlist

---

# D. Loss / topology

## Ref-D01. Boundary loss
- Title: `Boundary loss for highly unbalanced segmentation`
- ScienceDirect: https://www.sciencedirect.com/science/article/pii/S1361841520302152
- PubMed: https://pubmed.ncbi.nlm.nih.gov/33080507/
- DOI: 10.1016/j.media.2020.101851
- 要点:
  - region ではなく contour / interface 中心の loss
  - highly unbalanced targets に有効
- 使い方:
  - thin film, narrow gap, boundary-centric geometry loss の参考

## Ref-D02. clDice
- Title: `clDice - A Novel Topology-Preserving Loss Function for Tubular Structure Segmentation`
- CVPR open access: https://openaccess.thecvf.com/content/CVPR2021/html/Shit_clDice_-_A_Novel_Topology-Preserving_Loss_Function_for_Tubular_Structure_CVPR_2021_paper.html
- DOI: 10.1109/CVPR46437.2021.01629
- 要点:
  - topology preservation up to homotopy equivalence
- 使い方:
  - seam / void / closure / through-open など connectivity が重要な場合の optional loss

---

# E. 半導体エッチ / 成膜 / gap-fill / profile 制御

## Ref-E01. Sidewall necking / bowing
- Title: `Mechanism of Sidewall Necking and Bowing in the Plasma Etching of High Aspect-Ratio Contact Holes`
- DOI: 10.1149/1.3276511
- CiNii: https://cir.nii.ac.jp/crid/1360574095610779648
- 要点:
  - necking / bowing が時間とともに悪化し位置が深部へ移動
- 使い方:
  - `width(z)` / `wall_angle(z)` / depth-dependent profile の重要性

## Ref-E02. HAR contact hole profile control
- Title: `Profile control in high aspect ratio contact hole etching by a capacitively coupled plasma source`
- ScienceDirect: https://www.sciencedirect.com/science/article/pii/S0167931705003138
- DOI: 10.1016/j.mee.2005.07.001
- 要点:
  - bowing-free vertical profileは polymer deposition と ion extraction control に依存
- 使い方:
  - profile angle と process controllability の重要性

## Ref-E03. Microtrenching / bowing / rounded bottom
- Title: `Plasma interactions with high aspect ratio patterned surfaces: ion transport, scattering, and the role of charging`
- ScienceDirect: https://www.sciencedirect.com/science/article/abs/pii/S0040609000011494
- DOI: 10.1016/S0040-6090(00)01149-4
- 要点:
  - ion scattering が microtrenching / bowing に寄与
  - charging により rounded bottom へ遷移しうる
- 使い方:
  - corner / curvature / bottom feature の重要性

## Ref-E04. Sidewall roughness / scalloping
- Title: `Improving sidewall roughness by combined RIE-Bosch process`
- ScienceDirect: https://www.sciencedirect.com/science/article/pii/S1369800118305419
- DOI: 10.1016/j.mssp.2018.04.033
- 要点:
  - Bosch scalloping / roughness の定量的重要性
- 使い方:
  - contour roughness / curvature oscillation を profile に取り込む根拠

## Ref-E05. ALD conformality review
- Title: `Conformality in atomic layer deposition: Current status overview of analysis and modelling`
- URL: https://pubs.aip.org/aip/apr/article/6/2/021302/570185/Conformality-in-atomic-layer-deposition-Current
- DOI: 10.1063/1.5060967
- 要点:
  - conformality 定義
  - thickness profile / penetration / exposure / reaction probability
  - thermal / PE-ALD / ozone-based ALD 比較
- 使い方:
  - thickness / conformality / penetration を geometry feature として扱う根拠

## Ref-E06. Plasma-assisted ALD conformality
- Title: `Conformality of plasma-assisted ALD: physical processes and modeling`
- URL: https://research.tue.nl/en/publications/conformality-of-plasma-assisted-ald-physical-processes-and-modeli
- DOI: 10.1149/1.3491381
- 要点:
  - recombination-limited regime
  - trench bottom minimum before saturation
- 使い方:
  - `thickness(z)` / `gap(z)` / depth-dependent profile の重要性

## Ref-E07. Bottom-up PE-ALD seamless gap fill
- Title: `Bottom-up plasma-enhanced atomic layer deposition of SiO2 by utilizing growth inhibition using NH3 plasma pre-treatment for seamless gap-fill process`
- Nature / Sci Rep: https://www.nature.com/articles/s41598-022-20201-y
- PubMed: https://pubmed.ncbi.nlm.nih.gov/36131082/
- DOI: 10.1038/s41598-022-20201-y
- 要点:
  - seam / void 抑制には bottom-up growth が重要
- 使い方:
  - `gap(z)` / `thickness(z)` / closure profile の重要性

## Ref-E08. Bias-frequency assisted bottom-up gap fill
- Title: `Effect of Bias Frequency on Bottom-Up SiO2 Gap-Filling Using Plasma-Enhanced Atomic Layer Deposition`
- PubMed: https://pubmed.ncbi.nlm.nih.gov/39069792/
- DOI: 10.1021/acsami.4c06106
- 要点:
  - overhang formation と bottom-up fill のトレードオフ
- 使い方:
  - `gap(z)` / `width(z)` / top vs bottom thickness の重要性

## Ref-E09. Gradient area-selective deposition for seamless gap fill
- Title: `Gradient area-selective deposition for seamless gap-filling in 3D nanostructures through surface chemical reactivity control`
- Nature Communications: https://www.nature.com/articles/s41467-022-35428-6
- 要点:
  - surface reactivity control による seamless gap-fill
- 使い方:
  - geometry-aware deposition objectives の参考

---

# F. surrogate / operator / digital twin

## Ref-F01. Fourier Neural Operator
- Title: `Fourier Neural Operator for Parametric Partial Differential Equations`
- ICLR page: https://iclr.cc/virtual/2021/poster/3281
- 要点:
  - function-to-function learning
  - PDE family surrogate
- 使い方:
  - recipe→shape field surrogate の基礎

## Ref-F02. Geo-FNO
- Title: `Fourier Neural Operator with Learned Deformations for PDEs on General Geometries`
- JMLR: https://jmlr.org/beta/papers/v24/23-0064.html
- GitHub: https://github.com/neuraloperator/Geo-FNO
- arXiv: https://arxiv.org/abs/2207.05209
- 要点:
  - arbitrary geometries
  - point clouds, meshes, design parameters を入力可能
- 使い方:
  - geometry-aware operator downstream の代表

## Ref-F03. PointNet++
- Title: `PointNet++: Deep Hierarchical Feature Learning on Point Sets in a Metric Space`
- NeurIPS page: https://papers.nips.cc/paper/7095-pointnet-deep-hierarchical-feature-learning-on-point-sets-in-a-metric-space
- arXiv: 1706.02413
- 要点:
  - multi-scale local point features
- 使い方:
  - point cloud export の baseline 候補

## Ref-F04. Point Transformer V3
- Official repo: https://github.com/Pointcept/PointTransformerV3
- CVPR 2024 virtual / summary sources available
- 要点:
  - large receptive field
  - efficient large-scale point cloud learning
- 使い方:
  - point / contour sample downstream の高性能候補

## Ref-F05. MeshGraphNets
- Title: `Learning Mesh-Based Simulation with Graph Networks`
- arXiv: https://arxiv.org/abs/2010.03409
- 参考紹介: https://huggingface.co/papers/2010.03409
- 要点:
  - mesh-based dynamics learning
- 使い方:
  - boundary mesh dynamic surrogate 候補

## Ref-F06. STwinner digital twin
- Title: `Simulation-guided AI-driven digital twin for plasma etching in semiconductor fabrication`
- ScienceDirect: https://www.sciencedirect.com/science/article/pii/S2666998625003394
- DOI: 10.1016/j.device.2025.101026
- 要点:
  - calibrated TCAD + neural operator + transfer learning
  - MBCFET metal etching で 34% data でも experiment-based workflow に匹敵
  - real-time monitoring / adaptive control を志向
- 使い方:
  - system-level 将来像としての digital twin 文脈

## Ref-F07. Real-to-sim in semiconductor manufacturing
- Title: `Real-to-sim: automatic simulation model generation for a digital twin in semiconductor manufacturing`
- Springer: https://link.springer.com/article/10.1007/s10845-025-02572-x
- 要点:
  - semiconductor manufacturing の digital twin 文脈
- 使い方:
  - geometric twin / simulation coupling の broader context

---

# G. 推奨の読み方

もし目的が

- **repo 改修** なら  
  A → B → D → E

- **データ同化** なら  
  A → D → E → F

- **サロゲート学習** なら  
  A → B → C → F

- **将来技術調査** なら  
  C → E → F

の順で読むと整理しやすいです。
