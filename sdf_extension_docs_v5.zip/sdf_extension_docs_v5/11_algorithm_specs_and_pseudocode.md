# 11. アルゴリズム仕様と疑似コード（実装直前レベル）

本章は、拡張版で導入する主要アルゴリズムを **実装直前の粒度** まで落として記述したものです。  
狙いは、設計書を読んだ実装者が「次に何を書けばよいか」を迷わないようにすることです。

---

## 1. この章の使い方

各アルゴリズムについて、次をそろえています。

- 目的
- 入力 / 出力
- 前提条件
- 手順
- 疑似コード
- 計算量の目安
- よくある失敗
- テスト観点

---

## 2. `build_field3d_from_labels`

## 2.1 目的
raw material label volume を canonical role に写像し、  
role ごとの raw signed distance stack を作って `Field3D` を構築します。

## 2.2 入力
- `labels_zyx: np.ndarray[int]`
- `spacing_nm_zyx: tuple[float,float,float]`
- `role_spec: RoleSpec`
- `backend: str`
- `emit_udf: bool`
- `emit_scalar_fields: list[str] | None`

## 2.3 出力
- `Field3D`

## 2.4 前提条件
- label volume は 3D
- spacing は正
- `role_spec` に `void_role_id` がある
- `raw_material_to_role` が labels の全値をカバーしている

## 2.5 手順
1. raw label を role label へ写像  
2. role ごと binary mask を作る  
3. 各 role について signed distance を計算  
4. optional で unsigned distance を計算  
5. scalar fields を作る  
6. QA を計算  
7. `Field3D` を返す  

## 2.6 疑似コード
```python
def build_field3d_from_labels(labels_zyx, spacing_nm_zyx, role_spec, *, backend, emit_udf, emit_scalar_fields):
    validate_labels(labels_zyx, spacing_nm_zyx, role_spec)

    role_labels = map_raw_labels_to_roles(labels_zyx, role_spec.raw_material_to_role)

    role_ids = sorted(role_spec.role_id_to_name.keys())
    sdf_stack = []
    udf_stack = [] if emit_udf else None

    for role_id in role_ids:
        mask = (role_labels == role_id)

        sdf = signed_distance_from_mask(
            mask=mask,
            spacing_nm=spacing_nm_zyx,
            backend=backend,
            inside_negative=True,
        )
        sdf_stack.append(sdf.astype(np.float32))

        if emit_udf:
            udf = unsigned_distance_from_mask(
                mask=mask,
                spacing_nm=spacing_nm_zyx,
                backend=backend,
            )
            udf_stack.append(udf.astype(np.float32))

    sdf_nm = np.stack(sdf_stack, axis=0)
    udf_nm = np.stack(udf_stack, axis=0) if emit_udf else None

    scalar_fields = build_scalar_fields(role_labels, sdf_nm, spacing_nm_zyx, emit_scalar_fields)
    qa = summarize_field_qa(sdf_nm, spacing_nm_zyx)

    return Field3D(
        grid=GridMeta(...),
        roles=role_spec,
        sdf_nm=sdf_nm,
        udf_nm=udf_nm,
        scalar_fields=scalar_fields,
        qa=qa,
        meta={"builder_backend": backend},
    )
```

## 2.7 計算量
- role 数を `R`、voxel 数を `N = Z*Y*X` とすると
- 距離変換コストが支配的
- exact EDT 前提で概ね `O(RN)`

## 2.8 よくある失敗
- labels に未知 material id が混ざる
- role ごとに void を含める扱いが曖昧
- `sdf_nm` の role 順序を metadata に残さない

## 2.9 テスト観点
- 2値 box で符号が正しい
- anisotropic spacing で距離が合う
- role mapping 欠損で fail-fast

---

## 3. `signed_distance_from_mask`

## 3.1 目的
binary mask から spacing-aware signed distance を作る。

## 3.2 基本式
inside negative の場合、一般には

\[
\phi = d_{\text{outside}} - d_{\text{inside}}
\]

と書けます。

実装上は、mask 内部と外部の EDT を別々に計算し、差を取ります。

## 3.3 疑似コード
```python
def signed_distance_from_mask(mask, spacing_nm, *, backend, inside_negative=True):
    validate_binary_mask(mask)
    caps = resolve_backend_caps(backend)
    if not caps.supports_signed:
        raise UnsupportedCapabilityError(...)

    # distance to background for foreground voxels
    inside = edt(mask, spacing=spacing_nm, backend=backend)

    # distance to foreground for background voxels
    outside = edt(~mask, spacing=spacing_nm, backend=backend)

    phi = outside - inside
    if not inside_negative:
        phi = -phi
    return phi.astype(np.float32)
```

## 3.4 注意
- `mask=True` を inside とみなすかを固定する
- EDT 実装によって feature transform の意味が違う場合がある
- 境界上の 0 近傍挙動を test で固定する

---

## 4. `build_distance_views`

## 4.1 目的
raw SDF から学習や比較で使いやすい派生 view を作る。

## 4.2 入力
- `field: Field3D`
- `spec: ViewSpec`

## 4.3 出力
- `DistanceViews`

## 4.4 疑似コード
```python
def build_distance_views(field, spec):
    tsdf_views = {}
    tanh_views = {}
    logsigned_views = {}

    if spec.tsdf_mu_nm:
        for name, mu in spec.tsdf_mu_nm.items():
            tsdf_views[name] = clip(field.sdf_nm, -mu, mu) / mu

    if spec.tanh_mu_nm:
        for name, mu in spec.tanh_mu_nm.items():
            tanh_views[name] = np.tanh(field.sdf_nm / mu)

    if spec.emit_logsigned:
        sign = np.sign(field.sdf_nm).astype(np.int8)
        mag = np.log1p(np.abs(field.sdf_nm)).astype(np.float32)
        logsigned_views["default"] = (sign, mag)

    return DistanceViews(
        tsdf_views=tsdf_views,
        tanh_views=tanh_views,
        logsigned_views=logsigned_views,
        meta={"source": "Field3D.sdf_nm", "spec": asdict(spec)},
    )
```

## 4.5 設計上の注意
- raw SDF を必ず残す
- TSDF の `mu` は spec に保存
- view は out-of-place に生成する

---

## 5. `observe_topdown_exposed`

## 5.1 目的
観測方向から最初に見える面を取り出し、topdown の `Obs2D` を構築する。

## 5.2 入力
- `field: Field3D`
- `target_role`
- `view_axis`（例: `"z-"`）
- `signed_mode`

## 5.3 出力
- `Obs2D`

## 5.4 手順
1. 観測軸に沿って走査順を決める  
2. 各 `(y,x)` で最初に非 void の role を見つける  
3. `exposed_role_id`, `top_height_nm` を記録  
4. `target_role` の topdown mask を作る  
5. signed/unsigned の 2D distance を作る  
6. `Obs2D` を返す  

## 5.5 疑似コード
```python
def observe_topdown_exposed(field, *, target_role=None, view_axis="z-", signed_mode=True):
    role_labels = np.argmin(field.sdf_nm, axis=0)  # or a deterministic label decode
    void_role = field.roles.void_role_id

    Z, Y, X = role_labels.shape
    exposed_role = np.full((Y, X), void_role, dtype=np.int16)
    top_height_nm = np.full((Y, X), np.nan, dtype=np.float32)

    z_indices = range(Z) if view_axis == "z-" else range(Z - 1, -1, -1)

    for y in range(Y):
        for x in range(X):
            for z in z_indices:
                rid = role_labels[z, y, x]
                if rid != void_role:
                    exposed_role[y, x] = rid
                    top_height_nm[y, x] = z_to_nm(z, field.grid)
                    break

    if target_role is None:
        mask2d = exposed_role != void_role
    else:
        mask2d = exposed_role == target_role

    if signed_mode:
        distance2d = signed_distance_from_mask(mask2d, spacing_nm=field.grid.spacing_nm_zyx[1:])
        semantics = "signed"
    else:
        distance2d = unsigned_distance_from_mask(mask2d, spacing_nm=field.grid.spacing_nm_zyx[1:])
        semantics = "unsigned"

    return Obs2D(
        ...,
        distance2d_nm=distance2d,
        mask2d=mask2d,
        debug_maps={
            "exposed_role_id": exposed_role,
            "top_height_nm": top_height_nm,
        },
        meta={"distance_semantics": semantics, "observer_kind": "topdown_exposed"},
    )
```

## 5.6 注意
- topdown の role decode は deterministic であること
- void のみの列は `nan` 高さになる
- topdown mask は selected role に応じて意味が変わる

---

## 6. `observe_slice`

## 6.1 目的
3D field から 2D 断面 `Obs2D` を作る。

## 6.2 入力
- `field`
- `axis`
- `position_nm`
- `slab_thickness_nm`
- `target_role`
- `signed_mode`

## 6.3 出力
- `Obs2D`

## 6.4 手順
1. slice index を決める  
2. slab 厚みがある場合は index 範囲を作る  
3. role label か target role SDF を 2D へ還元  
4. 2D mask または 2D signed field を構成  
5. 必要なら distance2d を再構築  
6. `Obs2D` を返す  

## 6.5 断面還元の基本方針
- binary mask source の場合: slab 内 OR/union
- signed field source の場合: zero crossing を保ちやすい還元を選ぶ
- 最初の実装は OR union でよい

## 6.6 疑似コード
```python
def observe_slice(field, *, axis, position_nm=None, slab_thickness_nm=0.0, target_role=None, signed_mode=True):
    idx_center = axis_position_to_index(axis, position_nm, field.grid)
    idx_list = slab_indices(idx_center, slab_thickness_nm, axis, field.grid)

    role_labels = np.argmin(field.sdf_nm, axis=0)
    void_role = field.roles.void_role_id

    slab = take_indices(role_labels, axis=axis, indices=idx_list)

    if target_role is None:
        mask2d = np.any(slab != void_role, axis=0)
    else:
        mask2d = np.any(slab == target_role, axis=0)

    spacing_nm_2d = slice_spacing_nm(field.grid, axis)

    if signed_mode:
        distance2d = signed_distance_from_mask(mask2d, spacing_nm=spacing_nm_2d)
        semantics = "signed"
    else:
        distance2d = unsigned_distance_from_mask(mask2d, spacing_nm=spacing_nm_2d)
        semantics = "unsigned"

    return Obs2D(
        ...,
        distance2d_nm=distance2d,
        mask2d=mask2d,
        meta={"distance_semantics": semantics, "observer_kind": "slice", "axis": axis},
    )
```

---

## 7. contour 再構成（distance2d -> contour）

## 7.1 目的
profile/corner 抽出のために contour polyline を得る。

## 7.2 手順
1. signed distance なら zero level set を marching squares  
2. unsigned の場合は元 contour があればそれを優先  
3. polyline を arc-length 一様再サンプル  
4. smoothing optional  

## 7.3 疑似コード
```python
def contour_from_obs2d(obs, *, resample_step_nm=1.0, smoothing_sigma_nm=0.0):
    if obs.contours_xy_nm is not None and len(obs.contours_xy_nm) > 0:
        contour = select_main_contour(obs.contours_xy_nm)
    else:
        if obs.meta["distance_semantics"] != "signed":
            raise ValueError("unsigned distance without contour cannot define inside/outside contour robustly")
        contour = marching_squares_zero_level(obs.distance2d_nm, obs.spacing_nm_yx, obs.origin_nm_yx)

    contour = resample_polyline(contour, step_nm=resample_step_nm)
    if smoothing_sigma_nm > 0:
        contour = smooth_polyline(contour, sigma_nm=smoothing_sigma_nm)
    return contour
```

---

## 8. `extract_width_profile`

## 8.1 目的
断面での左右境界間の距離を深さ方向 profile として求める。

## 8.2 入力
- 断面 contour または signed distance
- 深さ軸 `z`
- orientation 情報

## 8.3 出力
- `coordinate_nm`
- `width(z)`
- `support_mask`

## 8.4 手順
1. 各深さ `z_i` に水平ラインを引く  
2. contour との交点を求める  
3. 左右 2 交点がある場合のみ有効  
4. `width = x_right - x_left`  
5. support を記録  

## 8.5 疑似コード
```python
def extract_width_profile(contour_xy, z_grid_nm):
    width = np.full_like(z_grid_nm, np.nan, dtype=np.float32)
    support = np.zeros_like(z_grid_nm, dtype=bool)

    for i, z in enumerate(z_grid_nm):
        xs = contour_line_intersections(contour_xy, horizontal_line_y=z)
        if len(xs) >= 2:
            xs = sorted(xs)
            width[i] = xs[-1] - xs[0]
            support[i] = True

    return width, support
```

## 8.6 よくある失敗
- 交点が 4 つ以上ある複雑形状
- open contour に対して左右を決められない
- ノイズで交点数が不安定

## 8.7 対策
- 既定では outermost pair を使う
- diagnostics に crossing count を保存
- 必要なら future extension で pair selection policy を追加

---

## 9. `extract_wall_angle_profile`

## 9.1 目的
側壁の verticality / taper を depth-dependent に測る。

## 9.2 入力
- 左右境界関数 `x_left(z), x_right(z)`

## 9.3 手順
1. `x(z)` を smoothing  
2. 一階差分 `dx/dz` を求める  
3. `theta = atan(dx/dz)` を計算  
4. support がある深さだけ返す  

## 9.4 疑似コード
```python
def extract_wall_angle_profile(x_of_z, z_grid_nm, support, *, smoothing_sigma_nm):
    x_sm = smooth_1d_with_support(x_of_z, support, sigma_nm=smoothing_sigma_nm)
    dx_dz = finite_diff(x_sm, z_grid_nm)
    theta_deg = np.degrees(np.arctan(dx_dz))
    theta_deg[~support] = np.nan
    return theta_deg
```

## 9.5 注意
- 角度の符号規約を API 契約に明記する
- 左壁と右壁で向きが逆になることに注意
- 極端に sparse な support では角度を出さない

---

## 10. `extract_curvature_profile`

## 10.1 目的
rounded bottom, footing, scalloping などを捉える。

## 10.2 方法
- 連続曲線近似後の二階差分
- または局所 circle fit

## 10.3 推奨
最初の実装は **smoothed finite difference** が簡単です。  
高ノイズなら circle fit を optional にできます。

## 10.4 疑似コード
```python
def extract_curvature_profile(x_of_z, z_grid_nm, support, *, smoothing_sigma_nm):
    x_sm = smooth_1d_with_support(x_of_z, support, sigma_nm=smoothing_sigma_nm)
    dx = finite_diff(x_sm, z_grid_nm)
    ddx = finite_diff(dx, z_grid_nm)
    kappa = ddx / np.power(1.0 + dx * dx, 1.5)
    kappa[~support] = np.nan
    return kappa
```

---

## 11. `extract_pair_separation_profile`

## 11.1 目的
2 本の界面間距離を generic に取る。  
gap と thickness を共通化するための基本関数。

## 11.2 入力
- `curve_a(z)`
- `curve_b(z)`

## 11.3 疑似コード
```python
def extract_pair_separation_profile(xa_of_z, xb_of_z, support_a, support_b):
    support = support_a & support_b
    sep = np.full_like(xa_of_z, np.nan, dtype=np.float32)
    sep[support] = np.abs(xb_of_z[support] - xa_of_z[support])
    return sep, support
```

## 11.4 注意
- `curve_a`, `curve_b` の pairing は upstream で決める
- process-specific 命名はここに入れない
- `gap` / `thickness` は caller が命名する

---

## 12. `extract_corners`

## 12.1 目的
top / bottom の局所 edge 情報を descriptor 化する。

## 12.2 手順
1. contour を arc-length 一様再サンプル  
2. centerline か bbox 中心で左右に分割  
3. top / bottom window を切る  
4. 各 window で高曲率点を探す  
5. tangent / curvature / radius_like を算出  
6. support / confidence を付ける  

## 12.3 疑似コード
```python
def extract_corners(contour_xy, *, top_window_nm, bottom_window_nm, smoothing_sigma_nm):
    contour = resample_polyline(contour_xy, step_nm=1.0)
    contour = smooth_polyline(contour, sigma_nm=smoothing_sigma_nm)

    y_min, y_max = contour[:, 1].min(), contour[:, 1].max()
    y_top_thr = y_min + top_window_nm
    y_bot_thr = y_max - bottom_window_nm
    x_mid = 0.5 * (contour[:, 0].min() + contour[:, 0].max())

    segments = {
        "top_left": contour[(contour[:,1] <= y_top_thr) & (contour[:,0] <= x_mid)],
        "top_right": contour[(contour[:,1] <= y_top_thr) & (contour[:,0] >  x_mid)],
        "bottom_left": contour[(contour[:,1] >= y_bot_thr) & (contour[:,0] <= x_mid)],
        "bottom_right": contour[(contour[:,1] >= y_bot_thr) & (contour[:,0] >  x_mid)],
    }

    out = {}
    for name, seg in segments.items():
        if len(seg) < 5:
            out[name] = missing_corner_descriptor(name)
            continue

        kappa = estimate_polyline_curvature(seg)
        idx = robust_argmax_abs(kappa)
        pos = seg[idx]
        tangent = estimate_tangent_angle(seg, idx)
        radius = 1.0 / max(abs(kappa[idx]), 1e-6)

        out[name] = CornerDescriptor(
            name=name,
            position_nm=(float(pos[0]), float(pos[1])),
            tangent_angle_deg=float(tangent),
            curvature_inv_nm=float(kappa[idx]),
            radius_like_nm=float(radius),
            confidence=estimate_corner_confidence(seg, idx),
            support_count=len(seg),
        )

    return CornerBundle(corners=out)
```

---

## 13. `field_loss`

## 13.1 目的
距離場の差を比較する。

## 13.2 band mask
`band_mode` の例:
- `union`: 両者の narrow band の和
- `intersection`: 共通 narrow band
- `ref_only`: 参照側のみ

## 13.3 疑似コード
```python
def field_loss(pred_d, ref_d, *, band_nm, band_mode, robust, scale_nm):
    pred_band = np.abs(pred_d) <= band_nm
    ref_band = np.abs(ref_d) <= band_nm

    if band_mode == "union":
        support = pred_band | ref_band
    elif band_mode == "intersection":
        support = pred_band & ref_band
    elif band_mode == "ref_only":
        support = ref_band
    else:
        raise ValueError(...)

    delta = (pred_d - ref_d) / scale_nm
    loss_map = robust_fn(delta, kind=robust)
    value = np.mean(loss_map[support])

    return MetricComponent(
        name="field",
        value=float(value),
        unit="normalized",
        support={"pixels_used": int(support.sum()), "band_nm": float(band_nm)},
    )
```

---

## 14. `curve_loss`

## 14.1 目的
境界位置そのものの差を比較する。

## 14.2 推奨
- symmetric Chamfer
- HD95
- 1 component に diagnostics として両方保存

## 14.3 疑似コード
```python
def curve_loss(pred_pts, ref_pts):
    d_pr = nearest_neighbor_distance(pred_pts, ref_pts)
    d_rp = nearest_neighbor_distance(ref_pts, pred_pts)

    chamfer = 0.5 * (d_pr.mean() + d_rp.mean())
    hd95 = max(np.percentile(d_pr, 95), np.percentile(d_rp, 95))

    value = chamfer + 0.25 * hd95
    return MetricComponent(
        name="curve",
        value=float(value),
        unit="nm",
        diagnostics={"chamfer_nm": float(chamfer), "hd95_nm": float(hd95)},
        support={"points_pred": len(pred_pts), "points_ref": len(ref_pts)},
    )
```

---

## 15. `profile_loss`

## 15.1 目的
深さ方向関数の差を比較する。

## 15.2 疑似コード
```python
def profile_loss(pred_bundle, ref_bundle, *, robust, per_function_scale):
    out = {}
    for name, pred_vals in pred_bundle.values.items():
        if name not in ref_bundle.values:
            continue

        ref_vals = ref_bundle.values[name]
        pred_sup = pred_bundle.support_mask.get(name, np.isfinite(pred_vals))
        ref_sup = ref_bundle.support_mask.get(name, np.isfinite(ref_vals))
        support = pred_sup & ref_sup & np.isfinite(pred_vals) & np.isfinite(ref_vals)

        if support.sum() == 0:
            out[name] = missing_metric_component(name)
            continue

        scale = per_function_scale.get(name, 1.0)
        delta = (pred_vals[support] - ref_vals[support]) / scale
        value = robust_fn(delta, kind=robust).mean()

        out[name] = MetricComponent(
            name=name,
            value=float(value),
            unit="normalized",
            support={"valid_depth_count": int(support.sum())},
        )
    return out
```

---

## 16. `corner_loss`

## 16.1 目的
角部位置・接線・半径様量の差を比較する。

## 16.2 疑似コード
```python
def corner_loss(pred_corners, ref_corners, *, position_scale_nm, angle_scale_deg, radius_scale_nm, robust):
    out = {}
    for name in ["top_left", "top_right", "bottom_left", "bottom_right"]:
        p = pred_corners[name]
        r = ref_corners[name]
        if p.confidence <= 0.0 or r.confidence <= 0.0:
            out[name] = missing_metric_component(name)
            continue

        dp = l2(p.position_nm, r.position_nm) / position_scale_nm
        da = abs(angle_diff_deg(p.tangent_angle_deg, r.tangent_angle_deg)) / angle_scale_deg
        dr = abs(p.radius_like_nm - r.radius_like_nm) / radius_scale_nm

        value = robust_fn(np.array([dp, da, dr]), kind=robust).mean()

        out[name] = MetricComponent(
            name=name,
            value=float(value),
            unit="normalized",
            support={
                "confidence_pred": float(p.confidence),
                "confidence_ref": float(r.confidence),
            },
        )
    return out
```

---

## 17. `similarity2d_alignment`

## 17.1 目的
simulation 観測と SEM 観測の座標ずれを minimal に補正する。

## 17.2 変換
\[
\mathbf{x}' = s R(\theta)\mathbf{x} + \mathbf{t}
\]

### 自由度
- scale `s`
- rotation `theta`
- translation `t`

## 17.3 手順
1. まず centroid で初期化  
2. 必要なら contour-based least squares で refine  
3. 変換後の grid / origin を更新  
4. transform を `Obs2D.meta` に保存  

---

## 18. `build_metric_bundle`

## 18.1 目的
component metric を収集し、最後に total を構成する。

## 18.2 疑似コード
```python
def build_metric_bundle(field_comp, curve_comp, profile_comp, corner_comp, weights):
    total = 0.0

    for comp in field_comp.values():
        total += weights["field"] * comp.value

    for comp in curve_comp.values():
        total += weights["curve"] * comp.value

    for comp in profile_comp.values():
        total += weights["profile"] * comp.value

    for comp in corner_comp.values():
        total += weights["corner"] * comp.value

    return MetricBundle(
        field=field_comp,
        curve=curve_comp,
        profile=profile_comp,
        corner=corner_comp,
        total=MetricComponent(name="total", value=float(total), unit="normalized", support={}),
    )
```

---

## 19. synthetic golden を作るときのコツ

### 19.1 최소 golden
- rectangle
- bowing
- rounded bottom
- overhang

### 19.2 検証したい傾向
- bowing で `width(z)` が中央で大きくなる
- rounded bottom で bottom corner radius が小さくなる
- overhang で top corner と `gap(z)` が変わる
- CD だけでは区別できない pair が、profile/corner では区別できる

---

## 20. 実装順の推奨

1. `build_field3d_from_labels`
2. `build_distance_views`
3. `observe_topdown_exposed`
4. `observe_slice`
5. `contour_from_obs2d`
6. `extract_width_profile`
7. `extract_wall_angle_profile`
8. `extract_curvature_profile`
9. `extract_corners`
10. `field_loss`
11. `curve_loss`
12. `profile_loss`
13. `corner_loss`
14. `build_metric_bundle`
15. `similarity2d_alignment`

この順で進めると、途中段階でも artifact と test を積み上げやすいです。

---

## 21. 本章の結論

本章にある疑似コードは、そのまま production code ではありません。  
ただし、次の点はそのまま設計契約として採用できます。

- 入出力 shape
- canonical / view / observation の境界
- support mask の考え方
- component metric の分け方
- fail-fast すべき条件

つまり、ここで定義した粒度まで落とせていれば、  
実装チームが別れても「同じものを作る」確率がかなり上がります。
