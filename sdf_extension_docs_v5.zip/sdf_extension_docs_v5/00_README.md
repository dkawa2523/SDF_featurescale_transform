# SDF extension docs v5

この bundle は、`dkawa2523/SDF_featurescale_transform` を
**raw SDF canonical / generic observer / MetricBundle / surrogate export** へ拡張するための
設計 docs、Codex prompt pack、optimized AGENTS/skills、そして **実コード差分のスケルトン一式** をまとめたものです。

## v5 で新しく追加したもの

- `22_repo_patch_skeleton_overview.md`
  - 実コードスケルトンの使い方、適用順、integration note
- `23_agents_and_skills_optimization_notes.md`
  - root AGENTS を短い map にし、nested AGENTS と modular skill に分けた理由
- `24_subagent_role_specs.md`
  - 並列タスク向け role / handoff / deliverable の標準仕様
- `repo_patch_skeleton/`
  - 既存 repo に重ねる **overlay 形式** のコードスケルトン
  - nested `AGENTS.md`
  - `docs/sdf_extension/` knowledge base
  - `wafergeo/` 以下の new modules
  - `tests/` の synthetic / unit skeleton
- `codex_assets/skills/` の全面刷新
  - trigger quality を上げた `SKILL.md`
  - task area ごとの分割
- `codex_assets/subagents/`
  - architect / field / observe / metrics / tests-docs の subagent spec
- `codex_assets/prompts/95-99_*.md`
  - overlay 適用、agents/skills 導入、parallel wave 実行、最終検証 prompt

## 推奨の読み順

1. `SDF_featurescale_transform_extension_full_report.md`
2. `02_extension_principles_and_design.md`
3. `03_methods_field_observer_metric.md`
4. `04_repo_modifications_implementation_plan.md`
5. `11_algorithm_specs_and_pseudocode.md`
6. `13_public_api_contracts.md`
7. `22_repo_patch_skeleton_overview.md`
8. `repo_patch_skeleton/README.md`
9. `23_agents_and_skills_optimization_notes.md`
10. `24_subagent_role_specs.md`

## 使い方

### A. 人間が設計を読む
- v3 docs 群（01〜13）と統合版を読む

### B. Codex に実装を進めさせる
- `codex_assets/AGENTS.md`
- `codex_assets/prompts/*.md`
- `codex_assets/skills/*/SKILL.md`
- `codex_assets/subagents/*.md`

### C. 既存 repo に overlay を入れて着手する
- `repo_patch_skeleton/overlay/` を repo root に重ねる
- root / nested `AGENTS.md` を有効化する
- `docs/sdf_extension/` を repo 内 knowledge base として使う
- additive file から順に merge する

## 主要ファイル

### 設計 docs
- `01_current_repo_analysis.md`
- `02_extension_principles_and_design.md`
- `03_methods_field_observer_metric.md`
- `04_repo_modifications_implementation_plan.md`
- `05_data_assimilation_surrogate_future.md`
- `06_reference_catalog.md`
- `07_appendix_example_specs_and_reports.md`
- `08_role_based_review.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `11_algorithm_specs_and_pseudocode.md`
- `12_third_party_handbook_and_examples.md`
- `13_public_api_contracts.md`

### Codex / agents / skills
- `14_codex_prompt_pack_overview.md`
- `15_codex_orchestration_and_parallel_roles.md`
- `16_codex_setup_mcp_network_and_safety.md`
- `17_codex_AGENTS_and_repo_instructions.md`
- `18_codex_skills_and_prompt_assets.md`
- `19_codex_prompt_index.md`
- `20_codex_execution_runbooks.md`
- `21_codex_reference_catalog.md`
- `23_agents_and_skills_optimization_notes.md`
- `24_subagent_role_specs.md`

### 実コードスケルトン
- `22_repo_patch_skeleton_overview.md`
- `repo_patch_skeleton/README.md`
- `repo_patch_skeleton/overlay/AGENTS.md`
- `repo_patch_skeleton/overlay/docs/sdf_extension/*`
- `repo_patch_skeleton/overlay/wafergeo/**/*`
- `repo_patch_skeleton/overlay/tests/**/*`

## 注意

- `repo_patch_skeleton` は **すべてが即 merge-ready な完成実装** ではありません。
  - additive new module はかなり具体的に実装
  - 既存 module との wiring は integration note を併読
  - 일부 function は intentionally TODO / stub を残しています
- AGENTS は intentionally 短くしています。
  詳説は repo 内 `docs/sdf_extension/` とこの docs bundle に置く前提です。
