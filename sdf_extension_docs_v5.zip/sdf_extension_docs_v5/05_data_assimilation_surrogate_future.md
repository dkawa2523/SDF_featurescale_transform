# 05. データ同化・サロゲート・将来技術

本章では、拡張版基盤が downstream に何をもたらすかを整理します。  
焦点は **「この repo 自体が学習器になること」ではなく、学習器・同化器・将来 digital twin の土台になること」** です。

---

## 1. 本章の結論

### 1.1 repo の本質
この repo の本質は **学習モデル** ではなく、

- geometry canonical
- observation layer
- objective layer
- teacher export layer

です。

### 1.2 なぜ価値が高いか
サロゲートや同化で本当に重いのは、しばしばモデルコードではなく、

- 形状表現の一貫性
- 実測との比較ドメイン
- 再利用可能な教師形式
- failure analysis のしやすさ

だからです。

### 1.3 推奨 stance
- まず exact geometry teacher を強くする
- 次に export を増やす
- その上で downstream モデルを選ぶ

---

## 2. データ同化への価値

## 2.1 現状 objective の良い点
CD は現場で説明しやすく、line/space 的な profile の整合には強いです。

## 2.2 しかし不足する場面
以下のようなケースでは、CD 単独は不十分です。

- bottom rounding が違う
- foot/notch が違う
- sidewall angle が違う
- overhang / closure が違う
- seam / void 兆候が違う

## 2.3 拡張後 objective
component を分けて持ちます。

- `field`
- `curve`
- `profile`
- `corner`
- `topology(optional)`

## 2.4 何が良くなるか
- optimizer が意味のある差に反応しやすい
- tuning の方向が見えやすい
- 結果の説明責任を果たしやすい
- 現象ごとの regression がしやすい

---

## 3. 同化レポートの説明性

### 3.1 単一 scalar loss の問題
単一 loss 値だけだと、
- なぜ悪いのか
- どこが悪いのか
- 何を直せば良いのか
が見えません。

### 3.2 component breakdown の価値
| component | 説明 |
|---|---|
| `field` | boundary 近傍全体の位置差 |
| `curve` | contour の純粋なズレ |
| `profile` | width/angle/thickness/gap などの関数差 |
| `corner` | edge/corner の局所差 |
| `topology` | open/closed/connectivity |

### 3.3 実務価値
- process engineer が「どの現象が悪いか」を読める
- data scientist が objective を分解して改善できる
- optimizer の探索方向を説明しやすい

---

## 4. サロゲートへの価値

## 4.1 学習実装が無くても価値が高い理由
将来モデルは変わります。  
しかし teacher data を毎回作り直すのは高コストです。  
そのため、同じ sample から複数の教師形式を生成できる基盤は非常に価値があります。

## 4.2 拡張版で出せる教師形式

| 形式 | 用途 | 強み |
|---|---|---|
| dense raw SDF / TSDF views | 3D CNN / voxel | baseline が簡単 |
| point-query SDF/UDF | implicit network | 連続 query に向く |
| mesh / point cloud | point / graph / mesh model | surface 中心で効率的 |
| Obs2D bundle | 2D surrogate / same-domain comparison | SEM と整合しやすい |
| profile curves | GP / BO / XGBoost / tabular | explainable で少量データに強い |

---

## 5. 推奨 export パッケージ

```mermaid
flowchart TD
    A[Field3D] --> B[dense tensor export]
    A --> C[point-query export]
    A --> D[mesh / point export]
    A --> E[Obs2D bundle export]
    A --> F[profile curve export]

    B --> G[3D CNN / U-Net]
    C --> H[Hash-grid INR / neural SDF]
    D --> I[Point Transformer / GNN / MeshGraphNets]
    E --> J[2D surrogate / assimilation]
    F --> K[GP / BO / lightweight regressors]
```

---

## 6. サロゲートモデル候補の整理

## 6.1 dense volume 系
### 代表
- 3D CNN
- 3D U-Net
- hybrid voxel encoder

### 向く場面
- grid が比較的小さい
- 座標系が揃っている
- baseline を早く作りたい

### コメント
最初の surrogate baseline としては非常に現実的です。  
拡張版 repo では `tsdf_small/mid/large` を channel に持たせるだけでかなり使いやすくなります。

---

## 6.2 implicit / neural SDF 系
### 代表
- hash-grid neural SDF
- tri-plane
- coordinate MLP
- Neuralangelo 系
- SDFStudio 系

### 強み
- compact
- continuous query
- subvoxel detail に強い
- mesh extraction と相性が良い

### 注意
これらは **repo core に入れるべきではありません**。  
repo は point-query export を整え、teacher を供給する側に回るのが正解です。

---

## 6.3 UDF 系
### 代表
- NeuralUDF
- NeUDF
- CAP-UDF 系列

### 向く場面
- open contour
- partial observation
- non-watertight geometry
- SEM 由来 incomplete contour

### コメント
simulation 側が SDF、SEM 側が UDF でも、observer で比較ドメインを揃えれば十分運用できます。

---

## 6.4 point-based 系
### 代表
- PointNet++
- Point Transformer V3
- NoKSR 系

### 向く場面
- voxel を避けたい
- surface point sampling がしやすい
- mesh/contour point ベースで学びたい

### コメント
特に NoKSR 系は「点群から multi-scale aggregation で SDF を作る」方向性が面白く、  
輪郭点群や sparse geometry observation との相性が良いです。

---

## 6.5 mesh / graph 系
### 代表
- MeshGraphNets
- graph neural simulators

### 向く場面
- boundary representation を直接扱いたい
- dynamic profile evolution を学びたい
- adaptive mesh と親和的な surrogate を作りたい

### コメント
repo が mesh export を持っていれば、将来の動的 surrogate へ拡張しやすいです。

---

## 6.6 neural operator 系
### 代表
- FNO
- Geo-FNO
- boundary-based / geometry-adaptive operator 系

### 向く場面
- `initial geometry + recipe + BC -> final field`
- 条件から形状場全体を学びたい
- PDE family 的 surrogate を作りたい

### コメント
digital twin の文脈では非常に有望です。  
ただしこれも repo core ではなく downstream です。

---

## 6.7 lightweight / explainable surrogate
### 代表
- GP
- XGBoost
- tabular MLP
- Bayesian optimization surrogate

### 入力
- profile curves の summary
- width / angle / thickness / gap の特徴量
- recipe metadata

### コメント
これは industrial adoption がしやすく、  
少量データ・高説明性の観点で今でも非常に有用です。

---

## 7. 将来有望技術の位置づけ

## 7.1 exact EDT / exact GPU EDT
### 優先度: 高
これは将来技術というより、基盤の完成度の話です。  
teacher / objective の正しさを支える土台です。

## 7.2 multi-resolution hash-grid neural SDF
### 優先度: 中〜高（downstream）
高精細 surface surrogate として有望。  
ただし core へ入れるのではなく export 接続で十分です。

## 7.3 UDF-based neural reconstruction / rendering
### 優先度: 中
SEM open contour や partial observation が多い場合に重要。  
SDF 一本化が難しいケースの逃げ道になります。

## 7.4 point serialization / sparse point methods
### 優先度: 中
NoKSR のように irregular point cloud から multi-scale aggregation で SDF へ持ち上げる方向は、  
輪郭・点群中心の downstream で有望です。

## 7.5 adaptive SDF storage
### 優先度: 中
巨大 3D で dense tensor が重いときに有効。  
ただし canonical / observer / metric を固めた後でよいです。

## 7.6 differentiable rendering / image formation
### 優先度: 低（core では非推奨）
将来的には興味深いですが、
- 物理仮定が重い
- 装置依存が強い
- core の責務から外れやすい
ため、今は入れない方がよいです。

## 7.7 simulation-guided digital twin
### 優先度: system-level future
2025–2026 では、TCAD + neural operator + transfer learning を組み合わせた digital twin が強い流れです。  
本 repo はその「本体」ではありませんが、**geometry teacher / observation / objective 層** として中核的価値を持ちます。

---

## 8. 最新技術の成熟度マトリクス

| 技術 | 役割 | 成熟度 | 本 repo への位置づけ |
|---|---|---:|---|
| SciPy exact EDT | canonical distance | 高 | core |
| ITK Maurer exact EDT | optional exact backend | 中 | optional core backend |
| CuPy exact EDT | optional GPU backend | 中 | optional core backend |
| Neuralangelo 型 hash-grid SDF | compact surface surrogate | 中〜高 | downstream |
| SDFStudio | implicit reconstruction framework | 中 | downstream reference |
| NeuralUDF / NeUDF | open-surface reconstruction | 中 | downstream / SEM route |
| NoKSR | point→SDF reconstruction | 中 | downstream |
| Geo-FNO | geometry-aware operator learning | 中 | downstream advanced |
| ViscoReg | neural SDF 学習安定化 | 低〜中 | research watchlist |
| digital twin (STwinner系) | system-level recipe optimization | 中 | system integration future |

---

## 9. 実務導入の段階案

| Stage | 目的 | repo 側の扱い |
|---|---|---|
| Stage 1 | exact field + Obs2D bundle | core |
| Stage 2 | profile/corner losses + SEM unsigned route | core |
| Stage 3 | dense/query/mesh/profile exports | core |
| Stage 4 | 3D CNN / point / mesh surrogate | downstream |
| Stage 5 | neural SDF/UDF / Geo-FNO / NoKSR | downstream advanced |
| Stage 6 | digital twin / adaptive control | system-level |

---

## 10. 今やるべきこと / 今はやらないこと

### 今やる
- geometry canonical の品質改善
- objective の表現改善
- export の多様化

### 今はやらない
- neural training framework 実装
- process-specific model zoo
- end-to-end SEM image simulator
- 過度に自由な registration

---

## 11. 本章の結論

この repo の将来価値は、  
**「SDF そのもの」ではなく、「正しい geometry teacher と observation/objective layer をいろいろな downstream に供給できること」** にあります。

そのための最良戦略は次です。

1. core はシンプルに
2. geometry / observer / metric を強く
3. export は豊かに
4. process 分岐は増やさない

これが、データ同化にもサロゲートにも最も効く進め方です。
