# status matrix

| file area | status | note |
|---|---|---|
| `overlay/AGENTS.md` | ready | root map としてそのまま置ける |
| `overlay/docs/sdf_extension/*` | ready | repo knowledge base としてそのまま置ける |
| nested `AGENTS.md` | ready | scope-specific rules |
| `wafergeo/sdf/distance_api.py` | high | existing registry / edt facade と繋ぎやすい |
| `wafergeo/core/roles.py` | high | additive で導入しやすい |
| `wafergeo/core/views.py` | high | additive で導入しやすい |
| `wafergeo/core/field3d.py` | medium-high | existing types / meta との wiring が必要 |
| `wafergeo/observe/contracts.py` | high | additive contracts |
| `wafergeo/observe/profiles.py` | high | pure numpy center |
| `wafergeo/observe/corners.py` | high | profile-based descriptor |
| `wafergeo/sem/obs2d_from_contour.py` | high | pure numpy unsigned route が中心 |
| `wafergeo/metrics/*.py` | high | additive metrics skeleton |
| `wafergeo/surrogate/export_v2.py` | medium-high | manifest naming 調整が必要 |
| `tests/*.py` | high | optional dependency isolation を意識 |
