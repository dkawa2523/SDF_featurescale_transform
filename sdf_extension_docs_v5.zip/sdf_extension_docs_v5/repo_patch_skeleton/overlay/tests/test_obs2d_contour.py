from __future__ import annotations

import numpy as np

from wafergeo.sem.obs2d_from_contour import build_obs2d_from_contours


def test_unsigned_contour_distance_smoke() -> None:
    contour = np.array([[1.0, 1.0], [3.0, 1.0], [3.0, 3.0]], dtype=np.float32)
    obs = build_obs2d_from_contours([contour], grid_shape_yx=(5, 5), spacing_nm_yx=(1.0, 1.0))
    assert obs.distance2d_nm.shape == (5, 5)
    assert obs.meta['distance_semantics'] == 'unsigned'
    assert obs.contours_xy_nm is not None


def test_signed_contour_route_requires_mask() -> None:
    contour = np.array([[1.0, 1.0], [3.0, 1.0]], dtype=np.float32)
    mask = np.zeros((5, 5), dtype=bool)
    mask[2:4, 2:4] = True
    obs = build_obs2d_from_contours([contour], grid_shape_yx=(5, 5), spacing_nm_yx=(1.0, 1.0), signed=True, mask2d=mask)
    assert obs.meta['distance_semantics'] == 'signed'
    assert np.any(obs.distance2d_nm < 0)
