from __future__ import annotations

import numpy as np

from wafergeo.observe.contracts import Obs2D
from wafergeo.observe.corners import build_corner_bundle_from_obs2d
from wafergeo.observe.profiles import build_profile_bundle_from_obs2d


def _rect_obs() -> Obs2D:
    mask = np.zeros((6, 6), dtype=bool)
    mask[1:5, 2:4] = True
    distance = np.where(mask, -1.0, 1.0).astype(np.float32)
    return Obs2D(
        grid2d_shape_yx=(6, 6),
        spacing_nm_yx=(1.0, 1.0),
        origin_nm_yx=(0.0, 0.0),
        axis_order='yx',
        distance2d_nm=distance,
        mask2d=mask,
        meta={'distance_semantics': 'signed'},
    )


def test_profiles_from_obs2d() -> None:
    obs = _rect_obs()
    bundle = build_profile_bundle_from_obs2d(obs)
    assert 'width_nm' in bundle.values
    assert np.nanmax(bundle.values['width_nm']) > 0


def test_corners_from_obs2d() -> None:
    obs = _rect_obs()
    corners = build_corner_bundle_from_obs2d(obs)
    assert set(corners.corners) == {'top_left', 'top_right', 'bottom_left', 'bottom_right'}
