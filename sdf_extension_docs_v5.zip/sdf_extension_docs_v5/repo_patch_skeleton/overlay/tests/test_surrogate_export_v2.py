from __future__ import annotations

import numpy as np

from wafergeo.core.field3d import Field3D, GridMeta
from wafergeo.core.roles import RoleSpec
from wafergeo.core.views import DistanceViews
from wafergeo.observe.contracts import Obs2D
from wafergeo.surrogate.export_v2 import export_dataset_package_v2


def _field() -> Field3D:
    sdf = np.zeros((2, 1, 2, 2), dtype=np.float32)
    return Field3D(
        grid=GridMeta(shape_zyx=(1, 2, 2), spacing_nm_zyx=(1.0, 1.0, 1.0), origin_nm_zyx=(0.0, 0.0, 0.0)),
        roles=RoleSpec(raw_material_to_role={0: 0, 1: 1}, role_id_to_name={0: 'void', 1: 'target'}, void_role_id=0),
        sdf_nm=sdf,
        meta={'distance_semantics': 'signed', 'role_id_order': [0, 1]},
    )


def test_export_dataset_package_v2(tmp_path) -> None:
    field = _field()
    obs = Obs2D(
        grid2d_shape_yx=(2, 2),
        spacing_nm_yx=(1.0, 1.0),
        origin_nm_yx=(0.0, 0.0),
        axis_order='yx',
        distance2d_nm=np.zeros((2, 2), dtype=np.float32),
        meta={'distance_semantics': 'signed'},
    )
    views = DistanceViews(meta={'distance_semantics': 'signed'})
    pkg = export_dataset_package_v2(tmp_path, 'sample-001', field, views=views, observations={'center': obs})
    manifest = tmp_path / 'sample-001' / 'manifest.json'
    assert manifest.exists()
    assert pkg.entry.sample_id == 'sample-001'
