# AGENTS.md for tests/

## Rules
- tests must be deterministic and tiny
- isolate optional dependency paths
- assert units / shapes / semantics, not only smoke behavior
- prefer hand-checkable synthetic fixtures
