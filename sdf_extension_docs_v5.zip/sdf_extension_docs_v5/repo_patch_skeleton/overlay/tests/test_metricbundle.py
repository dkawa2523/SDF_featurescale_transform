from __future__ import annotations

import numpy as np

from wafergeo.metrics.bundle import build_metric_bundle, scalarize_metric_bundle
from wafergeo.observe.contracts import Obs2D


def _obs(width_shift: int = 0) -> Obs2D:
    mask = np.zeros((8, 8), dtype=bool)
    mask[2:6, 2 + width_shift:5 + width_shift] = True
    distance = np.where(mask, -1.0, 1.0).astype(np.float32)
    contour = [np.array([[2.0 + width_shift, 2.0], [5.0 + width_shift, 2.0], [5.0 + width_shift, 6.0]], dtype=np.float32)]
    return Obs2D(
        grid2d_shape_yx=(8, 8),
        spacing_nm_yx=(1.0, 1.0),
        origin_nm_yx=(0.0, 0.0),
        axis_order='yx',
        distance2d_nm=distance,
        mask2d=mask,
        contours_xy_nm=contour,
        meta={'distance_semantics': 'signed'},
    )


def test_metricbundle_smoke() -> None:
    pred = _obs(width_shift=1)
    tgt = _obs(width_shift=0)
    bundle = build_metric_bundle(pred, tgt)
    assert bundle.field
    assert bundle.profile
    total = scalarize_metric_bundle(
        bundle,
        normalizers={
            'field.default': 1.0,
            'curve.curve_chamfer': 1.0,
            'curve.curve_tail_p95': 1.0,
            'profile.width_nm': 1.0,
            'profile.left_edge_x_nm': 1.0,
            'profile.right_edge_x_nm': 1.0,
            'corner.corner_position_mae': 1.0,
            'corner.corner_angle_mae': 1.0,
            'corner.corner_radius_mae': 1.0,
        },
    )
    assert np.isfinite(total.value)
