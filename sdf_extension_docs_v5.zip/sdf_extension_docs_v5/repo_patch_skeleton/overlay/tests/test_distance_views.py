from __future__ import annotations

import numpy as np

from wafergeo.core.field3d import Field3D, GridMeta
from wafergeo.core.roles import RoleSpec
from wafergeo.core.views import ViewSpec, build_distance_views


def _toy_field() -> Field3D:
    sdf = np.array(
        [
            [[[ -2.0, -1.0], [1.0, 2.0]]],
            [[[ 2.0, 1.0], [-1.0, -2.0]]],
        ],
        dtype=np.float32,
    )
    return Field3D(
        grid=GridMeta(shape_zyx=(1, 2, 2), spacing_nm_zyx=(1.0, 1.0, 1.0), origin_nm_zyx=(0.0, 0.0, 0.0)),
        roles=RoleSpec(raw_material_to_role={0: 0, 1: 1}, role_id_to_name={0: 'void', 1: 'target'}, void_role_id=0),
        sdf_nm=sdf,
        meta={'distance_semantics': 'signed', 'role_id_order': [0, 1]},
    )


def test_build_distance_views_ranges() -> None:
    field = _toy_field()
    views = build_distance_views(field, ViewSpec(tsdf_mu_nm={'mid': 2.0}, tanh_mu_nm={'mid': 2.0}))
    tsdf = views.tsdf_views['mid']
    assert tsdf.shape == field.sdf_nm.shape
    assert np.all(tsdf <= 1.0 + 1e-6)
    assert np.all(tsdf >= -1.0 - 1e-6)
    sign, mag = views.logsigned_views['default']
    assert sign.shape == field.sdf_nm.shape
    assert mag.shape == field.sdf_nm.shape
