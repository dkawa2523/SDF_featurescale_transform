from __future__ import annotations

import numpy as np

from wafergeo.core.field3d import FieldBuilderConfig, build_field3d_from_label_volume
from wafergeo.core.grid import GridSpec
from wafergeo.core.meta import Meta
from wafergeo.core.roles import minimal_role_spec_from_material
from wafergeo.core.types import LabelVolume, MaterialSpec


class _FakeDistance:
    @staticmethod
    def signed(mask, spacing_nm, **kwargs):
        out = np.where(mask, -1.0, 1.0).astype(np.float32)
        return out

    @staticmethod
    def unsigned(mask, spacing_nm, **kwargs):
        return np.where(mask, 0.5, 1.5).astype(np.float32)


def test_build_field3d_from_label_volume(monkeypatch) -> None:
    import wafergeo.core.field3d as mod

    monkeypatch.setattr(mod, 'signed_distance_nm', _FakeDistance.signed)
    monkeypatch.setattr(mod, 'unsigned_distance_nm', _FakeDistance.unsigned)

    label = LabelVolume(
        grid=GridSpec(dim=3, spacing=(1.0, 2.0, 3.0), origin=(0.0, 0.0, 0.0), axis_order='ZYX', sample_location='cell_center', units='nm'),
        material=MaterialSpec(ids=[0, 1], names=['void', 'mat'], void_id=0, priority=[0, 1], ignore_in_exposure=[False, False]),
        material_id=np.array([[[0, 1], [1, 0]]], dtype=np.int16),
        meta=Meta(schema_version='x', profile_id='x', config_hash='x', generator_version='x', git_commit='x', input_hash='x', created_at='2026-01-01T00:00:00+00:00'),
    )
    result = build_field3d_from_label_volume(
        label,
        role_spec=minimal_role_spec_from_material(label.material),
        cfg=FieldBuilderConfig(emit_udf=True, emit_scalar_fields=('nonvoid_mask', 'decoded_role_zyx')),
    )
    field = result.field
    assert field.sdf_nm.shape == (2, 1, 2, 2)
    assert field.udf_nm is not None
    assert field.meta['distance_semantics'] == 'signed'
    assert 'nonvoid_mask' in field.scalar_fields
