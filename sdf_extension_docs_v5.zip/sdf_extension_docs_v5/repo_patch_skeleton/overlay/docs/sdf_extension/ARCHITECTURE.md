# architecture

## core idea
- canonical geometry = raw signed distance (`Field3D.sdf_nm`)
- derived views = TSDF / tanh / logsigned
- unified observation = `Obs2D`
- unified comparison = `MetricBundle`
- surrogate export = dataset package V2

## main layers
```text
LabelVolume / Mesh / Contours
  -> Field3D / Obs2D
  -> ProfileBundle / CornerBundle
  -> MetricBundle
  -> Assimilation / Surrogate export
```

## anti-goals
- process-specific core API explosion
- hidden fallback for unsupported capabilities
- monolithic scalar loss without diagnostics
