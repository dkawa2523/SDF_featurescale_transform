# SDF extension knowledge base

この docs は repo 内 knowledge base として使うための **短い source of truth** です。

## 読み順
- `ARCHITECTURE.md`
- `API_CONTRACTS.md`
- `IMPLEMENTATION_WAVES.md`
- `TEST_STRATEGY.md`

## ルール
- root AGENTS には map だけを書く
- 詳説はここに書く
- code を変えたら relevant doc も更新する
