# implementation waves

## wave 1
- AGENTS / docs knowledge base
- distance facade
- role mapping
- Field3D
- DistanceViews

## wave 2
- Obs2D contract
- contour distance route
- profiles
- corners

## wave 3
- MetricBundle
- scalarization hook
- surrogate export V2
- tests / docs sync
