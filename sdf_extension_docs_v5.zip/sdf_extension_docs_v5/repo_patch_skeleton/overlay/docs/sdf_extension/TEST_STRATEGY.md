# test strategy

## always test
- sign convention
- anisotropic spacing
- role order stability
- distance view range
- signed / unsigned Obs2D semantics
- profile extraction on tiny masks
- corner extraction on tiny masks
- metric component support behavior
- export manifest completeness

## keep tests tiny
- 2D or 3D toy arrays
- no large SEM images
- optional dependency paths isolated from default tests
