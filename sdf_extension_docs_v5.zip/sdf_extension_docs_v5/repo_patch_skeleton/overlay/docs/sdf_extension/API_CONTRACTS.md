# api contracts (short form)

## shapes / units
- 3D volume: `[Z,Y,X]`
- role stack: `[R,Z,Y,X]`
- 2D map: `[Y,X]`
- contour: `[N,2]` in `(x_nm, y_nm)`
- public unit: `nm`

## mandatory semantics
- every distance artifact must declare `distance_semantics`
- role order must be explicit

## core types
- `RoleSpec`
- `Field3D`
- `DistanceViews`
- `Obs2D`
- `ProfileBundle`
- `CornerBundle`
- `MetricBundle`
