# AGENTS.md

This repository extends `SDF_featurescale_transform` toward a generic, simple geometry foundation.

## Read first
- `docs/sdf_extension/ARCHITECTURE.md`
- `docs/sdf_extension/API_CONTRACTS.md`
- `docs/sdf_extension/IMPLEMENTATION_WAVES.md`
- `docs/sdf_extension/TEST_STRATEGY.md`

## Non-negotiable invariants
1. canonical geometry is raw signed distance
2. TSDF is derived, not canonical
3. distance semantics must be explicit
4. no process-specific core API explosion
5. unsupported capability and no-op options must fail fast
6. docs and tests move with code

## Routing
- field/distance work: `wafergeo/sdf`, `wafergeo/core`
- observation/SEM work: `wafergeo/observe`, `wafergeo/sem`
- metrics work: `wafergeo/metrics`
- tests: `tests/`

## Working style
- prefer additive patches
- write the smallest good patch
- keep backward compatibility via shims
- summarize changed files, acceptance, tests, and risks at the end
