# AGENTS.md for wafergeo/sdf/

## Focus
Distance backends, sign semantics, spacing-aware geometry, derived TSDF views.

## Rules
- no hidden fallback to another backend
- expose exact vs approximate capability explicitly
- keep sign convention tested
- keep TSDF as derived view only
- preserve anisotropic spacing semantics
