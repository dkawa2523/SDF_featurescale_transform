from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from wafergeo.sdf.edt import edt_distance, signed_distance_from_mask
from wafergeo.sdf.engines.registry import get_sdf_engine, list_sdf_engines


@dataclass(frozen=True)
class DistanceBackendCaps:
    """Capability summary for an EDT backend.

    This is a thin, fail-fast facade over the existing registry so that callers do not
    have to know the internal engine protocol details.
    """

    name: str
    exact: bool
    supports_signed: bool
    supports_unsigned: bool
    supports_spacing: bool
    supports_gpu: bool
    supports_2d: bool
    supports_3d: bool
    deterministic: bool


@dataclass(frozen=True)
class DistanceBackendInfo:
    name: str
    version: str
    caps: DistanceBackendCaps
    method_card: dict[str, Any]


def _caps_from_engine(name: str) -> DistanceBackendCaps:
    engine = get_sdf_engine(name)
    caps = engine.capabilities
    return DistanceBackendCaps(
        name=name,
        exact=bool(caps.exact),
        supports_signed=True,
        supports_unsigned=True,
        supports_spacing=bool(caps.supports_anisotropic_spacing),
        supports_gpu=bool(caps.gpu_accelerated),
        supports_2d=bool(caps.supports_2d),
        supports_3d=bool(caps.supports_3d),
        deterministic=bool(caps.deterministic),
    )


def available_distance_backends() -> list[DistanceBackendCaps]:
    """Return actual, runtime-available backend capabilities.

    Important: registered != silently safe to use. Callers should inspect the returned
    capabilities and fail fast if they require exact behavior.
    """

    return [_caps_from_engine(name) for name in list_sdf_engines()]


def get_distance_backend_info(name: str) -> DistanceBackendInfo:
    engine = get_sdf_engine(name)
    return DistanceBackendInfo(
        name=engine.name,
        version=engine.version,
        caps=_caps_from_engine(name),
        method_card={
            "summary": engine.method_card.summary,
            "dependencies": list(engine.method_card.dependencies),
            "limitations": list(engine.method_card.limitations),
            "references": list(engine.method_card.references),
            "recommended_use_cases": list(engine.method_card.recommended_use_cases),
            "install_hint": engine.method_card.install_hint,
        },
    )


def require_backend(name: str, *, exact: bool | None = None, dim: int | None = None) -> None:
    caps = _caps_from_engine(name)
    if exact is True and not caps.exact:
        raise ValueError(f"backend '{name}' is not exact")
    if dim == 2 and not caps.supports_2d:
        raise ValueError(f"backend '{name}' does not support 2D input")
    if dim == 3 and not caps.supports_3d:
        raise ValueError(f"backend '{name}' does not support 3D input")


def _validate_mask_and_spacing(mask: np.ndarray, spacing_nm: tuple[float, ...]) -> np.ndarray:
    mask_bool = np.asarray(mask, dtype=bool)
    if mask_bool.ndim not in (2, 3):
        raise ValueError(f"mask must be 2D or 3D, got ndim={mask_bool.ndim}")
    if len(spacing_nm) != mask_bool.ndim:
        raise ValueError(
            f"spacing length must equal ndim: len(spacing_nm)={len(spacing_nm)} ndim={mask_bool.ndim}"
        )
    for i, value in enumerate(spacing_nm):
        if not np.isfinite(value) or value <= 0:
            raise ValueError(f"spacing_nm[{i}] must be finite and > 0, got {value}")
    return mask_bool


def signed_distance_nm(
    mask: np.ndarray,
    spacing_nm: tuple[float, ...],
    *,
    backend: str = "scipy",
    inside_negative: bool = True,
    require_exact: bool = False,
) -> np.ndarray:
    """Compute spacing-aware signed distance.

    `mask=True` is treated as the interior region. By default, interior distances are
    negative, matching the project-wide canonical convention.
    """

    mask_bool = _validate_mask_and_spacing(mask, spacing_nm)
    require_backend(backend, exact=require_exact, dim=mask_bool.ndim)
    phi = np.asarray(signed_distance_from_mask(mask_bool, spacing_nm, backend), dtype=np.float32)
    if not inside_negative:
        phi = -phi
    return phi


def unsigned_distance_nm(
    mask: np.ndarray,
    spacing_nm: tuple[float, ...],
    *,
    backend: str = "scipy",
    require_exact: bool = False,
) -> np.ndarray:
    """Return the unsigned distance to the interface of a binary region.

    The implementation uses the existing backend's EDT route on `mask` and `~mask`, then
    selects the relevant side per voxel so the result is distance-to-boundary everywhere.
    """

    mask_bool = _validate_mask_and_spacing(mask, spacing_nm)
    require_backend(backend, exact=require_exact, dim=mask_bool.ndim)
    inside = np.asarray(edt_distance(mask_bool, spacing_nm, backend), dtype=np.float32)
    outside = np.asarray(edt_distance(~mask_bool, spacing_nm, backend), dtype=np.float32)
    return np.where(mask_bool, inside, outside).astype(np.float32, copy=False)
