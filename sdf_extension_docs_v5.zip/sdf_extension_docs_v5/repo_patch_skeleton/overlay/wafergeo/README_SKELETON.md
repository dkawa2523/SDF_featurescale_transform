# wafergeo skeleton overlay notes

この overlay は、既存 repo の core / observe / metrics / surrogate に対する additive 実装雛形です。

## first targets
- `sdf/distance_api.py`
- `core/roles.py`
- `core/field3d.py`
- `core/views.py`

## second targets
- `observe/contracts.py`
- `observe/profiles.py`
- `observe/corners.py`
- `sem/obs2d_from_contour.py`
- `metrics/*`

## not finished by design
- final CLI wiring
- full backward-compat exports
- optional backend packaging
