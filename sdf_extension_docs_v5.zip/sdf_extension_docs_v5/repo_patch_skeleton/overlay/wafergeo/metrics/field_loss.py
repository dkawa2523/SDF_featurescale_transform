from __future__ import annotations

import numpy as np

from wafergeo.metrics.components import MetricComponent
from wafergeo.observe.contracts import Obs2D


def _smooth_l1(x: np.ndarray, beta: float) -> np.ndarray:
    abs_x = np.abs(x)
    return np.where(abs_x < beta, 0.5 * (x**2) / beta, abs_x - 0.5 * beta)


def compare_field_distance(
    pred: Obs2D,
    target: Obs2D,
    *,
    band_nm: float = 50.0,
    reducer: str = "mae",
) -> MetricComponent:
    if pred.grid2d_shape_yx != target.grid2d_shape_yx:
        raise ValueError("pred and target grids must match")
    if pred.meta.get("distance_semantics") != target.meta.get("distance_semantics"):
        raise ValueError("distance semantics mismatch")

    support = (np.abs(pred.distance2d_nm) <= band_nm) | (np.abs(target.distance2d_nm) <= band_nm)
    if pred.confidence is not None:
        support = support & np.isfinite(pred.confidence) & (pred.confidence > 0)
    if target.confidence is not None:
        support = support & np.isfinite(target.confidence) & (target.confidence > 0)

    diff = pred.distance2d_nm - target.distance2d_nm
    if reducer == "mae":
        err = np.abs(diff)
    elif reducer == "mse":
        err = diff**2
    elif reducer == "smooth_l1":
        err = _smooth_l1(diff, beta=1.0)
    else:
        raise ValueError(f"unknown reducer: {reducer}")

    if support.any():
        value = float(np.mean(err[support]))
        p95 = float(np.percentile(np.abs(diff[support]), 95.0))
        support_fraction = float(support.mean())
    else:
        value = float("nan")
        p95 = float("nan")
        support_fraction = 0.0
    return MetricComponent(
        name=f"field_band_{reducer}",
        value=value,
        unit="nm",
        support={"fraction": support_fraction},
        diagnostics={"band_nm": float(band_nm), "p95_abs_error_nm": p95},
    )
