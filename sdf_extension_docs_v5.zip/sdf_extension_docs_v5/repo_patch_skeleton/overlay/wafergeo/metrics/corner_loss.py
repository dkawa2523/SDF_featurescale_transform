from __future__ import annotations

import math

import numpy as np

from wafergeo.metrics.components import MetricComponent
from wafergeo.observe.contracts import CornerBundle


STANDARD_CORNERS = ("top_left", "top_right", "bottom_left", "bottom_right")


def compare_corners(pred: CornerBundle, target: CornerBundle) -> dict[str, MetricComponent]:
    pos_err = []
    angle_err = []
    radius_err = []
    support = 0
    for name in STANDARD_CORNERS:
        p = pred.corners.get(name)
        t = target.corners.get(name)
        if p is None or t is None:
            continue
        if not (np.isfinite(p.position_nm[0]) and np.isfinite(t.position_nm[0])):
            continue
        support += 1
        pos_err.append(math.dist(p.position_nm, t.position_nm))
        if np.isfinite(p.tangent_angle_deg) and np.isfinite(t.tangent_angle_deg):
            angle_err.append(abs(p.tangent_angle_deg - t.tangent_angle_deg))
        if np.isfinite(p.radius_like_nm) and np.isfinite(t.radius_like_nm):
            radius_err.append(abs(p.radius_like_nm - t.radius_like_nm))

    frac = support / len(STANDARD_CORNERS)
    return {
        "corner_position_mae": MetricComponent(
            name="corner_position_mae",
            value=float(np.mean(pos_err)) if pos_err else float("nan"),
            unit="nm",
            support={"fraction": frac},
            diagnostics={"matched_corners": support},
        ),
        "corner_angle_mae": MetricComponent(
            name="corner_angle_mae",
            value=float(np.mean(angle_err)) if angle_err else float("nan"),
            unit="deg",
            support={"fraction": frac},
            diagnostics={"matched_corners": support},
        ),
        "corner_radius_mae": MetricComponent(
            name="corner_radius_mae",
            value=float(np.mean(radius_err)) if radius_err else float("nan"),
            unit="nm",
            support={"fraction": frac},
            diagnostics={"matched_corners": support},
        ),
    }
