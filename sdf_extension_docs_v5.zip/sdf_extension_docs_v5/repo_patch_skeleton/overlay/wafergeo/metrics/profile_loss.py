from __future__ import annotations

from typing import Iterable

import numpy as np

from wafergeo.metrics.components import MetricComponent
from wafergeo.observe.contracts import ProfileBundle


def _unit_from_name(name: str) -> str:
    lname = name.lower()
    if "angle" in lname:
        return "deg"
    if "curvature" in lname:
        return "1/nm"
    return "nm"


def _common_coordinate(pred: ProfileBundle, target: ProfileBundle) -> np.ndarray:
    lo = max(float(np.min(pred.coordinate_nm)), float(np.min(target.coordinate_nm)))
    hi = min(float(np.max(pred.coordinate_nm)), float(np.max(target.coordinate_nm)))
    if not np.isfinite(lo) or not np.isfinite(hi) or hi < lo:
        return np.empty((0,), dtype=np.float32)
    step = min(
        np.median(np.diff(pred.coordinate_nm)).item() if pred.coordinate_nm.size > 1 else 1.0,
        np.median(np.diff(target.coordinate_nm)).item() if target.coordinate_nm.size > 1 else 1.0,
    )
    step = max(float(step), 1e-6)
    return np.arange(lo, hi + step, step, dtype=np.float32)


def _interp_with_support(x: np.ndarray, y: np.ndarray, support: np.ndarray, xq: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    finite = np.isfinite(y) & support.astype(bool)
    if finite.sum() < 2:
        return np.full_like(xq, np.nan, dtype=np.float32), np.zeros_like(xq, dtype=bool)
    yq = np.interp(xq, x[finite], y[finite]).astype(np.float32)
    support_q = (xq >= x[finite][0]) & (xq <= x[finite][-1])
    return yq, support_q


def compare_profiles(
    pred: ProfileBundle,
    target: ProfileBundle,
    *,
    channels: Iterable[str] | None = None,
) -> dict[str, MetricComponent]:
    if pred.coordinate_name != target.coordinate_name:
        raise ValueError("coordinate_name mismatch")
    common_x = _common_coordinate(pred, target)
    selected = list(channels) if channels is not None else sorted(set(pred.values) & set(target.values))
    out: dict[str, MetricComponent] = {}
    for name in selected:
        pred_y, pred_support = _interp_with_support(
            pred.coordinate_nm,
            pred.values[name],
            pred.support_mask[name],
            common_x,
        )
        tgt_y, tgt_support = _interp_with_support(
            target.coordinate_nm,
            target.values[name],
            target.support_mask[name],
            common_x,
        )
        support = pred_support & tgt_support & np.isfinite(pred_y) & np.isfinite(tgt_y)
        if support.any():
            abs_err = np.abs(pred_y[support] - tgt_y[support])
            value = float(np.mean(abs_err))
            p95 = float(np.percentile(abs_err, 95.0))
            frac = float(support.mean())
        else:
            value = float("nan")
            p95 = float("nan")
            frac = 0.0
        out[name] = MetricComponent(
            name=f"profile_{name}_mae",
            value=value,
            unit=_unit_from_name(name),
            support={"fraction": frac},
            diagnostics={"p95": p95, "common_coordinate_count": int(common_x.shape[0])},
        )
    return out
