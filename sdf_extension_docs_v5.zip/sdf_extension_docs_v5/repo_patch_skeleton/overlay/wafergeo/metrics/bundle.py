from __future__ import annotations

from typing import Iterable

import numpy as np

from wafergeo.metrics.components import MetricBundle, MetricComponent
from wafergeo.metrics.corner_loss import compare_corners
from wafergeo.metrics.curve_loss import compare_contours
from wafergeo.metrics.field_loss import compare_field_distance
from wafergeo.metrics.profile_loss import compare_profiles
from wafergeo.observe.contracts import CornerBundle, Obs2D, ProfileBundle
from wafergeo.observe.corners import build_corner_bundle_from_obs2d
from wafergeo.observe.profiles import build_profile_bundle_from_obs2d


DEFAULT_GROUP_ORDER = ("field", "curve", "profile", "corner", "topology")


def build_metric_bundle(
    pred_obs: Obs2D,
    target_obs: Obs2D,
    *,
    pred_profiles: ProfileBundle | None = None,
    target_profiles: ProfileBundle | None = None,
    pred_corners: CornerBundle | None = None,
    target_corners: CornerBundle | None = None,
    field_band_nm: float = 50.0,
    curve_step_nm: float = 5.0,
    profile_channels: Iterable[str] | None = None,
) -> MetricBundle:
    bundle = MetricBundle(meta={
        "builder": "build_metric_bundle",
        "distance_semantics": target_obs.meta.get("distance_semantics"),
    })
    bundle.field["default"] = compare_field_distance(pred_obs, target_obs, band_nm=field_band_nm)
    if pred_obs.contours_xy_nm is not None and target_obs.contours_xy_nm is not None:
        bundle.curve.update(compare_contours(pred_obs.contours_xy_nm, target_obs.contours_xy_nm, step_nm=curve_step_nm))
    pred_profiles = pred_profiles or build_profile_bundle_from_obs2d(pred_obs)
    target_profiles = target_profiles or build_profile_bundle_from_obs2d(target_obs)
    bundle.profile.update(compare_profiles(pred_profiles, target_profiles, channels=profile_channels))
    pred_corners = pred_corners or build_corner_bundle_from_obs2d(pred_obs)
    target_corners = target_corners or build_corner_bundle_from_obs2d(target_obs)
    bundle.corner.update(compare_corners(pred_corners, target_corners))
    return bundle


def scalarize_metric_bundle(
    bundle: MetricBundle,
    *,
    normalizers: dict[str, float],
    group_weights: dict[str, float] | None = None,
) -> MetricComponent:
    """Convert a decomposed bundle into one scalar objective.

    The caller must provide explicit normalizers so that mixed units are not silently
    combined. This keeps the geometry representation separate from policy.
    """

    weights = group_weights or {name: 1.0 for name in DEFAULT_GROUP_ORDER}
    terms = []
    diagnostics = {"normalized_terms": {}}
    for group_name in DEFAULT_GROUP_ORDER:
        group = getattr(bundle, group_name)
        if not group:
            continue
        values = []
        for comp_name, comp in group.items():
            key = f"{group_name}.{comp_name}"
            norm = normalizers.get(key)
            if norm is None:
                continue
            if not np.isfinite(comp.value):
                continue
            normalized = comp.value / norm
            diagnostics["normalized_terms"][key] = normalized
            values.append(normalized)
        if values:
            terms.append(weights.get(group_name, 1.0) * float(np.mean(values)))
    total_value = float(np.mean(terms)) if terms else float("nan")
    total = MetricComponent(
        name="total_objective",
        value=total_value,
        unit="normalized",
        support={"group_count": float(len(terms))},
        diagnostics=diagnostics,
    )
    bundle.total = total
    return total
