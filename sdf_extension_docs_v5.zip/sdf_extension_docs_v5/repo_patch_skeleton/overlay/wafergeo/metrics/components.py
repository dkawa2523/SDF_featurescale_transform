from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class MetricComponent:
    name: str
    value: float
    unit: str
    support: dict[str, float]
    diagnostics: dict[str, Any] = field(default_factory=dict)


@dataclass
class MetricBundle:
    field: dict[str, MetricComponent] = field(default_factory=dict)
    curve: dict[str, MetricComponent] = field(default_factory=dict)
    profile: dict[str, MetricComponent] = field(default_factory=dict)
    corner: dict[str, MetricComponent] = field(default_factory=dict)
    topology: dict[str, MetricComponent] = field(default_factory=dict)
    total: MetricComponent | None = None
    meta: dict[str, Any] = field(default_factory=dict)
