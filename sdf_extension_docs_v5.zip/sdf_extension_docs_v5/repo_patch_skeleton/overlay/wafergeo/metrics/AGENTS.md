# AGENTS.md for wafergeo/metrics/

## Focus
MetricComponent, MetricBundle, field / curve / profile / corner losses.

## Rules
- keep components separated
- each component needs diagnostics and support info
- scalarization is explicit and configurable
- avoid burying all logic inside one giant scalar loss
