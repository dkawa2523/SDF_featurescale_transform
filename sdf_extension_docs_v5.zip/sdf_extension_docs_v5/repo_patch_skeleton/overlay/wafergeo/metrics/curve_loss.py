from __future__ import annotations

import numpy as np

from wafergeo.metrics.components import MetricComponent


def _resample_polyline(polyline: np.ndarray, step_nm: float) -> np.ndarray:
    if polyline.shape[0] < 2:
        return polyline.astype(np.float32)
    diffs = np.diff(polyline, axis=0)
    seg_len = np.sqrt(np.sum(diffs**2, axis=1))
    total = float(seg_len.sum())
    if total <= 0:
        return polyline[:1].astype(np.float32)
    samples = np.arange(0.0, total + step_nm, step_nm, dtype=np.float32)
    cum = np.concatenate([[0.0], np.cumsum(seg_len, dtype=np.float64)])
    out = np.empty((samples.shape[0], 2), dtype=np.float32)
    for i, s in enumerate(samples):
        seg_idx = min(int(np.searchsorted(cum, s, side="right") - 1), polyline.shape[0] - 2)
        seg_start = cum[seg_idx]
        seg_end = cum[seg_idx + 1]
        if seg_end <= seg_start:
            out[i] = polyline[seg_idx]
        else:
            t = (s - seg_start) / (seg_end - seg_start)
            out[i] = (1.0 - t) * polyline[seg_idx] + t * polyline[seg_idx + 1]
    return out


def _flatten_and_resample(contours: list[np.ndarray], step_nm: float) -> np.ndarray:
    pieces = []
    for contour in contours:
        arr = np.asarray(contour, dtype=np.float32)
        if arr.ndim != 2 or arr.shape[1] != 2:
            raise ValueError("each contour must have shape [N,2]")
        if arr.shape[0] >= 2:
            pieces.append(_resample_polyline(arr, step_nm))
    if not pieces:
        return np.empty((0, 2), dtype=np.float32)
    return np.concatenate(pieces, axis=0)


def _nearest_distance(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    if a.size == 0 or b.size == 0:
        return np.full((a.shape[0],), np.nan, dtype=np.float32)
    diff = a[:, None, :] - b[None, :, :]
    dist = np.sqrt(np.sum(diff**2, axis=2))
    return np.min(dist, axis=1).astype(np.float32)


def compare_contours(
    pred_contours: list[np.ndarray],
    target_contours: list[np.ndarray],
    *,
    step_nm: float = 5.0,
    tail_percentile: float = 95.0,
) -> dict[str, MetricComponent]:
    pred_pts = _flatten_and_resample(pred_contours, step_nm)
    tgt_pts = _flatten_and_resample(target_contours, step_nm)
    d_ab = _nearest_distance(pred_pts, tgt_pts)
    d_ba = _nearest_distance(tgt_pts, pred_pts)
    both = np.concatenate([d_ab[np.isfinite(d_ab)], d_ba[np.isfinite(d_ba)]])
    if both.size == 0:
        chamfer = float("nan")
        tail = float("nan")
        support_fraction = 0.0
    else:
        chamfer = float(np.mean(both))
        tail = float(np.percentile(both, tail_percentile))
        support_fraction = 1.0
    return {
        "curve_chamfer": MetricComponent(
            name="curve_chamfer",
            value=chamfer,
            unit="nm",
            support={"fraction": support_fraction},
            diagnostics={"sample_step_nm": float(step_nm)},
        ),
        f"curve_tail_p{int(tail_percentile)}": MetricComponent(
            name=f"curve_tail_p{int(tail_percentile)}",
            value=tail,
            unit="nm",
            support={"fraction": support_fraction},
            diagnostics={"sample_step_nm": float(step_nm)},
        ),
    }
