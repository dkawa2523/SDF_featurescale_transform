from __future__ import annotations

from typing import Iterable

import numpy as np

from wafergeo.observe.contracts import Obs2D


def _grid_points_xy_nm(
    grid_shape_yx: tuple[int, int],
    spacing_nm_yx: tuple[float, float],
    origin_nm_yx: tuple[float, float],
) -> tuple[np.ndarray, np.ndarray]:
    y = origin_nm_yx[0] + np.arange(grid_shape_yx[0], dtype=np.float32) * spacing_nm_yx[0]
    x = origin_nm_yx[1] + np.arange(grid_shape_yx[1], dtype=np.float32) * spacing_nm_yx[1]
    yy, xx = np.meshgrid(y, x, indexing="ij")
    return xx, yy


def _point_segment_distance_sq(points_xy: np.ndarray, a_xy: np.ndarray, b_xy: np.ndarray) -> np.ndarray:
    ap = points_xy - a_xy[None, :]
    ab = b_xy - a_xy
    denom = float(np.dot(ab, ab))
    if denom <= 0.0:
        return np.sum(ap**2, axis=1)
    t = np.clip((ap @ ab) / denom, 0.0, 1.0)
    proj = a_xy[None, :] + t[:, None] * ab[None, :]
    diff = points_xy - proj
    return np.sum(diff**2, axis=1)


def polyline_distance_image_nm(
    contours_xy_nm: Iterable[np.ndarray],
    grid_shape_yx: tuple[int, int],
    spacing_nm_yx: tuple[float, float],
    origin_nm_yx: tuple[float, float] = (0.0, 0.0),
) -> np.ndarray:
    xx, yy = _grid_points_xy_nm(grid_shape_yx, spacing_nm_yx, origin_nm_yx)
    points = np.stack([xx.reshape(-1), yy.reshape(-1)], axis=1).astype(np.float32)
    dist_sq = np.full((points.shape[0],), np.inf, dtype=np.float32)
    for contour in contours_xy_nm:
        contour_arr = np.asarray(contour, dtype=np.float32)
        if contour_arr.ndim != 2 or contour_arr.shape[1] != 2:
            raise ValueError("each contour must have shape [N,2]")
        if contour_arr.shape[0] < 2:
            continue
        for i in range(contour_arr.shape[0] - 1):
            seg_sq = _point_segment_distance_sq(points, contour_arr[i], contour_arr[i + 1])
            dist_sq = np.minimum(dist_sq, seg_sq.astype(np.float32))
    return np.sqrt(dist_sq, dtype=np.float32).reshape(grid_shape_yx)


def build_obs2d_from_contours(
    contours_xy_nm: list[np.ndarray],
    grid_shape_yx: tuple[int, int],
    spacing_nm_yx: tuple[float, float],
    origin_nm_yx: tuple[float, float] = (0.0, 0.0),
    *,
    signed: bool = False,
    mask2d: np.ndarray | None = None,
    confidence: np.ndarray | None = None,
    debug_maps: dict[str, np.ndarray] | None = None,
    meta: dict[str, object] | None = None,
) -> Obs2D:
    distance_unsigned = polyline_distance_image_nm(
        contours_xy_nm,
        grid_shape_yx,
        spacing_nm_yx,
        origin_nm_yx,
    ).astype(np.float32)
    if signed:
        if mask2d is None:
            raise ValueError("signed=True requires mask2d in this skeleton implementation")
        distance = np.where(mask2d.astype(bool), -distance_unsigned, distance_unsigned).astype(np.float32)
        semantics = "signed"
    else:
        distance = distance_unsigned
        semantics = "unsigned"
    meta_out = dict(meta or {})
    meta_out.setdefault("distance_semantics", semantics)
    meta_out.setdefault("builder", "build_obs2d_from_contours")
    return Obs2D(
        grid2d_shape_yx=grid_shape_yx,
        spacing_nm_yx=(float(spacing_nm_yx[0]), float(spacing_nm_yx[1])),
        origin_nm_yx=(float(origin_nm_yx[0]), float(origin_nm_yx[1])),
        axis_order="yx",
        distance2d_nm=distance,
        mask2d=None if mask2d is None else np.asarray(mask2d, dtype=bool),
        contours_xy_nm=[np.asarray(c, dtype=np.float32) for c in contours_xy_nm],
        confidence=None if confidence is None else np.asarray(confidence, dtype=np.float32),
        transform=None,
        debug_maps=dict(debug_maps or {}),
        meta=meta_out,
    )
