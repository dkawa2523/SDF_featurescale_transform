# AGENTS.md for wafergeo/

## Scope
All code under `wafergeo/`.

## Rules
- public units are nm
- shapes must be explicit in docstrings
- dataclasses / typed helpers are preferred for contracts
- process-specific naming belongs in examples or docs, not core API names
- keep adapters separate from canonical contracts
