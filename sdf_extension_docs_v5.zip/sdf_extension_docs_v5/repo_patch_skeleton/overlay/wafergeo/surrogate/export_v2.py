from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from pathlib import Path
import json
from typing import Any

import numpy as np

from wafergeo.core.field3d import Field3D
from wafergeo.core.views import DistanceViews
from wafergeo.observe.contracts import CornerBundle, Obs2D, ProfileBundle


@dataclass(frozen=True)
class DatasetPackageEntry:
    sample_id: str
    files: dict[str, str]
    meta: dict[str, Any]


@dataclass(frozen=True)
class DatasetPackageV2:
    version: str
    entry: DatasetPackageEntry


def _json_default(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if is_dataclass(value):
        return asdict(value)
    raise TypeError(f"Object of type {type(value)!r} is not JSON serializable")


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=_json_default) + "\n", encoding="utf-8")


def _save_obs(root: Path, name: str, obs: Obs2D, files: dict[str, str]) -> None:
    obs_dir = root / "obs" / name
    obs_dir.mkdir(parents=True, exist_ok=True)
    np.save(obs_dir / "distance2d_nm.npy", obs.distance2d_nm)
    files[f"obs.{name}.distance2d_nm"] = str((Path("obs") / name / "distance2d_nm.npy").as_posix())
    if obs.mask2d is not None:
        np.save(obs_dir / "mask2d.npy", obs.mask2d)
        files[f"obs.{name}.mask2d"] = str((Path("obs") / name / "mask2d.npy").as_posix())
    if obs.confidence is not None:
        np.save(obs_dir / "confidence.npy", obs.confidence)
        files[f"obs.{name}.confidence"] = str((Path("obs") / name / "confidence.npy").as_posix())
    _write_json(obs_dir / "meta.json", obs.meta)
    files[f"obs.{name}.meta"] = str((Path("obs") / name / "meta.json").as_posix())


def _save_profiles(root: Path, name: str, bundle: ProfileBundle, files: dict[str, str]) -> None:
    profile_dir = root / "profiles"
    profile_dir.mkdir(parents=True, exist_ok=True)
    np.savez(
        profile_dir / f"{name}.npz",
        coordinate_nm=bundle.coordinate_nm,
        **bundle.values,
        **{f"support__{k}": v for k, v in bundle.support_mask.items()},
    )
    files[f"profiles.{name}"] = str((Path("profiles") / f"{name}.npz").as_posix())


def _save_corners(root: Path, name: str, bundle: CornerBundle, files: dict[str, str]) -> None:
    corner_dir = root / "corners"
    corner_dir.mkdir(parents=True, exist_ok=True)
    payload = {corner_name: asdict(corner) for corner_name, corner in bundle.corners.items()}
    _write_json(corner_dir / f"{name}.json", payload)
    files[f"corners.{name}"] = str((Path("corners") / f"{name}.json").as_posix())


def export_dataset_package_v2(
    root_dir: str | Path,
    sample_id: str,
    field: Field3D,
    *,
    views: DistanceViews | None = None,
    observations: dict[str, Obs2D] | None = None,
    profiles: dict[str, ProfileBundle] | None = None,
    corners: dict[str, CornerBundle] | None = None,
    extra_meta: dict[str, Any] | None = None,
) -> DatasetPackageV2:
    root = Path(root_dir) / sample_id
    root.mkdir(parents=True, exist_ok=True)
    files: dict[str, str] = {}

    field_dir = root / "field"
    field_dir.mkdir(parents=True, exist_ok=True)
    np.save(field_dir / "sdf_nm.npy", field.sdf_nm)
    files["field.sdf_nm"] = str((Path("field") / "sdf_nm.npy").as_posix())
    if field.udf_nm is not None:
        np.save(field_dir / "udf_nm.npy", field.udf_nm)
        files["field.udf_nm"] = str((Path("field") / "udf_nm.npy").as_posix())
    if field.scalar_fields:
        np.savez(field_dir / "scalar_fields.npz", **field.scalar_fields)
        files["field.scalar_fields"] = str((Path("field") / "scalar_fields.npz").as_posix())
    if field.interface_fields:
        np.savez(field_dir / "interface_fields.npz", **field.interface_fields)
        files["field.interface_fields"] = str((Path("field") / "interface_fields.npz").as_posix())
    _write_json(field_dir / "meta.json", field.meta)
    files["field.meta"] = str((Path("field") / "meta.json").as_posix())

    if views is not None:
        views_dir = root / "views"
        views_dir.mkdir(parents=True, exist_ok=True)
        for name, arr in views.tsdf_views.items():
            np.save(views_dir / f"tsdf__{name}.npy", arr)
            files[f"views.tsdf.{name}"] = str((Path("views") / f"tsdf__{name}.npy").as_posix())
        for name, arr in views.tanh_views.items():
            np.save(views_dir / f"tanh__{name}.npy", arr)
            files[f"views.tanh.{name}"] = str((Path("views") / f"tanh__{name}.npy").as_posix())
        for name, (sign, mag) in views.logsigned_views.items():
            np.savez(views_dir / f"logsigned__{name}.npz", sign=sign, mag=mag)
            files[f"views.logsigned.{name}"] = str((Path("views") / f"logsigned__{name}.npz").as_posix())
        _write_json(views_dir / "meta.json", views.meta)
        files["views.meta"] = str((Path("views") / "meta.json").as_posix())

    for name, obs in (observations or {}).items():
        _save_obs(root, name, obs, files)
    for name, bundle in (profiles or {}).items():
        _save_profiles(root, name, bundle, files)
    for name, bundle in (corners or {}).items():
        _save_corners(root, name, bundle, files)

    manifest = {
        "version": "dataset_package_v2",
        "sample_id": sample_id,
        "files": files,
        "meta": {
            "distance_semantics": field.meta.get("distance_semantics"),
            "role_id_order": field.meta.get("role_id_order"),
            **dict(extra_meta or {}),
        },
    }
    _write_json(root / "manifest.json", manifest)
    entry = DatasetPackageEntry(sample_id=sample_id, files=files, meta=manifest["meta"])
    return DatasetPackageV2(version="dataset_package_v2", entry=entry)
