from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from wafergeo.core.field3d import Field3D


@dataclass(frozen=True)
class ViewSpec:
    tsdf_mu_nm: dict[str, float] = field(default_factory=dict)
    tanh_mu_nm: dict[str, float] = field(default_factory=dict)
    emit_logsigned: bool = True


@dataclass
class DistanceViews:
    tsdf_views: dict[str, np.ndarray] = field(default_factory=dict)
    tanh_views: dict[str, np.ndarray] = field(default_factory=dict)
    logsigned_views: dict[str, tuple[np.ndarray, np.ndarray]] = field(default_factory=dict)
    meta: dict[str, object] = field(default_factory=dict)


def _validate_mu(mu_nm: float) -> float:
    mu = float(mu_nm)
    if not np.isfinite(mu) or mu <= 0:
        raise ValueError(f"mu_nm must be finite and > 0, got {mu_nm}")
    return mu


def to_tsdf_view(phi_nm: np.ndarray, mu_nm: float) -> np.ndarray:
    mu = _validate_mu(mu_nm)
    return np.clip(phi_nm, -mu, mu).astype(np.float32) / mu


def to_tanh_view(phi_nm: np.ndarray, mu_nm: float) -> np.ndarray:
    mu = _validate_mu(mu_nm)
    return np.tanh(phi_nm / mu).astype(np.float32)


def to_logsigned_view(phi_nm: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    sign = np.sign(phi_nm).astype(np.int8)
    mag = np.log1p(np.abs(phi_nm)).astype(np.float32)
    return sign, mag


def build_distance_views(field: Field3D, spec: ViewSpec) -> DistanceViews:
    out = DistanceViews(meta={
        "source": "Field3D.sdf_nm",
        "distance_semantics": "signed",
        "role_id_order": list(field.roles.ordered_role_ids),
        "tsdf_mu_nm": dict(spec.tsdf_mu_nm),
        "tanh_mu_nm": dict(spec.tanh_mu_nm),
        "emit_logsigned": spec.emit_logsigned,
    })
    for name, mu in spec.tsdf_mu_nm.items():
        out.tsdf_views[name] = to_tsdf_view(field.sdf_nm, mu)
    for name, mu in spec.tanh_mu_nm.items():
        out.tanh_views[name] = to_tanh_view(field.sdf_nm, mu)
    if spec.emit_logsigned:
        out.logsigned_views["default"] = to_logsigned_view(field.sdf_nm)
    return out
