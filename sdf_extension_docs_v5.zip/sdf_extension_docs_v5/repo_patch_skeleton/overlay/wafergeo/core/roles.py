from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from wafergeo.core.types import MaterialSpec


@dataclass(frozen=True)
class RoleSpec:
    """Map raw material ids to a smaller, stable role space.

    The role space is intentionally generic so that etch/deposition-specific naming does
    not leak into core geometry contracts.
    """

    raw_material_to_role: dict[int, int]
    role_id_to_name: dict[int, str]
    void_role_id: int

    def __post_init__(self) -> None:
        if self.void_role_id not in self.role_id_to_name:
            raise ValueError("void_role_id must exist in role_id_to_name")
        role_ids = set(self.role_id_to_name)
        for raw_id, role_id in self.raw_material_to_role.items():
            if role_id not in role_ids:
                raise ValueError(
                    f"raw_material_to_role[{raw_id}] -> {role_id} is not present in role_id_to_name"
                )
        if len(set(self.role_id_to_name.values())) != len(self.role_id_to_name):
            raise ValueError("role names must be unique")

    @property
    def ordered_role_ids(self) -> list[int]:
        return sorted(self.role_id_to_name)


DEFAULT_NONVOID_ROLE_NAME = "target"
DEFAULT_VOID_ROLE_NAME = "void"


def identity_role_spec_from_material(material: MaterialSpec) -> RoleSpec:
    """Create a 1:1 raw-material -> role mapping.

    This is the safest default for early integration because it preserves existing
    material semantics until a smaller canonical role space is explicitly provided.
    """

    return RoleSpec(
        raw_material_to_role={int(mid): int(mid) for mid in material.ids},
        role_id_to_name={int(mid): str(name) for mid, name in zip(material.ids, material.names, strict=True)},
        void_role_id=int(material.void_id),
    )


def minimal_role_spec_from_material(
    material: MaterialSpec,
    *,
    nonvoid_role_name: str = DEFAULT_NONVOID_ROLE_NAME,
    void_role_name: str = DEFAULT_VOID_ROLE_NAME,
) -> RoleSpec:
    """Collapse all non-void materials into one generic non-void role.

    This is useful for observation / metric prototyping where exact material identity is
    not required yet.
    """

    raw_to_role: dict[int, int] = {}
    for mid in material.ids:
        raw_to_role[int(mid)] = 0 if int(mid) == int(material.void_id) else 1
    return RoleSpec(
        raw_material_to_role=raw_to_role,
        role_id_to_name={0: void_role_name, 1: nonvoid_role_name},
        void_role_id=0,
    )


def map_raw_labels_to_roles(labels_zyx: np.ndarray, role_spec: RoleSpec) -> np.ndarray:
    labels = np.asarray(labels_zyx)
    if labels.ndim != 3:
        raise ValueError(f"labels_zyx must be 3D, got ndim={labels.ndim}")
    role_labels = np.empty(labels.shape, dtype=np.int16)
    unique = np.unique(labels)
    missing = [int(v) for v in unique.tolist() if int(v) not in role_spec.raw_material_to_role]
    if missing:
        raise ValueError(f"role mapping missing raw material ids: {missing}")
    for raw_id, role_id in role_spec.raw_material_to_role.items():
        role_labels[labels == raw_id] = role_id
    return role_labels
