from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

import numpy as np

from wafergeo.core.grid import GridSpec
from wafergeo.core.meta import Meta
from wafergeo.core.roles import RoleSpec, identity_role_spec_from_material, map_raw_labels_to_roles
from wafergeo.core.types import LabelVolume
from wafergeo.sdf.distance_api import signed_distance_nm, unsigned_distance_nm


@dataclass(frozen=True)
class GridMeta:
    """Geometry grid contract for canonical 3D fields."""

    shape_zyx: tuple[int, int, int]
    spacing_nm_zyx: tuple[float, float, float]
    origin_nm_zyx: tuple[float, float, float]
    axis_order: str = "zyx"
    frame: str = "canonical"

    @classmethod
    def from_gridspec(cls, grid: GridSpec, shape_zyx: tuple[int, int, int]) -> "GridMeta":
        if grid.dim != 3:
            raise ValueError(f"GridSpec.dim must be 3, got {grid.dim}")
        return cls(
            shape_zyx=shape_zyx,
            spacing_nm_zyx=(float(grid.spacing[0]), float(grid.spacing[1]), float(grid.spacing[2])),
            origin_nm_zyx=(float(grid.origin[0]), float(grid.origin[1]), float(grid.origin[2])),
            axis_order=str(grid.axis_order).lower(),
            frame="canonical",
        )

    def to_gridspec(self) -> GridSpec:
        return GridSpec(
            dim=3,
            spacing=self.spacing_nm_zyx,
            origin=self.origin_nm_zyx,
            axis_order="ZYX",
            sample_location="cell_center",
            units="nm",
        )


@dataclass
class Field3D:
    """Canonical geometry field.

    `sdf_nm` is the system-of-record. All other dense distance encodings are derived views.
    """

    grid: GridMeta
    roles: RoleSpec
    sdf_nm: np.ndarray
    udf_nm: np.ndarray | None = None
    scalar_fields: dict[str, np.ndarray] = field(default_factory=dict)
    interface_fields: dict[str, np.ndarray] = field(default_factory=dict)
    support_mask: np.ndarray | None = None
    qa: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        expected_shape = (len(self.roles.ordered_role_ids),) + self.grid.shape_zyx
        if self.sdf_nm.shape != expected_shape:
            raise ValueError(f"sdf_nm must have shape {expected_shape}, got {self.sdf_nm.shape}")
        if self.sdf_nm.dtype != np.float32:
            raise ValueError(f"sdf_nm must be float32, got {self.sdf_nm.dtype}")
        if not np.isfinite(self.sdf_nm).all():
            raise ValueError("sdf_nm contains NaN/Inf")
        if self.udf_nm is not None:
            if self.udf_nm.shape != expected_shape:
                raise ValueError("udf_nm shape must match sdf_nm")
            if self.udf_nm.dtype != np.float32:
                raise ValueError("udf_nm must be float32")
        if self.support_mask is not None and self.support_mask.shape != self.grid.shape_zyx:
            raise ValueError("support_mask shape must be [Z,Y,X]")
        if self.meta.get("distance_semantics") != "signed":
            raise ValueError("Field3D.meta['distance_semantics'] must be 'signed'")


@dataclass(frozen=True)
class FieldBuilderConfig:
    backend: str = "scipy"
    emit_udf: bool = False
    emit_interface_pairs: tuple[tuple[int, int], ...] = ()
    emit_scalar_fields: tuple[str, ...] = ("nonvoid_mask",)
    require_exact_backend: bool = False


@dataclass(frozen=True)
class FieldBuildResult:
    field: Field3D
    role_labels_zyx: np.ndarray


def _copy_meta(meta: Meta) -> dict[str, Any]:
    return {
        "schema_version": meta.schema_version,
        "profile_id": meta.profile_id,
        "config_hash": meta.config_hash,
        "generator_version": meta.generator_version,
        "git_commit": meta.git_commit,
        "input_hash": meta.input_hash,
        "created_at": meta.created_at,
        "extra": dict(meta.extra),
    }


def decode_role_labels(field: Field3D) -> np.ndarray:
    """Decode a single role label volume by choosing the most-inside channel.

    This uses the minimum signed distance channel, which is the natural decode for the
    project's negative-inside convention.
    """

    role_ids = np.asarray(field.roles.ordered_role_ids, dtype=np.int16)
    argmin = np.argmin(field.sdf_nm, axis=0)
    return role_ids[argmin]


def _build_top_height_nm(role_labels_zyx: np.ndarray, grid: GridMeta, void_role_id: int) -> np.ndarray:
    z_to_nm = grid.origin_nm_zyx[0] + np.arange(grid.shape_zyx[0], dtype=np.float32) * grid.spacing_nm_zyx[0]
    Y, X = grid.shape_zyx[1], grid.shape_zyx[2]
    top = np.full((Y, X), np.nan, dtype=np.float32)
    for y in range(Y):
        for x in range(X):
            hits = np.where(role_labels_zyx[:, y, x] != void_role_id)[0]
            if hits.size:
                top[y, x] = z_to_nm[hits[0]]
    return top


def _build_scalar_fields(
    role_labels_zyx: np.ndarray,
    role_spec: RoleSpec,
    grid: GridMeta,
    requested: Iterable[str],
) -> dict[str, np.ndarray]:
    names = set(requested)
    out: dict[str, np.ndarray] = {}
    if "nonvoid_mask" in names:
        out["nonvoid_mask"] = (role_labels_zyx != role_spec.void_role_id)
    if "decoded_role_zyx" in names:
        out["decoded_role_zyx"] = role_labels_zyx.astype(np.int16, copy=False)
    if "top_height_nm" in names:
        out["top_height_nm"] = _build_top_height_nm(role_labels_zyx, grid, role_spec.void_role_id)
    return out


def _build_interface_fields(
    sdf_nm: np.ndarray,
    role_ids: list[int],
    interface_pairs: Iterable[tuple[int, int]],
) -> dict[str, np.ndarray]:
    role_to_index = {rid: i for i, rid in enumerate(role_ids)}
    out: dict[str, np.ndarray] = {}
    for a, b in interface_pairs:
        if a not in role_to_index or b not in role_to_index:
            raise ValueError(f"interface pair ({a}, {b}) is not present in role ids")
        out[f"phi_{a}_{b}_nm"] = (
            sdf_nm[role_to_index[a]] - sdf_nm[role_to_index[b]]
        ).astype(np.float32, copy=False)
    return out


def summarize_field_qa(field: Field3D) -> dict[str, Any]:
    sdf = field.sdf_nm
    finite_ratio = float(np.isfinite(sdf).mean())
    return {
        "finite_ratio": finite_ratio,
        "sdf_min_nm": float(np.min(sdf)),
        "sdf_max_nm": float(np.max(sdf)),
        "shape_zyx": list(field.grid.shape_zyx),
        "role_count": len(field.roles.ordered_role_ids),
    }


def build_field3d_from_label_volume(
    label: LabelVolume,
    role_spec: RoleSpec | None = None,
    *,
    cfg: FieldBuilderConfig | None = None,
) -> FieldBuildResult:
    """Build canonical raw-distance geometry from an existing LabelVolume.

    This is intentionally additive: it does not remove or mutate the legacy TSDF path.
    """

    config = cfg or FieldBuilderConfig()
    role_spec = role_spec or identity_role_spec_from_material(label.material)
    grid = GridMeta.from_gridspec(label.grid, label.material_id.shape)
    role_labels = map_raw_labels_to_roles(label.material_id, role_spec)
    role_ids = role_spec.ordered_role_ids

    sdf_stack: list[np.ndarray] = []
    udf_stack: list[np.ndarray] = []
    for role_id in role_ids:
        mask = role_labels == role_id
        sdf = signed_distance_nm(
            mask,
            grid.spacing_nm_zyx,
            backend=config.backend,
            inside_negative=True,
            require_exact=config.require_exact_backend,
        )
        sdf_stack.append(sdf.astype(np.float32, copy=False))
        if config.emit_udf:
            udf = unsigned_distance_nm(
                mask,
                grid.spacing_nm_zyx,
                backend=config.backend,
                require_exact=config.require_exact_backend,
            )
            udf_stack.append(udf.astype(np.float32, copy=False))

    sdf_nm = np.stack(sdf_stack, axis=0).astype(np.float32, copy=False)
    udf_nm = np.stack(udf_stack, axis=0).astype(np.float32, copy=False) if config.emit_udf else None
    scalar_fields = _build_scalar_fields(role_labels, role_spec, grid, config.emit_scalar_fields)
    interface_fields = _build_interface_fields(sdf_nm, role_ids, config.emit_interface_pairs)
    support_mask = np.ones(grid.shape_zyx, dtype=bool)
    meta = _copy_meta(label.meta)
    meta.update(
        {
            "distance_semantics": "signed",
            "builder": "build_field3d_from_label_volume",
            "builder_backend": config.backend,
            "role_id_order": role_ids,
        }
    )

    field = Field3D(
        grid=grid,
        roles=role_spec,
        sdf_nm=sdf_nm,
        udf_nm=udf_nm,
        scalar_fields=scalar_fields,
        interface_fields=interface_fields,
        support_mask=support_mask,
        qa={},
        meta=meta,
    )
    field.qa.update(summarize_field_qa(field))
    return FieldBuildResult(field=field, role_labels_zyx=role_labels)
