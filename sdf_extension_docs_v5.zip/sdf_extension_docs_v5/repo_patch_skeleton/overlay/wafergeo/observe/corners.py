from __future__ import annotations

import math

import numpy as np

from wafergeo.observe.contracts import CornerBundle, CornerDescriptor, Obs2D, ProfileBundle
from wafergeo.observe.profiles import build_profile_bundle_from_obs2d


def _radius_like_from_curvature(curvature_inv_nm: float) -> float:
    if not np.isfinite(curvature_inv_nm) or abs(curvature_inv_nm) < 1e-12:
        return float("inf")
    return float(1.0 / abs(curvature_inv_nm))


def _make_missing_corner(name: str) -> CornerDescriptor:
    return CornerDescriptor(
        name=name,
        position_nm=(float("nan"), float("nan")),
        tangent_angle_deg=float("nan"),
        curvature_inv_nm=float("nan"),
        radius_like_nm=float("nan"),
        confidence=0.0,
        support_count=0,
    )


def build_corner_bundle_from_profiles(bundle: ProfileBundle) -> CornerBundle:
    y = bundle.coordinate_nm
    left = bundle.values.get("left_edge_x_nm")
    right = bundle.values.get("right_edge_x_nm")
    left_angle = bundle.values.get("left_wall_angle_deg")
    right_angle = bundle.values.get("right_wall_angle_deg")
    left_curv = bundle.values.get("left_curvature_inv_nm")
    right_curv = bundle.values.get("right_curvature_inv_nm")

    if left is None or right is None:
        raise ValueError("ProfileBundle must contain left/right edge channels")

    valid_rows = np.where(np.isfinite(left) & np.isfinite(right))[0]
    if valid_rows.size == 0:
        return CornerBundle(
            corners={
                name: _make_missing_corner(name)
                for name in ("top_left", "top_right", "bottom_left", "bottom_right")
            }
        )

    top_i = int(valid_rows[0])
    bot_i = int(valid_rows[-1])

    def make(name: str, x: float, yi: float, angle: np.ndarray | None, curv: np.ndarray | None, idx: int) -> CornerDescriptor:
        angle_value = float(angle[idx]) if angle is not None and np.isfinite(angle[idx]) else float("nan")
        curv_value = float(curv[idx]) if curv is not None and np.isfinite(curv[idx]) else float("nan")
        support_count = int(sum(
            [
                np.isfinite(x),
                np.isfinite(yi),
                np.isfinite(angle_value),
                np.isfinite(curv_value),
            ]
        ))
        confidence = support_count / 4.0
        return CornerDescriptor(
            name=name,
            position_nm=(float(x), float(yi)),
            tangent_angle_deg=angle_value,
            curvature_inv_nm=curv_value,
            radius_like_nm=_radius_like_from_curvature(curv_value),
            confidence=float(confidence),
            support_count=support_count,
        )

    corners = {
        "top_left": make("top_left", float(left[top_i]), float(y[top_i]), left_angle, left_curv, top_i),
        "top_right": make("top_right", float(right[top_i]), float(y[top_i]), right_angle, right_curv, top_i),
        "bottom_left": make("bottom_left", float(left[bot_i]), float(y[bot_i]), left_angle, left_curv, bot_i),
        "bottom_right": make("bottom_right", float(right[bot_i]), float(y[bot_i]), right_angle, right_curv, bot_i),
    }
    return CornerBundle(corners=corners)


def build_corner_bundle_from_obs2d(obs: Obs2D) -> CornerBundle:
    profiles = build_profile_bundle_from_obs2d(obs)
    return build_corner_bundle_from_profiles(profiles)
