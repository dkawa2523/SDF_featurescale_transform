# AGENTS.md for wafergeo/observe/

## Focus
Obs2D, generic observer outputs, profile functions, corner descriptors.

## Rules
- `distance_semantics` is mandatory
- open contours stay unsigned by default
- observer names remain generic
- profile names are geometry-based, not process-name-based
