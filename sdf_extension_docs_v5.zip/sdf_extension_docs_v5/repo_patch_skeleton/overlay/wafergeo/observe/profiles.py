from __future__ import annotations

from typing import Iterable

import numpy as np

from wafergeo.observe.contracts import Obs2D, ProfileBundle


def _nan_array(length: int) -> np.ndarray:
    return np.full((length,), np.nan, dtype=np.float32)


def _edge_positions_from_mask(
    mask2d: np.ndarray,
    spacing_nm_yx: tuple[float, float],
    origin_nm_yx: tuple[float, float],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    mask = np.asarray(mask2d, dtype=bool)
    Y, X = mask.shape
    dy, dx = float(spacing_nm_yx[0]), float(spacing_nm_yx[1])
    origin_y, origin_x = float(origin_nm_yx[0]), float(origin_nm_yx[1])

    y_nm = origin_y + np.arange(Y, dtype=np.float32) * dy
    left_nm = _nan_array(Y)
    right_nm = _nan_array(Y)

    for y in range(Y):
        xs = np.where(mask[y])[0]
        if xs.size:
            left_nm[y] = origin_x + xs[0] * dx
            right_nm[y] = origin_x + xs[-1] * dx

    return y_nm, left_nm, right_nm


def _finite_gradient(values: np.ndarray, coordinate_nm: np.ndarray) -> np.ndarray:
    out = _nan_array(values.shape[0])
    finite = np.isfinite(values)
    if finite.sum() < 3:
        return out
    idx = np.where(finite)[0]
    grads = np.gradient(values[idx].astype(np.float64), coordinate_nm[idx].astype(np.float64))
    out[idx] = np.asarray(grads, dtype=np.float32)
    return out


def _curvature_x_of_y(x_nm: np.ndarray, y_nm: np.ndarray) -> np.ndarray:
    kappa = _nan_array(x_nm.shape[0])
    finite = np.isfinite(x_nm)
    if finite.sum() < 5:
        return kappa
    idx = np.where(finite)[0]
    x = x_nm[idx].astype(np.float64)
    y = y_nm[idx].astype(np.float64)
    dx_dy = np.gradient(x, y)
    d2x_dy2 = np.gradient(dx_dy, y)
    curv = d2x_dy2 / np.power(1.0 + dx_dy**2, 1.5)
    kappa[idx] = np.asarray(curv, dtype=np.float32)
    return kappa


def build_profile_bundle_from_mask(
    mask2d: np.ndarray,
    spacing_nm_yx: tuple[float, float],
    origin_nm_yx: tuple[float, float] = (0.0, 0.0),
    *,
    coordinate_name: str = "y_nm",
) -> ProfileBundle:
    """Extract generic geometry profiles from a binary 2D slice.

    The output intentionally uses generic geometry names so the same contract can describe
    etch, deposition, or measurement-driven shapes.
    """

    y_nm, left_nm, right_nm = _edge_positions_from_mask(mask2d, spacing_nm_yx, origin_nm_yx)
    dx = float(spacing_nm_yx[1])
    width_nm = np.where(np.isfinite(left_nm) & np.isfinite(right_nm), right_nm - left_nm + dx, np.nan).astype(np.float32)
    center_nm = np.where(np.isfinite(left_nm) & np.isfinite(right_nm), 0.5 * (left_nm + right_nm), np.nan).astype(np.float32)

    slope_left = _finite_gradient(left_nm, y_nm)
    slope_right = _finite_gradient(right_nm, y_nm)
    wall_angle_left_deg = np.degrees(np.arctan(slope_left)).astype(np.float32)
    wall_angle_right_deg = np.degrees(np.arctan(slope_right)).astype(np.float32)
    curvature_left_inv_nm = _curvature_x_of_y(left_nm, y_nm)
    curvature_right_inv_nm = _curvature_x_of_y(right_nm, y_nm)

    values = {
        "left_edge_x_nm": left_nm,
        "right_edge_x_nm": right_nm,
        "width_nm": width_nm,
        "center_x_nm": center_nm,
        "left_wall_angle_deg": wall_angle_left_deg,
        "right_wall_angle_deg": wall_angle_right_deg,
        "left_curvature_inv_nm": curvature_left_inv_nm,
        "right_curvature_inv_nm": curvature_right_inv_nm,
    }
    support = {
        name: np.isfinite(value) for name, value in values.items()
    }
    diagnostics = {
        "valid_rows": int(np.isfinite(width_nm).sum()),
        "row_count": int(width_nm.shape[0]),
    }
    return ProfileBundle(
        coordinate_name=coordinate_name,
        coordinate_nm=y_nm.astype(np.float32),
        values={k: v.astype(np.float32, copy=False) for k, v in values.items()},
        support_mask=support,
        diagnostics=diagnostics,
    )


def build_profile_bundle_from_obs2d(obs: Obs2D) -> ProfileBundle:
    if obs.mask2d is not None:
        mask = obs.mask2d.astype(bool)
    elif obs.meta.get("distance_semantics") == "signed":
        mask = obs.distance2d_nm < 0
    else:
        raise ValueError("cannot infer mask from an unsigned Obs2D without mask2d")
    return build_profile_bundle_from_mask(mask, obs.spacing_nm_yx, obs.origin_nm_yx)


def select_profile_channels(bundle: ProfileBundle, names: Iterable[str]) -> ProfileBundle:
    selected = list(names)
    return ProfileBundle(
        coordinate_name=bundle.coordinate_name,
        coordinate_nm=bundle.coordinate_nm,
        values={name: bundle.values[name] for name in selected},
        support_mask={name: bundle.support_mask[name] for name in selected},
        diagnostics=dict(bundle.diagnostics),
    )
