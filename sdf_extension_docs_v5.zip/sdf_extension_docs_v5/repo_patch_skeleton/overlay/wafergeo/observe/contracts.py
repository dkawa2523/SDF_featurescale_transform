from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


@dataclass
class Obs2D:
    grid2d_shape_yx: tuple[int, int]
    spacing_nm_yx: tuple[float, float]
    origin_nm_yx: tuple[float, float]
    axis_order: str
    distance2d_nm: np.ndarray
    mask2d: np.ndarray | None = None
    contours_xy_nm: list[np.ndarray] | None = None
    confidence: np.ndarray | None = None
    transform: dict[str, Any] | None = None
    debug_maps: dict[str, np.ndarray] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.distance2d_nm.shape != self.grid2d_shape_yx:
            raise ValueError("distance2d_nm shape must equal grid2d_shape_yx")
        if self.distance2d_nm.dtype != np.float32:
            raise ValueError("distance2d_nm must be float32")
        if self.meta.get("distance_semantics") not in {"signed", "unsigned"}:
            raise ValueError("meta['distance_semantics'] must be 'signed' or 'unsigned'")
        if self.mask2d is not None and self.mask2d.shape != self.grid2d_shape_yx:
            raise ValueError("mask2d shape must equal grid2d_shape_yx")
        if self.confidence is not None and self.confidence.shape != self.grid2d_shape_yx:
            raise ValueError("confidence shape must equal grid2d_shape_yx")
        if self.contours_xy_nm is not None:
            for contour in self.contours_xy_nm:
                if contour.ndim != 2 or contour.shape[1] != 2:
                    raise ValueError("each contour must have shape [N,2]")
        for key, value in self.debug_maps.items():
            if value.shape != self.grid2d_shape_yx:
                raise ValueError(f"debug_maps[{key}] shape must equal grid2d_shape_yx")


@dataclass
class ProfileBundle:
    coordinate_name: str
    coordinate_nm: np.ndarray
    values: dict[str, np.ndarray]
    support_mask: dict[str, np.ndarray]
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.coordinate_nm.ndim != 1:
            raise ValueError("coordinate_nm must be 1D")
        k = self.coordinate_nm.shape[0]
        for name, value in self.values.items():
            if value.shape != (k,):
                raise ValueError(f"values[{name}] must have shape ({k},)")
        for name, value in self.support_mask.items():
            if value.shape != (k,):
                raise ValueError(f"support_mask[{name}] must have shape ({k},)")


@dataclass(frozen=True)
class CornerDescriptor:
    name: str
    position_nm: tuple[float, float]
    tangent_angle_deg: float
    curvature_inv_nm: float
    radius_like_nm: float
    confidence: float
    support_count: int


@dataclass
class CornerBundle:
    corners: dict[str, CornerDescriptor] = field(default_factory=dict)
