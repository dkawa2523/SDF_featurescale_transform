# integration notes

## 1. 既存 repo に対する基本姿勢
- additive new files を優先
- 既存 API をすぐ消さない
- legacy path は shim で残す
- final public contract を docs で先に固定する

## 2. 既存ファイルで想定する軽微な変更

### `wafergeo/__init__.py`
必要であれば `core` を export 対象に追加する。
ただし direct submodule import が使えるなら必須ではない。

### `wafergeo/sdf/edt.py`
既存関数はそのまま活かし、
新しい `distance_api.py` から capability-aware facade を提供する。

### `wafergeo/sdf/tsdf.py`
legacy TSDF helper として残し、
new code は `Field3D -> DistanceViews` へ誘導する。

### `wafergeo/observe/*`
新しい `contracts.py`, `profiles.py`, `corners.py` を additive で追加し、
既存 observer 実装から段階的に使用する。

### `wafergeo/metrics/*`
新しい decomposed metrics を additive で追加し、
legacy scalar evaluator は後段で shim 化する。

## 3. 先に入れると実装品質が上がるもの
- root AGENTS
- nested AGENTS
- `docs/sdf_extension/*`
- `codex_assets/skills/*`

## 4. すぐには入れなくてよいもの
- optional exact backends の fully wired support
- final scalarization defaults
- nonrigid alignment
- heavy mesh route
