# repo patch skeleton

このディレクトリは、`SDF_featurescale_transform` へ重ねる **overlay 形式の実装雛形** です。

## 構成

- `STATUS_MATRIX.md`
  - file ごとの ready level
- `INTEGRATION_NOTES.md`
  - 既存 repo へどうつなぐか
- `overlay/`
  - repo root へ重ねるファイル群

## 適用順

1. `overlay/AGENTS.md`
2. `overlay/docs/sdf_extension/*`
3. nested `overlay/**/AGENTS.md`
4. `overlay/wafergeo/sdf/distance_api.py`
5. `overlay/wafergeo/core/*.py`
6. `overlay/wafergeo/observe/*.py`
7. `overlay/wafergeo/sem/obs2d_from_contour.py`
8. `overlay/wafergeo/metrics/*.py`
9. `overlay/wafergeo/surrogate/export_v2.py`
10. `overlay/tests/*.py`

## 使い方

- human が読む場合: `STATUS_MATRIX.md` と `INTEGRATION_NOTES.md` から読む
- Codex に読ませる場合: `22_repo_patch_skeleton_overview.md` と一緒に attach
- repo に適用する場合: additive file を先に、replacement は review してから
