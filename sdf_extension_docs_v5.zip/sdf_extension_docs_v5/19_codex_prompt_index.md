# 19. Codex prompt index

本章は、同梱した prompt の索引です。  
**どの順で使うか / どの reviewer を並列に回すか / どの skill が相性よいか** を一目で分かるようにしています。

---

## 1. master / reviewer prompt

| Prompt | 用途 | 推奨 mode |
|---|---|---|
| `00_master_orchestrator.md` | 全体計画、次の issue 選定、PR 切り方 | ask |
| `90_review_architect.md` | architecture / schema / compatibility review | ask |
| `91_review_ds_process.md` | observability / geometry / loss value review | ask |
| `92_review_tests_and_regression.md` | unit / regression / synthetic / CI review | ask |
| `93_review_docs_and_artifacts.md` | docs / artifact / sample review | ask |
| `94_pr_body_and_finish.md` | PR 本文、受け入れ条件整理、未完了整理 | ask or code |

---

## 2. Issue prompt 一覧

| Prompt file | Issue | Task | 目的 | 推奨 reviewer | 相性のよい skill |
|---|---|---|---|---|---|
| 01_I-01_fail-fast-validation-effective-spec.md | I-01 | T0-01/T0-02 | Spec と実装のズレを無くし、「設定できるが効かない」を禁止する。artifact に effective_spec と schema_version を残す。 | 90_review_architect, 92_review_tests_and_regression | wafergeo-core-architecture, wafergeo-regression-goldens |
| 02_I-02_backend-capability-registry.md | I-02 | T0-01 | 選べるように見えるが実際には使えない backend を API 上から排除し、available_backends/capabilities を明示する。 | 90_review_architect, 92_review_tests_and_regression | wafergeo-core-architecture, wafergeo-field3d-builder |
| 03_I-03_field3d-core-builder.md | I-03 | T1-01 | TSDF ではなく raw signed distance を canonical geometry とする最小の Field3D 抽象を導入する。 | 90_review_architect, 91_review_ds_process, 92_review_tests_and_regression | wafergeo-core-architecture, wafergeo-field3d-builder |
| 04_I-04_exact-distance-api.md | I-04 | T1-02 | signed / unsigned, spacing-aware, exact distance 生成 API を明確化し、Field3D と Obs2D の両方から使いやすくする。 | 90_review_architect, 92_review_tests_and_regression | wafergeo-field3d-builder, wafergeo-sem-obs2d |
| 05_I-05_tsdf-views-legacy-shim.md | I-05 | T1-03 | raw SDF canonical を保ったまま、small / mid / large の 3-scale TSDF view を安定生成し、既存 TSDF 資産を view として再利用する。 | 90_review_architect, 91_review_ds_process, 92_review_tests_and_regression | wafergeo-core-architecture, wafergeo-field3d-builder |
| 06_I-06_canonical-role-mapping.md | I-06 | T1-04 | 材料名やプロセス名の爆発を core に持ち込まず、raw material -> canonical role を spec で制御できるようにする。 | 90_review_architect, 91_review_ds_process | wafergeo-core-architecture, wafergeo-field3d-builder |
| 07_I-07_sem-obs2d-signed-unsigned.md | I-07 | T2-01 | open contour を無理に閉じず、polyline から unsigned distance2d、mask から signed distance2d を統一 API で扱えるようにする。 | 90_review_architect, 91_review_ds_process, 92_review_tests_and_regression | wafergeo-sem-obs2d, wafergeo-process-geometry-review |
| 08_I-08_similarity2d-alignment.md | I-08 | T2-02 | SEM と simulation の最小限の幾何整合を generic な 2D similarity transform 1 本で扱う。 | 90_review_architect, 92_review_tests_and_regression | wafergeo-sem-obs2d, wafergeo-core-architecture |
| 09_I-09_observerbundle.md | I-09 | T2-03 | observer kind を増やしすぎずに、topdown / center slice / orthogonal slice / profiles を標準束として扱う。 | 90_review_architect, 91_review_ds_process, 92_review_tests_and_regression | wafergeo-sem-obs2d, wafergeo-process-geometry-review |
| 10_I-10_generic-profiles.md | I-10 | T3-01 | etch / deposition の重要差を process-specific API ではなく width(z), wall_angle(z), curvature(z), gap(z), thickness(z) の generic function に落とす。 | 91_review_ds_process, 92_review_tests_and_regression | wafergeo-metricbundle-profiles-corners, wafergeo-process-geometry-review |
| 11_I-11_generic-corners.md | I-11 | T3-02 | top/bottom corner の位置・接線・曲率・radius-like を generic に抽出し、bottom rounding や footing 差を見えるようにする。 | 91_review_ds_process, 92_review_tests_and_regression | wafergeo-metricbundle-profiles-corners, wafergeo-process-geometry-review |
| 12_I-12_metricbundle.md | I-12 | T3-03/T3-04 | 評価の中心を CD 単体から field + curve + profile + corner (+ optional topology) の bundle へ上げる。 | 90_review_architect, 91_review_ds_process, 92_review_tests_and_regression | wafergeo-metricbundle-profiles-corners, wafergeo-process-geometry-review, wafergeo-regression-goldens |
| 13_I-13_assimilation-metricbundle-objective.md | I-13 | T4-01 | optimizer 本体ではなく objective evaluator を強くし、simulation result + SEM obs + spec -> total score + diagnostics を返せるようにする。 | 90_review_architect, 91_review_ds_process, 93_review_docs_and_artifacts | wafergeo-core-architecture, wafergeo-metricbundle-profiles-corners, wafergeo-sem-obs2d |
| 14_I-14_surrogate-export-v2.md | I-14 | T4-02/T4-03 | どのモデルで学ぶかを core から切り離し、同一 sample から dense/query/mesh/Obs2D/profile を export できる V2 パッケージを作る。 | 90_review_architect, 91_review_ds_process, 93_review_docs_and_artifacts | wafergeo-surrogate-export-v2, wafergeo-core-architecture |
| 15_I-15_synthetic-goldens-regression.md | I-15 | TX-01 | 実装が動くだけでなく、説明できて regression で守れる状態にする。 | 92_review_tests_and_regression, 93_review_docs_and_artifacts | wafergeo-regression-goldens, wafergeo-metricbundle-profiles-corners |
| 16_I-16_optional-exact-backends.md | I-16 | T5-01 | SciPy exact を core のままにしつつ、optional な ITK / CuPy exact backend を capability-gated で追加する。 | 90_review_architect, 92_review_tests_and_regression, 93_review_docs_and_artifacts | wafergeo-field3d-builder, wafergeo-core-architecture |
| 17_I-17_interface-fields.md | I-17 | T5-02 | selected role pair に対する continuous interface field を optional に持てるようにし、default core を複雑にしすぎない。 | 90_review_architect, 91_review_ds_process | wafergeo-core-architecture, wafergeo-process-geometry-review |
| 18_I-18_sparse-adaptive-watchlist.md | I-18 | T5-03 | 大規模化向け sparse / adaptive storage の拡張余地を設計 docs と extension point として整理し、本実装は入れない。 | 90_review_architect, 93_review_docs_and_artifacts | wafergeo-core-architecture |

---

## 3. 推奨順

```mermaid
flowchart LR
    A[01 I-01] --> B[02 I-02]
    B --> C[03 I-03]
    C --> D[04 I-04]
    D --> E[05 I-05]
    E --> F[07 I-07]
    E --> G[06 I-06]
    F --> H[08 I-08]
    F --> I[09 I-09]
    I --> J[10 I-10]
    I --> K[11 I-11]
    J --> L[12 I-12]
    K --> L
    L --> M[13 I-13]
    L --> N[14 I-14]
    M --> O[15 I-15]
    N --> O
    O --> P[16 I-16 / 17 I-17 / 18 I-18]
```

---

## 4. 最初に使うべき prompt

最初の 3 本は次です。

1. `00_master_orchestrator.md`
2. `01_I-01_fail-fast-validation-effective-spec.md`
3. `03_I-03_field3d-core-builder.md`

この 3 本で

- plan
- fail-fast / schema hygiene
- canonical geometry

が揃います。

---

## 5. reviewer prompt の使い分け

### Architect reviewer を優先
- I-01, I-02, I-03, I-05, I-08, I-12, I-13, I-14, I-16, I-17, I-18

### DS / Process reviewer を優先
- I-03, I-05, I-07, I-09, I-10, I-11, I-12, I-13, I-14, I-17

### QA reviewer を優先
- I-01, I-02, I-03, I-04, I-05, I-07, I-08, I-09, I-10, I-11, I-12, I-15, I-16

### Docs / Artifact reviewer を優先
- I-13, I-14, I-15, I-16, I-18

---

## 6. prompt_manifest の役割

`codex_assets/prompts/prompt_manifest.json` には、各 prompt の

- issue id
- task id
- phase
- mode
- reasoning
- internet
- branch
- reviewers
- skills
- docs
- target files

を機械可読でまとめています。  
簡易スクリプトや外部オーケストレーションで使いたい場合は、こちらを参照してください。

---

## 7. まとめ

prompt は **1 issue 1 prompt** にしてあるので、  
Orchestrator で順番を決め、issue prompt で実装し、reviewer prompt で補正する、  
という流れが最も扱いやすいです。
