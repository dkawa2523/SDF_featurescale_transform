# 03. 手法詳細: Field / Observer / Metric / Profile / Corner（v3 詳細版）

本章では、拡張版で採用すべき手法を **「何を計算するか」だけでなく、「なぜそれが必要か」「何を見えるようにするか」** まで含めて詳しく説明します。

狙いは、プロセスごとに専用アルゴリズムを増やすのではなく、  
**汎用幾何関数と観測基底で semiconductor profile を捉えること** です。

---

## 1. この章で扱う視点

この章では、次の 4 つを結び付けて説明します。

1. 半導体加工で重要な形状差  
2. それを表す geometry quantity  
3. その quantity をどの observer で観測するか  
4. どの metric で loss 化するか  

つまり、単なる数式説明ではなく、**工程現象 → geometry → observation → loss** の流れで整理します。

---

## 2. まず、何が「見えていない」のか

CD ベース評価が悪いわけではありません。  
むしろ多くのライン形状では、CD は非常に有効です。  
問題は、CD が **1 次元の幅情報に強く圧縮された量** だという点です。

そのため、次のようなケースを見逃しやすいです。

| ケース | CD は合うか | 実際の問題 |
|---|---:|---|
| 側壁が中腹でふくらむ bowing | 合うことがある | 深さ依存 profile が違う |
| bottom rounding が強い | 合うことがある | 底部の加工状態が悪い |
| microtrench が出ている | 合うことがある | 底角部の掘れすぎが見えない |
| sidewall angle が違う | 合うことがある | エッチや成膜の制御状態が違う |
| 平均膜厚は合うが入口 overhang が違う | 合うことがある | pinch-off リスクが見えない |
| open SEM contour を無理に closed mask にした | 一見比較できる | 観測意味が歪む |

したがって、改善すべきは「重み」より先に **observable** です。

---

## 3. 半導体加工形状を generic geometry へ落とす

本提案の中心思想は、process 固有語を core API に入れないことです。  
その代わり、工程で重要な違いを **generic geometry function** に落とします。

### 3.1 エッチングで重要な差
- `width(z)`
- `center_shift(z)`
- `wall_angle_left(z)`, `wall_angle_right(z)`
- `curvature_left(z)`, `curvature_right(z)`
- `bottom_corner_radius_like`
- `top_corner_radius_like`

### 3.2 成膜で重要な差
- `gap(z)` あるいは `remaining_opening(z)`
- `thickness_top`
- `thickness_side(z)`
- `thickness_bottom`
- `closure_height`
- `corner_thickening`

### 3.3 共通に見えるようにする
これらをまとめると、最終的に必要なのは次の関数族です。

| 関数族 | 意味 | 典型用途 |
|---|---|---|
| `width(z)` | 左右境界間の距離 | CD, bowing, necking, gap |
| `centerline(z)` | 形状中心位置 | 非対称変形 |
| `wall_angle(z)` | 側壁の傾き | verticality / taper |
| `curvature(z)` | 局所丸みや屈曲 | rounding, scalloping |
| `pair_separation(z)` | 2界面間距離 | thickness, gap |
| `corner_descriptor` | 角部位置・接線・半径様量 | bottom edge, top edge |

この形に落とせば、process 専用 metric を作らなくても、  
etch と deposition の両方をかなり自然に扱えます。

---

## 4. raw SDF / TSDF / UDF の役割分担

### 4.1 raw signed distance

\[
\phi(\mathbf{x}) =
\begin{cases}
-\mathrm{dist}(\mathbf{x}, \partial \Omega) & \mathbf{x} \in \Omega \\
+\mathrm{dist}(\mathbf{x}, \partial \Omega) & \mathbf{x} \notin \Omega
\end{cases}
\]

#### 強み
- inside / outside が明確
- zero level set が境界そのもの
- 法線や曲率へつなぎやすい
- implicit / mesh / observer / loss に跨って意味が安定

#### 弱み
- dynamic range が大きい
- open contour には不向き
- 学習入力としては帯域制限した方が扱いやすいことが多い

#### 本提案での位置づけ
- **canonical**
- geometry core が保持する基準量

### 4.2 TSDF

\[
\mathrm{TSDF}_{\mu}(\mathbf{x}) = \frac{\mathrm{clip}(\phi(\mathbf{x}), -\mu, +\mu)}{\mu}
\]

#### 強み
- narrow band を強調できる
- loss が安定しやすい
- outlier を飽和で抑えられる

#### 弱み
- `mu` に強く依存
- 飽和領域の情報が落ちる
- 単一 `mu` だと multi-scale detail と相性が悪い

#### 本提案での位置づけ
- **view**
- `small / mid / large` の固定3スケールを推奨

### 4.3 UDF
UDF は unsigned distance です。

\[
u(\mathbf{x}) = \mathrm{dist}(\mathbf{x}, \Gamma)
\]

#### 強み
- open contour / open surface に自然
- SEM 輪郭のような部分観測に向く
- closed mask を無理に作らなくてよい

#### 弱み
- inside/outside が分からない
- signed geometry より情報量が少ない
- 3D canonical の中心にはしにくい

#### 本提案での位置づけ
- `Field3D` では optional
- `Obs2D` では first-class

---

## 5. なぜ 3 スケール TSDF が良いのか

単一 `mu` では、局所角部と大域 profile を同時にうまく表せないことが多いです。  
そこで `mu_small / mu_mid / mu_large` の 3 スケール view を持たせます。

### 5.1 役割分担
- `small`: 角部、bottom rounding、microtrench、thin film
- `mid`: 普通の断面比較
- `large`: 大域 profile、全体の位置ずれや broad shape

### 5.2 推奨設計
- canonical: raw SDF
- views:
  - `tsdf_small = clip(phi, -5, 5)/5`
  - `tsdf_mid = clip(phi, -20, 20)/20`
  - `tsdf_large = clip(phi, -80, 80)/80`

数値は nm 例であり、実プロセスに合わせて調整します。  
ただし、**その場しのぎで sample ごとに変えない** 方がよいです。

### 5.3 固定スケールにする理由
- dataset 全体で意味が揃う
- downstream 学習が安定
- metric の解釈が保ちやすい
- spec が複雑化しない

---

## 6. subvoxel / soft boundary をどう扱うか

### 6.1 問題
voxel label からそのまま EDT を取ると、角部や曲面が cell-centered に量子化されます。  
nm スケールではこの誤差が無視できないことがあります。

### 6.2 解決の考え方
本基盤では、まず次の優先順位で geometry を受けます。

1. mesh / polyline など明示境界
2. supersampled occupancy
3. hard voxel label

### 6.3 実装として重くしすぎないための方針
複雑な subvoxel reconstruction を core に入れすぎると重くなります。  
そこで first step では次だけを推奨します。

- 2D SEM: **analytic polyline distance**
- 3D simulation: **exact EDT + spacing 対応**
- 必要なら upstream で supersampling してから Field3D builder へ渡す

つまり、subvoxel への道を開きつつ、core は過剰に複雑にしません。

---

## 7. exact distance backend の考え方

### 7.1 なぜ exact が必要か
SDF の canonical や評価の基準が近似距離だと、  
どこまでが geometry 差でどこからが DT 近似誤差かが曖昧になります。

そのため、基準実装は exact EDT を優先します。

### 7.2 backend 候補
- SciPy exact EDT (`Ref-B01`)
- ITK Signed Maurer (`Ref-B03`)
- CuPy exact EDT (`Ref-B02`) を optional backend に

### 7.3 使い分け
- 基準 / test / artifact 生成: exact
- 大量候補探索や試作: optional approximate も可
- ただし approximate を評価基準にしない

---

## 8. Observer の設計と役割

Observer は geometry から comparison domain を作る層です。  
本提案では observer kind 自体は増やさず、  
`topdown_exposed + slice + profile/corner extractor` を基本にします。

---

## 9. `topdown_exposed` の考え方

### 9.1 何を見る observer か
topdown では、観測方向から最初に見える面を見ます。  
出力として重要なのは次です。

- exposed role id
- top height map
- 必要なら selected role の 2D distance field
- debug 用 mask / contour

### 9.2 何に効くか
- top opening の違い
- entrance narrowing / overhang
- 露出材料の違い
- top corner の差

### 9.3 何に弱いか
- buried sidewall の差
- bottom rounding
- trench 内部の profile
- seam/void の内部状態

したがって、topdown 単独では不十分で、slice が必要です。

### 9.4 実装イメージ
1. 観測軸に沿って走査
2. 各 `(y,x)` で最初に非 void の voxel / zero-crossing を見つける
3. その role id と height を記録
4. 2D distance field が必要なら selected role の mask から構築
5. contour や confidence を付加して `Obs2D` 化

---

## 10. `slice` の考え方

### 10.1 何を見る observer か
断面 observer です。  
中心断面、直交断面、または指定位置の断面を取ります。

### 10.2 なぜ重要か
半導体形状の本質的な差の多くは断面に現れます。

- wall angle
- bowing / necking
- bottom rounding
- microtrench
- film thickness
- closure gap

### 10.3 実装方針
- 1 pixel 厚 slice だけでなく `slab_thickness_nm` を許す
- slab 内は union / OR 集約を基本とする
- output は `Obs2D.distance2d_nm`
- signed / unsigned は source に応じて明示する

### 10.4 `slice` は raw contour 生成だけにしない
単に contour を出すだけでなく、  
後段の profile/corner 抽出が再利用できるよう、**distance2d を first-class** にします。

---

## 11. Profile 抽出の設計

Profile は、この拡張案の中心です。  
ここで重要なのは、「プロセス別関数」ではなく「generic 関数族」として定義することです。

### 11.1 入力
通常は断面 `Obs2D` から抽出します。  
入力候補は以下です。

- signed `distance2d_nm`
- contour polyline
- 必要なら補助 mask

### 11.2 出力
```python
@dataclass
class ProfileBundle:
    coordinate_nm: np.ndarray          # usually z grid
    values: dict[str, np.ndarray]      # width, angle, curvature, ...
    support_mask: dict[str, np.ndarray]
    diagnostics: dict[str, Any]
```

### 11.3 推奨する first-class profile
| 名称 | 定義 | 用途 |
|---|---|---|
| `width(z)` | 左右境界間距離 | CD, bowing, gap |
| `centerline(z)` | 左右平均位置 | 非対称 profile |
| `wall_angle_left(z)` | 左壁接線角 | etch/deposition verticality |
| `wall_angle_right(z)` | 右壁接線角 | 同上 |
| `curvature_left(z)` | 左壁曲率 | rounding, scalloping |
| `curvature_right(z)` | 右壁曲率 | 同上 |
| `pair_separation(z)` | 2界面間距離 | thickness / gap |
| `closure_ratio(z)` | opening の残存率 | pinch-off / seam 評価 |

### 11.4 `width(z)` の具体的意味
各深さ `z` で、断面の左右境界位置 `x_left(z), x_right(z)` を取り、

\[
\mathrm{width}(z) = x_{right}(z) - x_{left}(z)
\]

と定義します。

#### これで見えるもの
- CD
- bowing
- necking
- top / bottom taper
- gap fill 中の残 opening

### 11.5 `wall_angle(z)` の定義
左右境界位置関数を `x(z)` として、傾きを取ります。

\[
\theta(z) = \arctan\left(\frac{dx}{dz}\right)
\]

実装では差分ノイズを抑えるため、  
先に boundary curve を smoothing し、その後に差分を取ります。

### 11.6 `curvature(z)` の定義
曲率は、局所丸みや scalloping を捉えるために使います。  
離散曲線上では、平滑化後の一階・二階差分から求めるか、  
局所 3 点 / 5 点円フィットで求めます。

\[
\kappa(z) \approx \frac{x''(z)}{(1 + x'(z)^2)^{3/2}}
\]

### 11.7 `pair_separation(z)` の意味
2 本の boundary curve `a(z), b(z)` の separation を generic に取る関数です。

- trench の左右壁 → `gap(z)`
- inner/outer film surface → `thickness(z)`

これにより、process-specific な分岐を増やさずに済みます。

---

## 12. Corner 抽出の設計

CD が見えない差は corner に現れることが多いです。  
bottom edge, footing, notching, rounding, top overhang などが典型です。

### 12.1 何を返すか
corner は点 1 つではなく descriptor として返します。

```python
@dataclass
class CornerDescriptor:
    name: str
    position_nm: tuple[float, float]
    tangent_angle_deg: float
    curvature_inv_nm: float
    radius_like_nm: float
    confidence: float
    support_count: int
```

### 12.2 どの corner を標準で見るか
- `top_left`
- `top_right`
- `bottom_left`
- `bottom_right`

### 12.3 実装の基本手順
1. contour を一様 arc-length 再サンプリング
2. top / bottom window を切る
3. left / right side に分割
4. 曲率が高い点を候補として抽出
5. 近傍で circle fit または接線推定
6. descriptor を返す

### 12.4 なぜ corner は重要か
field や width が合っていても、角部だけ悪いケースは珍しくありません。  
特に semiconductor では、

- bottom edge の少しの丸み
- footing/notching の局所形状
- deposition 入口の overhang

が downstream 電気特性や fill 品質に強く効きます。  
corner descriptor を loss に含めると、これらを objective に載せられます。

---

## 13. SEM 観測をどう扱うか

### 13.1 既存方針の良い点
既存 repo には、SEM 準備層で

- mask ベースの距離場
- polyline 解析距離

の両構想があります。  
この方向は非常に良いです。

### 13.2 本提案で強める点
open contour に対して、closed mask を必須にしません。  
SEM の contour が open / partial / one-sided の場合は、  
**unsigned distance2d** として保持します。

### 13.3 なぜ unsigned が必要か
closed mask に無理にすると、

- inside/outside の仮定が観測にない
- 接続部を人工的に補完してしまう
- bottom edge などの位置が歪む

という問題が起きます。

### 13.4 signed と unsigned の使い分け
- simulation side: signed が主
- SEM side: contour の性質に応じて signed または unsigned
- comparison: semantics を揃えてから行う

---

## 14. Metric の設計

本提案では、最終 loss を単一数値にする前に component を保持します。

\[
L = \lambda_f L_{field} + \lambda_c L_{curve} + \lambda_p L_{profile} + \lambda_k L_{corner} + \lambda_t L_{topology}
\]

ただし重要なのは係数ではなく、**各 component の意味が独立していること** です。

### 14.1 `L_field`
距離場の差を比較します。

\[
L_{field} = \frac{1}{|B|} \sum_{p \in B} \rho\left(\frac{d_1(p)-d_2(p)}{s_d}\right)
\]

- `B`: band mask
- `rho`: Huber / Charbonnier / L1 など
- `s_d`: 距離スケール

#### 何に効くか
- contour だけでは見えない面全体の差
- narrow band の局所的 geometry 差
- signed / unsigned 両 route に対応可能

### 14.2 `L_curve`
contour 間距離を比較します。

推奨は:
- symmetric Chamfer
- HD95
- 必要なら mean normal deviation

#### 何に効くか
- boundary 自体のずれ
- thin structure や narrow gap の差
- field と違って境界中心に効く

### 14.3 `L_profile`
generic profile 関数群の差を比較します。

\[
L_{profile} = \sum_f \frac{1}{|Z_f|}\sum_{z \in Z_f} \rho\left(\frac{f_1(z)-f_2(z)}{s_f}\right)
\]

#### 何に効くか
- CD は合うが bowing が違う
- thickness 平均は合うが bottom side が違う
- entrance overhang が違う
- verticality が違う

### 14.4 `L_corner`
角部 descriptor の差を比較します。

\[
L_{corner} = \sum_c \left[
\rho\left(\frac{\|\Delta \mathbf{x}_c\|}{s_x}\right) +
\rho\left(\frac{\Delta \theta_c}{s_\theta}\right) +
\rho\left(\frac{\Delta r_c}{s_r}\right)
\right]
\]

#### 何に効くか
- bottom rounding
- footing / notch
- top overhang
- edge localization

### 14.5 `L_topology`
必要な場合だけ optional にします。

#### 使う場面
- through-open / closure の有無が本質的
- seam/void 接続性が重要
- binary topology を preserving したい

#### なぜ optional か
常時オンにすると重くなりやすく、  
設計も複雑になりがちです。

---

## 15. `field + curve + profile + corner` が良い理由

この構成は、それぞれが補完的です。

| component | 強いもの | 弱いもの |
|---|---|---|
| `field` | 面全体の差、signed/unsigned 両対応 | 局所 boundary の解釈性 |
| `curve` | 境界位置そのもの | 内側の geometry context |
| `profile` | 深さ依存の意味ある差 | profile 定義外の自由形状 |
| `corner` | 局所 edge / rounding | 大域形状 |

CD だけでは 1 本しか見ていなかった比較軸が、  
これで 4 本に増え、しかも解釈可能な形で分解されます。

---

## 16. 既存手法との差分を明確にする

### 16.1 既存 repo 中心
- multi-material TSDF
- topdown / slice 観測
- 2D TSDF loss
- contour distance
- line-scan CD

### 16.2 拡張版中心
- raw SDF canonical
- 3-scale TSDF views
- SEM unsigned distance route
- observer bundle
- profile extraction
- corner extraction
- metric bundle
- component report

### 16.3 何が本質的に変わるか
一言で言うと、  
**「比較が '何となく合うか' から 'どの幾何量がどれだけ違うか' へ変わる」** ことです。

---

## 17. データ同化での価値

データ同化では、最終的に optimizer が objective を最小化します。  
ここで重要なのは、objective が **工程上意味のある方向** を向いているかです。

### 17.1 既存 CD 中心 objective の問題
- CD を合わせる方向へは動く
- しかし bottom rounding や sidewall angle の差が残ることがある
- objective の勾配方向が本当に欲しい geometry とずれることがある

### 17.2 拡張版の価値
`field + curve + profile + corner` にすると、

- broad alignment は `field`
- contour localization は `curve`
- depth-dependent profile は `profile`
- local edge quality は `corner`

がそれぞれ押してくれるため、  
**SEM と simulation の整合を、より工程妥当な形で最適化へ渡せます。**

---

## 18. サロゲート学習での価値

サロゲート学習では、何を教師にするかが重要です。  
本提案の強みは、同じ sample から複数 teacher を作れることです。

### 18.1 出せる teacher
- raw SDF
- multi-scale TSDF
- 2D signed/unsigned distance map
- contour polyline
- profile table
- corner table
- query samples
- mesh

### 18.2 これがなぜ重要か
学習器は一つではありません。

- dense 3D CNN
- point/query based model
- mesh/graph model
- implicit neural field
- operator model

それぞれが好む teacher 形式が異なります。  
canonical を raw SDF にして export を多様化すると、  
**core を変えずに downstream を選び直せます。**

---

## 19. 推奨 default 設定

最初の導入では、次を推奨します。

### 19.1 distance view
- raw SDF: 保存
- TSDF: `small=5nm, mid=20nm, large=80nm`
- logsigned: off
- tanh: off

### 19.2 observers
- `topdown_exposed`: on
- `center_slice`: on
- `orthogonal_slice`: on
- `extra_slices`: 必要時のみ

### 19.3 metrics
- `field`: on
- `curve`: on
- `profile`: on
- `corner`: on
- `topology`: off (初期は optional)

### 19.4 robustness
- field: Charbonnier
- profile: Huber
- corner: Huber
- support coverage を必ず report

---

## 20. よくある失敗と対策

### 20.1 signed / unsigned を混ぜる
**失敗:** simulation の signed と SEM の unsigned をそのまま比較  
**対策:** semantics を合わせる。unsigned route なら両側 unsigned へ。

### 20.2 contour のノイズを角部差と誤認する
**失敗:** raw curvature max をそのまま corner に使う  
**対策:** smoothing + local fit + percentile で安定化

### 20.3 profile support が少ない
**失敗:** edge crossing が十分に取れない深さまで width を比較  
**対策:** support mask を profile ごとに持ち、比較は共通 support のみ

### 20.4 view を canonical と誤解する
**失敗:** TSDF だけ保存して raw SDF を捨てる  
**対策:** raw SDF を必ず保持し、TSDF は再生成可能とする

---

## 21. 本章の結論

本章の要点は次です。

1. **工程差を process-specific API にせず、generic geometry function に落とす**
2. **canonical は raw SDF、TSDF/UDF は view**
3. **observer は増やしすぎず、bundle + profile/corner で表現力を出す**
4. **metric は field / curve / profile / corner に分けて解釈可能にする**
5. **これにより、データ同化でもサロゲートでも同じ geometry core を使える**

次章では、これを実際に既存 repo のどのファイルへどう落とし込むかを、  
**変更単位・関数単位・受け入れ条件** まで掘り下げて具体化します。
