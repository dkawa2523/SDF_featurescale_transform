# 18. Skills and prompt assets

本章では、同梱した `codex_assets/skills/` の位置づけを説明します。

---

## 1. skills を入れた理由

Issue prompt は task ごとに強いですが、  
関連する task で何度も使う **短い専門知識パック** があると便利です。

たとえば:

- core abstraction の guardrail
- Field3D / exact distance / TSDF views の要点
- SEM signed / unsigned Obs2D の要点
- profile / corner / MetricBundle の要点
- surrogate export V2 の要点
- regression goldens の要点

これらは、毎回 docs 本体を全部読ませるよりも、短い quick reference として持っておく価値があります。

---

## 2. この bundle の skills の位置づけ

skills は **第一級の設計ソースではありません**。  
位置づけは次の通りです。

1. 正本: `02`, `03`, `04`, `09`, `10`, `11`, `13`
2. guardrail: `AGENTS.md`
3. task scope: issue prompt
4. quick reference: skill

つまり、skill は docs の代替ではなく、**再読コストを下げる補助資産** です。

---

## 3. 同梱した skills

| Skill | 主用途 |
|---|---|
| `wafergeo-core-architecture` | abstraction, fail-fast, schema, compatibility |
| `wafergeo-field3d-builder` | Field3D, exact distance, TSDF views, role mapping |
| `wafergeo-sem-obs2d` | signed / unsigned Obs2D, alignment, bundles |
| `wafergeo-metricbundle-profiles-corners` | profiles, corners, MetricBundle |
| `wafergeo-process-geometry-review` | semiconductor geometry meaning の review |
| `wafergeo-surrogate-export-v2` | dense/query/mesh/Obs2D/profile export |
| `wafergeo-regression-goldens` | synthetic goldens, regression, example artifacts |

---

## 4. skill の構成

各 skill は次の形にしています。

```text
skill-name/
├── SKILL.md
├── CHECKLIST.md
├── TECHNICAL.md / FILES.md / EXAMPLES.md ...
```

### `SKILL.md`
- short description
- when to use
- quick reference
- linked detail files

### detail files
- deeper notes
- checklist
- target files
- examples

---

## 5. この bundle の skill をどう使うか

### 使い方 A: skill discovery がある環境
- Codex が custom skill を読める場合は、そのまま skill として使う

### 使い方 B: skill discovery がない環境
- `SKILL.md` を普通の参照文書として prompt に添付する
- 必要なら detail file だけ追加で読ませる

この 2 通りを想定しているので、どちらでも使えます。

---

## 6. skill を使うべき場面

### 6.1 繰り返し同じ観点で review したい
reviewer prompt に加えて relevant skill を読ませると、観点がぶれにくくなります。

### 6.2 docs 全部を毎回読みたくない
Issue prompt の前に संबंधित skill を読ませると、必要な要点だけ先に入れられます。

### 6.3 reviewer ごとに観点を揃えたい
Architect reviewer には `wafergeo-core-architecture`  
DS / Process reviewer には `wafergeo-process-geometry-review`  
といった使い方ができます。

---

## 7. この bundle で skill を optional にした理由

skill の自動発見や install 方法は、使用環境に依存します。  
そのため、この bundle では **skill が無くても全部進められる** ようにしています。

必須なのは:

- docs bundle
- AGENTS.md
- issue prompt

skill はあくまで補助です。

---

## 8. まとめ

skills は、この repo では **軽量な専門知識キャッシュ** として使うのが最も効果的です。  
常駐ルールは AGENTS、task 条件は issue prompt、反復的な quick reference は skill、  
という棲み分けが扱いやすいです。
