# 22. repo patch skeleton overview

本章は v5 で追加した `repo_patch_skeleton/` の説明です。

目的は、**設計 docs → Codex prompt → 実コード雛形** の断絶をなくし、
既存 repo へ段階的に実装を進めやすくすることです。

---

## 1. 何が入っているか

```text
repo_patch_skeleton/
  README.md
  STATUS_MATRIX.md
  INTEGRATION_NOTES.md
  overlay/
    AGENTS.md
    docs/sdf_extension/*
    wafergeo/*
    tests/*
```

### overlay の意味
- `overlay/` は **repo root に重ねる前提** です
- additive file を中心にしているため、既存 repo の破壊を最小化します
- root / nested `AGENTS.md` もここに含めています

---

## 2. 何を優先して適用するか

### wave 1: knowledge / instructions
1. `overlay/AGENTS.md`
2. `overlay/docs/sdf_extension/*`
3. nested `overlay/wafergeo/**/AGENTS.md`

### wave 2: additive core modules
1. `overlay/wafergeo/sdf/distance_api.py`
2. `overlay/wafergeo/core/roles.py`
3. `overlay/wafergeo/core/field3d.py`
4. `overlay/wafergeo/core/views.py`

### wave 3: observer / SEM / metrics
1. `overlay/wafergeo/observe/contracts.py`
2. `overlay/wafergeo/observe/profiles.py`
3. `overlay/wafergeo/observe/corners.py`
4. `overlay/wafergeo/sem/obs2d_from_contour.py`
5. `overlay/wafergeo/metrics/*.py`

### wave 4: surrogate / tests
1. `overlay/wafergeo/surrogate/export_v2.py`
2. `overlay/tests/test_*.py`

---

## 3. skeleton の位置づけ

この skeleton は 3 種類に分かれます。

| 種類 | 状態 | 例 | 使い方 |
|---|---|---|---|
| additive / nearly-usable | かなり具体実装済み | `distance_api.py`, `views.py` | そのまま追加しやすい |
| additive / integration-needed | 既存 types と wiring が必要 | `field3d.py`, `export_v2.py` | Codex に repo に合わせて微調整させる |
| instruction assets | 実装品質を上げる補助 | `AGENTS.md`, `SKILL.md`, `docs/sdf_extension/*` | 先に導入してから code task を実行 |

---

## 4. なぜ unified diff ではなく overlay なのか

既存 repo の取得制約と、今後 upstream が変わる可能性を考えると、
**完全な置換 diff より additive overlay の方が安全** です。

特に次の理由があります。

- 既存 module の内部差分に依存しすぎない
- Codex に file-by-file で最小 patch を作らせやすい
- root AGENTS / nested AGENTS / docs knowledge base を同時に入れやすい
- downstream で採用 / 破棄の選択がしやすい

---

## 5. どこまで実装済みか

### 実装済み度が高い
- distance backend facade
- role mapping
- Field3D / DistanceViews contract
- Obs2D contract
- contour distance image (unsigned + signed via mask)
- profile / corner extraction
- field / curve / profile / corner component loss
- surrogate export manifest
- pure numpy unit tests

### intentionally 残している統合作業
- existing CLI / pipeline / report command への接続
- legacy `TSDFVolume` path との shim wiring
- exact backend optional dependency の full capability report
- assimilation objective の final scalarization policy
- existing artifact schema との migration

---

## 6. 推奨の適用方法

```mermaid
flowchart TD
    A[Copy overlay docs + AGENTS] --> B[Run docs-only Codex pass]
    B --> C[Copy additive core files]
    C --> D[Run Field3D / distance tasks]
    D --> E[Copy observe / metrics files]
    E --> F[Run observer / metric tasks]
    F --> G[Copy export / tests]
    G --> H[Run regression + docs sync]
```

---

## 7. この skeleton の価値

- docs を読んだ人間と Codex が **同じ public contract** を参照できる
- AGENTS と skills が code skeleton に対応しているので、実装 drift が減る
- observe / metric / export の骨組みが先にあるため、
  Field3D ができた時点で downstream の議論を始められる
- pure numpy test が多いので optional dependency 未導入でも着手しやすい
