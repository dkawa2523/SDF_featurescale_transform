# 01. 既存 repo の詳細分析  
**対象:** `dkawa2523/SDF_featurescale_transform` / Python package `wafergeo`

本章では、まず既存 repo の設計とコードをできるだけ正確に読み解き、  
その上で **何が強みで、何が課題で、どこが拡張の最小境界か** を整理します。

---

## 1. エグゼクティブサマリー

この repo は、見た目以上に良い土台を持っています。  
特に重要なのは、以下の 4 点です。

1. **Artifact-driven であること**  
2. **3D geometry と 2D observation を分けていること**  
3. **SEM 比較と simulation 比較を `Obs2D` に統一しようとしていること**  
4. **surrogate / assimilation を core geometry 層から分離していること**  

つまり、方向性はかなり良いです。  
問題は「思想」よりもむしろ **実装上のギャップ** と **評価基底の粗さ** にあります。

---

## 2. repo の設計思想

repo の docs を読むと、全体はおおむね次のレイヤに分かれています。

```mermaid
flowchart TD
    A[Ingest / IO] --> B[LabelVolume]
    B --> C[SDF / TSDF]
    B --> D[Mesh]
    C --> E[Observer]
    D --> E
    B --> E
    E --> F[Obs2D]
    F --> G[Metrics]
    G --> H[Assimilation]
    F --> I[Surrogate package]
    C --> I
    D --> I
```

この構造自体は非常に良いです。  
特に `Obs2D` を共通比較ドメインにする発想は、simulation と SEM を橋渡しする上で重要です。

---

## 3. 現行 repo の主要 docs と役割

| docs / file | 役割 | 読み取れること |
|---|---|---|
| `0_design.md` | 全体設計 | layer separation, artifact-driven, comparison domain の思想 |
| `2_sdf.md` | SDF/TSDF 設計 | material-wise SDF/TSDF, `d_boundary`, `pair_code` |
| `2-1_sdf_extend.md` | SDF 拡張構想 | exact EDT, Maurer, JFA, OpenVDB, mesh→SDF, polyline SDF |
| `4_observer.md` | geometry→Obs2D | Label / TSDF / Mesh を統一的に 2D 比較へ落とす発想 |
| `5_Metrics.md` | Obs2D-vs-Obs2D 指標 | 2D TSDF, contour, CD 比較の責務分離 |
| `6_SEM_prepare.md` | SEM 準備 | mask ベース距離場と polyline 解析距離の両構想 |
| `7_assimilation.md` | objective evaluator | optimizer 本体ではなく objective レイヤ |
| `8_surrogate.md` | surrogate package | 学習コードではなく教師 package generator |

---

## 4. 実コードから見た現行実装の中核

### 4.1 `wafergeo/sdf/tsdf.py`
現在の TSDF 定義は非常に明快です。

- `to_tsdf(phi, mu) = clip(phi, -mu, +mu) / mu`
- `from_tsdf(tsdf, mu) = clip(tsdf, -1, +1) * mu`
- `label_from_tsdf(...)` は最小 TSDF チャネルと priority から label を復元

つまり、**canonical がほぼ TSDF 側に寄っている** 設計です。  
raw SDF は「途中経由」で、保存・比較・学習の主役は TSDF になっています。

### 4.2 `wafergeo/sdf/edt.py`
距離変換は backend registry を介して構築され、  
`signed_distance_from_mask` は基本的に **外側 EDT - 内側 EDT** で signed distance を組み立てます。  
spacing を引数で受けられるのは良いです。

### 4.3 `wafergeo/sdf/boundary_features.py`
ここでは補助特徴として

- `d_boundary`: もっとも近い界面までの距離に相当する量
- `pair_code`: 最も近い 2 チャネルから作る離散的な材料対コード

が入ります。  
`pair_code` は多材料界面を cheap に近似するアイデアとしては良いですが、後段学習や loss にはやや粗いです。

### 4.4 `wafergeo/observe/topdown.py`
topdown observer は、上から見て最初に現れる non-ignored voxel を `exposed_id` として求め、  
同時に `height_map` を作ります。そこから、

- `mask2d`
- 2D TSDF (`tsdf2d_from_mask`)
- contour
- debug maps (`exposed_id`, `height_map`)

を生成します。

### 4.5 `wafergeo/observe/slice.py`
slice observer は `axis`, `position_nm`, `slab_thickness_nm` を基に slab を切り出し、  
その slab 内 mask を OR union して 2D 化し、そこから `tsdf2d`, contour を作ります。  
つまり現在の `slice` は **厳密な 1 枚断面の signed distance** というより、  
**slab union を 2D mask に潰して TSDF 化する経路** に寄っています。

### 4.6 `wafergeo/metrics/tsdf_loss.py`
現行 field 系の主力は narrow-band robust TSDF loss です。  
band は obs / pred / union から選び、`|tsdf|<1` を境界近傍とみなして robust residual を取ります。  
weight map を掛ける仕組みもあります。

### 4.7 `wafergeo/metrics/contour_metrics.py`
輪郭比較は双方向 Chamfer 距離中心です。  
KDTree ベースで、比較そのものはシンプルで素直です。

### 4.8 `wafergeo/metrics/cd_metrics.py`
CD metric は 1D linescan 上の zero crossing から edge を取る方式です。  
`expected_edges` と crossing 数がずれると fail 状態になり、`outer`/`inner` edge pair を選んで CD を計算します。  
この設計は「CD が主役」という思想をよく表しています。

---

## 5. 現行設計の強み

### 5.1 Artifact-driven である
半導体形状比較で重要なのは、  
「何の入力から、どの spec で、どの observer / metric を作ったか」が後で再現できることです。  
本 repo はそこを最初からかなり重視しています。

### 5.2 `Obs2D` を比較ドメインにしている
simulation 側 3D、SEM 側 2D という非対称性に対して、  
いったん 2D 観測へ正規化して比較する設計は現実的で強いです。

### 5.3 Label / SDF / Mesh の責務分離がある
これにより、将来 `mesh -> SDF`, `polyline -> distance2d`, `point-query export` へ拡張しやすいです。

### 5.4 surrogate / assimilation が core から分かれている
学習部や optimizer を core に埋め込んでいないため、  
geometry 表現基盤として長生きしやすいです。

---

## 6. 現行設計の課題

### 6.1 canonical が TSDF 側に寄りすぎている
半導体加工形状では、1 つの `mu_nm` で

- global cavity / trench shape
- local foot / notch / rounding
- thin film / near-closure geometry

を同時に表すのが難しいです。  
TSDF 自体が悪いのではなく、**raw SDF より TSDF が中心になっていること** が制約です。

### 6.2 単一 `mu_nm` が局所差分と大域差分を両立しにくい
小さい `mu` は corner 差には効きますが、大域形状が飽和前に消えます。  
大きい `mu` はその逆で、底部 edge や丸みが埋もれます。

### 6.3 `pair_code` が離散的すぎる
界面が重要な多材料形状に対して、`pair_code` は「何と何が近いか」を cheap に示せますが、  
どの界面がどうズレたかを loss や学習に使うには粗いです。

### 6.4 hard voxel boundary 起点で subvoxel 情報が弱い
mask -> EDT ルートは堅いですが、  
SEM 輪郭や simulation mesh があるときでも、最終的に raster mask に潰してしまうと

- bottom rounding
- thin sidewall film
- small notch
- local overhang

の表現が格子依存になりやすいです。

### 6.5 observer が現象を見切れていない
`topdown_exposed` は上面露出と高さに強いですが、  
sidewall / bottom / buried edge / closure interior は見えにくいです。  
`slice` はありますが、slab union ベースで、かつ profile 化が未整備です。

### 6.6 metrics が CD / TSDF / Chamfer 中心で、工程重要差分が埋もれる
現状でも悪くはありません。  
しかし、加工評価で特に重要な

- sidewall angle
- bowing / necking
- microtrench
- bottom rounding
- overhang / pinch-off
- thickness / conformality
- seam / void 兆候

は、**重みを工夫するだけでは十分に出にくい** です。

---

## 7. 設計 intent と実装のズレ

ここはデータサイエンティスト / アーキテクト観点で重要です。  
repo の docs 側には将来拡張の構想が多く書かれていますが、現行コードには次のズレがあります。

### 7.1 backend registry はあるが backend 実装は揃っていない
registry には

- `scipy`
- `itk_maurer`
- `cupy_jfa`

が登録されています。  
しかし観測したコードでは、SciPy backend は実装されていますが、  
ITK backend と CuPy backend は stub で、`OptionalDependencyUnavailableError` を投げる状態です。  
つまり **選べるように見えても、実際に完全動作するのは主に SciPy path** です。

### 7.2 Spec にあるが observer 実装で反映されていない項目がある
`ObserverSpecV2` / `ContourSpec` / `Tsdf2DSpec` には  
`roi`, `source`, `smoothing_sigma_nm`, `simplify_tolerance_nm`, `band_only` などがあります。  
しかし、観測した `topdown.py` / `slice.py` の主要コードパスでは、  
これらが十分反映されているようには見えません。  
これは研究段階では許容されがちですが、共通基盤としては **spec drift** の原因になります。

### 7.3 transform policy は docs 上の幅に比べ、現段階はかなり限定的
assimilation 側は objective evaluator としての分離は良い一方で、  
transform policy は観測時点では `strict_sim_grid` 以外が実質 no-op に近い扱いです。  
将来拡張の余地はありますが、現時点では **できることを明確に絞る方が安全** です。

---

## 8. 半導体ウェハー形状の観点から見た不足

### 8.1 エッチ形状
重要なのは単なる CD だけではありません。  
実務では、少なくとも次が重要です。

- bowing
- necking
- microtrenching
- footing / notching
- bottom rounding
- scalloping / roughness
- sidewall angle
- depth-dependent CD

現行 repo では、このうち一部は contour / TSDF 差に間接的には現れますが、  
**工程可読な observable としてはまだ整理されていません。**

### 8.2 成膜形状
こちらも単なる top coverage では足りません。

- conformality
- thickness distribution
- entrance overhang
- closure / pinch-off
- seam / void 兆候
- bottom-up fill

が重要です。  
現行の topdown / slice / CD だけでは、この差は十分見えません。

### 8.3 SEM 同化
SEM 側では、open contour や一部トレースしかないケースが普通にあります。  
ここで signed mask に無理に閉じると、むしろ情報を落とします。  
repo docs には analytic polyline distance の発想があり、ここは非常に良いです。  
ただし **第一級の route として整理されてはいません**。

---

## 9. 現行方式と拡張方針の比較

| 項目 | 現行 | 拡張方針 |
|---|---|---|
| 3D canonical | material-wise TSDF | raw SDF canonical, TSDF は派生 view |
| scale | 単一 `mu_nm` | 固定 3 scale view |
| SEM distance | mask ベース中心 | mask + analytic polyline unsigned distance |
| observer | `topdown_exposed`, `slice` | core kind 維持 + bundle helper |
| metric | TSDF + contour + CD | field + curve + profile + corner (+ topology) |
| boundary info | `d_boundary`, `pair_code` | optional interface field + scalar fields |
| 同化説明性 | 比較的粗い | component-wise / profile-wise breakdown |
| surrogate export | package 構想あり | dense / query / mesh / Obs2D / profile を正式化 |

---

## 10. `2-1_sdf_extend.md` との関係

repo にはすでに `2-1_sdf_extend.md` があり、

- exact EDT backend
- Maurer
- CuPy / GPU
- FMM / FSM
- OpenVDB
- mesh→SDF
- 2D polyline distance
- benchmark / QA

といった非常に重要な論点が挙がっています。  
本提案はこれを否定するものではありません。  
むしろ、**この将来構想を core abstraction に落とすとどうなるか** を整理したものです。

違いは次の点です。

- 将来候補を全部 core に入れようとしない
- **core に残す抽象** と **optional backend** と **downstream export** を明確に分ける
- process-specific 分岐を増やさない
- loss を generic profile 関数へ吸収する

---

## 11. 本章の結論

既存 repo は、単に「TSDF の実験置き場」ではなく、  
**かなり筋の良い geometry/observation/evaluation framework の芽** を持っています。

したがって、やるべきことは全面リライトではありません。  
本当に必要なのは次の 5 点です。

1. **canonical を raw distance に寄せる**  
2. **single-scale TSDF を fixed multi-scale view にする**  
3. **SEM unsigned route を第一級にする**  
4. **observer kind を増やさず、bundle + profile + corner を追加する**  
5. **metric を `field + curve + profile + corner` に上げる**  

この方向なら、repo を壊さずに強くできます。
