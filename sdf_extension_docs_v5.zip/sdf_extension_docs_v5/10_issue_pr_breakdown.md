# 10. Issue / PR 単位への分解案（GitHub 運用向け）v3

> v3 追記  
> Issue / PR 分解の基本粒度は v2 の内容を維持しています。  
> ただし各 Issue では、次の参照文書を明記することを推奨します。
>
> - 設計: [02_extension_principles_and_design.md](02_extension_principles_and_design.md)
> - 手法: [03_methods_field_observer_metric.md](03_methods_field_observer_metric.md)
> - file別改修: [04_repo_modifications_implementation_plan.md](04_repo_modifications_implementation_plan.md)
> - 疑似コード: [11_algorithm_specs_and_pseudocode.md](11_algorithm_specs_and_pseudocode.md)
> - API契約: [13_public_api_contracts.md](13_public_api_contracts.md)

本章は、設計提案を **GitHub の Issue / PR にそのまま落とせる粒度** に分解したものです。  
目的は 3 つあります。

1. 実装単位を明確にする  
2. 依存関係を整理する  
3. PR を大きくしすぎず、レビューしやすくする  

> 基本方針  
> - 1 PR 1 テーマ  
> - backward compatibility を崩す変更は shim を先に入れる  
> - optional future feature は後ろへ送る  
> - core に process-specific branch を入れない  

---

## 0. 関連ドキュメント

- 詳細タスク一覧: [09_implementation_task_list.md](09_implementation_task_list.md)
- 改修対象ファイル別の説明: [04_repo_modifications_implementation_plan.md](04_repo_modifications_implementation_plan.md)
- 設計原則: [02_extension_principles_and_design.md](02_extension_principles_and_design.md)

---

## 1. 推奨ラベル

| ラベル | 意味 |
|---|---|
| `core` | Field / Obs / Metric など基盤変更 |
| `spec` | config / schema / validation |
| `sem` | SEM / contour / unsigned distance |
| `metric` | loss / profile / corner |
| `assimilation` | objective evaluator |
| `surrogate` | export / package |
| `backend` | EDT engine / optional dependency |
| `docs` | ドキュメント |
| `tests` | unit / regression / synthetic goldens |
| `breaking-risk` | 既存 API 互換に注意が必要 |
| `future` | 今すぐは merge しない future item |

---

## 2. Epic 構成

```mermaid
flowchart TD
    E0[Epic A\nSpec / capability] --> E1[Epic B\nField3D core]
    E1 --> E2[Epic C\nSEM / Obs2D / alignment]
    E2 --> E3[Epic D\nProfiles / Corners / Metrics]
    E3 --> E4[Epic E\nAssimilation / Surrogate]
    E4 --> E5[Epic F\nOptional backends / future hooks]
```

---

## 3. Issue 一覧サマリー

| Issue ID | 優先度 | Epic | タイトル | 主レイヤ |
|---|---:|---|---|---|
| I-01 | P0 | A | Fail-fast validation と `effective_spec` 導入 | Spec / Artifact |
| I-02 | P0 | A | backend capability registry と unsupported option 排除 | Spec / Backend |
| I-03 | P0 | B | `Field3D` core types と builder skeleton を追加 | Field |
| I-04 | P0 | B | exact distance API を `edt.py` に整理 | Distance |
| I-05 | P0 | B | 3-scale TSDF views と legacy shim を追加 | Field / Compatibility |
| I-06 | P1 | B | canonical role mapping を導入 | Field |
| I-07 | P0 | C | SEM polyline / mask から signed / unsigned `Obs2D` を構築 | SEM / Observe |
| I-08 | P1 | C | similarity2d alignment を core に追加 | Assimilation / Observe |
| I-09 | P0 | C | `ObserverBundle` と bundle report を導入 | Observe |
| I-10 | P0 | D | generic profile extraction を実装 | Observe / Metric |
| I-11 | P0 | D | generic corner extraction を実装 | Observe / Metric |
| I-12 | P0 | D | `MetricBundle` と component report を実装 | Metric |
| I-13 | P0 | E | assimilation objective を `MetricBundle` ベースへ移行 | Assimilation |
| I-14 | P0 | E | surrogate export V2 を追加 | Surrogate |
| I-15 | P0 | E | synthetic goldens / regression / examples を追加 | Tests / Docs |
| I-16 | P2 | F | optional ITK / CuPy exact backend を追加 | Backend |
| I-17 | P2 | F | interface fields を optional feature として追加 | Field |
| I-18 | P2 | F | sparse / adaptive storage watchlist を doc 化 | Future |

---

## 4. 詳細 Issue 設計

## I-01. Fail-fast validation と `effective_spec` 導入

### 目的
Spec と実装のズレを無くし、artifact に「実際に効いた設定」を残す。

### 背景
現状のように未実装 option が残ると、DS 観点でも Architect 観点でも危険です。  
A/B テストや再現性が壊れます。

### 変更範囲
- spec validation
- artifact writer
- CLI / run manifest

### 主な変更ファイル候補
- `wafergeo/config/*.py`
- `wafergeo/io/artifact*.py`
- examples / notebooks

### 受け入れ条件
- unsupported option は error
- `effective_spec.yaml` が必ず保存される
- `schema_version` が report に残る

### 関連タスク
- `T0-01`, `T0-02`

---

## I-02. backend capability registry と unsupported option 排除

### 目的
「選べるように見えるが実際には使えない」 backend を API 上から排除する。

### 背景
stub backend は存在してもよいが、実行パスでは capability として偽装してはいけません。

### 変更範囲
- `wafergeo/sdf/engines/*`
- registry / discovery
- validation

### 受け入れ条件
- `available_backends()` が返る
- `exact_edt`, `gpu`, `spacing_aware` 等が確認できる
- unavailable backend 指定時に fail-fast する

### 関連 refs
- Ref-B01, Ref-B02, Ref-B03

---

## I-03. `Field3D` core types と builder skeleton を追加

### 目的
TSDF ではなく raw signed distance を canonical にする。

### 主な変更ファイル候補
- `wafergeo/field/types.py`
- `wafergeo/field/build.py`
- `wafergeo/field/__init__.py`

### 受け入れ条件
- label volume から `Field3D` が作れる
- grid / spacing / origin / role 情報を持てる
- 既存 TSDF path を壊さない

### 備考
最初は minimal implementation でよく、interface fields や sparse storage は不要。

---

## I-04. exact distance API を `edt.py` に整理

### 目的
distance 生成 API を signed / unsigned で明示し、spacing-aware exact path を固定する。

### 主な変更ファイル候補
- `wafergeo/sdf/edt.py`
- `wafergeo/sdf/engines/*.py`

### 受け入れ条件
- `signed_distance_from_mask_exact`
- `unsigned_distance_from_mask_exact`
- metadata に backend 情報が残る

### テスト
- spacing 変更 case
- exact parity sanity check
- sign convention test

---

## I-05. 3-scale TSDF views と legacy shim を追加

### 目的
raw SDF canonical を保ちながら、既存 TSDF 資産を view として利用できるようにする。

### 主な変更ファイル候補
- `wafergeo/field/views.py`
- `wafergeo/sdf/tsdf.py`
- legacy adapter

### 受け入れ条件
- `small/mid/large` の 3 scale が出る
- `to_tsdf`, `from_tsdf` は従来通り使える
- report に各 scale `mu_nm` が残る

### レビュー観点
- μ を process-specific に増やしすぎていないか
- canonical と view の責務が混ざっていないか

---

## I-06. canonical role mapping を導入

### 目的
材料名やプロセス名の爆発を core へ持ち込まない。

### 主な変更ファイル候補
- `wafergeo/field/roles.py` または `types.py`
- spec schema

### 受け入れ条件
- raw material → role mapping を spec で記述できる
- strict mode では未定義材料を error にできる

### 優先度が P1 の理由
なくても進められるが、早めに入れた方が後々の混乱が減る。

---

## I-07. SEM polyline / mask から signed / unsigned `Obs2D` を構築

### 目的
open contour を無理に signed mask に閉じず、unsigned route を正式化する。

### 主な変更ファイル候補
- `wafergeo/sem_prepare/*`
- `wafergeo/observe/*`
- `Obs2D` 型定義

### 受け入れ条件
- polyline から unsigned distance2d が作れる
- mask から signed distance2d が作れる
- `distance_semantics` が report に残る

### 関連 refs
- Repo-08
- Ref-C03, Ref-C04

---

## I-08. similarity2d alignment を core に追加

### 目的
SEM と simulation の最低限の整合を generic に行う。

### 主な変更ファイル候補
- `wafergeo/assimilation/alignment.py`
- `wafergeo/observe/*`

### 受け入れ条件
- translation / rotation / isotropic scale のみ
- transform parameter を artifact に保存
- nonrigid は実装しない

### 優先度が P1 の理由
value は高いが、Field / Observer / Metric よりは後でもよい。

---

## I-09. `ObserverBundle` と bundle report を導入

### 目的
observer kind を増やさずに観測の厚みを増やす。

### 主な変更ファイル候補
- `wafergeo/observe/bundles.py`
- `wafergeo/observe/topdown.py`
- `wafergeo/observe/slice.py`

### bundle 内容
- `topdown_exposed`
- `slice_center`
- `slice_orthogonal`
- `profiles`

### 受け入れ条件
- same spec から deterministic に生成される
- bundle coverage / support が report される
- topdown / slice 単体 API も壊さない

---

## I-10. generic profile extraction を実装

### 目的
etch / deposition の重要差を generic function に落とす。

### 標準対象
- `width(z)`
- `wall_angle(z)`
- `curvature(z)`
- `gap(z)`
- `thickness(z)`

### 主な変更ファイル候補
- `wafergeo/observe/profiles.py`

### 受け入れ条件
- synthetic trench / bowed trench / closure case で profile が直感通り
- support mask が返る
- downstream で summary を計算しやすい構造

### 関連 refs
- Ref-E01, Ref-E02, Ref-E03, Ref-E05

---

## I-11. generic corner extraction を実装

### 目的
bottom / top corner の差を明示的に取れるようにする。

### 主な変更ファイル候補
- `wafergeo/observe/corners.py`

### 受け入れ条件
- `top_left`, `top_right`, `bottom_left`, `bottom_right`
- position / tangent / curvature / radius-like が取得できる
- support 不足時に status を返す

---

## I-12. `MetricBundle` と component report を実装

### 目的
CD 中心評価から `field + curve + profile + corner (+optional topology)` へ移行する。

### 主な変更ファイル候補
- `wafergeo/metrics/field_loss.py` または `tsdf_loss.py` 再編
- `wafergeo/metrics/contour_metrics.py`
- `wafergeo/metrics/profile_loss.py`
- `wafergeo/metrics/corner_loss.py`
- `wafergeo/metrics/bundle.py`

### 受け入れ条件
- total / component / map / status が返る
- `cd_metrics.py` は summary metric として共存
- unsigned/signed 両方の Obs2D に対応

### 関連 refs
- Ref-D01, Ref-D02

---

## I-13. assimilation objective を `MetricBundle` ベースへ移行

### 目的
optimizer 本体ではなく objective evaluator を強くする。

### 主な変更ファイル候補
- `wafergeo/assimilation/*`

### 受け入れ条件
- input: simulation result + SEM obs + spec
- output: total score + component diagnostics + alignment report
- optimizer 非依存のまま使える

---

## I-14. surrogate export V2 を追加

### 目的
将来どのモデルで学ぶかを core から切り離す。

### export 形式
- dense field
- point-query
- mesh / point cloud
- Obs2D bundle
- profile bundle

### 主な変更ファイル候補
- `wafergeo/surrogate/package_v2.py`
- `wafergeo/surrogate/export_dense.py`
- `wafergeo/surrogate/export_query.py`
- `wafergeo/surrogate/export_mesh.py`
- `wafergeo/surrogate/export_profiles.py`

### 受け入れ条件
- 同じ sample から複数 export を生成できる
- manifest / lineage / split が残る
- learning code は含めない

---

## I-15. synthetic goldens / regression / examples を追加

### 目的
実装が「動く」だけでなく「説明できる」状態にする。

### 必須内容
- ideal trench
- bowed trench
- rounded bottom
- overhang / closure
- open polyline SEM
- same-shape misalignment

### 受け入れ条件
- CI で最小セットが通る
- docs に結果図や JSON report 例が付く
- regression 失敗時に差分説明ができる

---

## I-16. optional ITK / CuPy exact backend を追加

### 目的
optional performance path を持つ。

### 受け入れ条件
- SciPy exact と parity test が通る
- backend 不在時も core path は変わらない
- capability report に backend 差が残る

### 注意
P2 扱い。基盤の本質ではない。

---

## I-17. interface fields を optional feature として追加

### 目的
role pair ごとの界面情報を continuous feature として扱えるようにする。

### 受け入れ条件
- default off
- selected interface pair のみ計算
- field canonical を複雑にしすぎない

---

## I-18. sparse / adaptive storage watchlist を doc 化

### 目的
大規模化の拡張余地を記録する。

### 受け入れ条件
- 設計 docs に extension point を追記
- 本実装はしない

---

## 5. 推奨 PR 切り方

## PR-01. Spec / validation / artifact hygiene

| 項目 | 内容 |
|---|---|
| 含む Issue | I-01, I-02 |
| 目的 | 実装に入る前に spec drift を止める |
| 変更規模 | 小〜中 |
| merge 条件 | examples が fail-fast / `effective_spec` を出す |

### 理由
ここを先に入れないと、後続 PR の比較がブレやすいです。

---

## PR-02. `Field3D` core skeleton

| 項目 | 内容 |
|---|---|
| 含む Issue | I-03 |
| 目的 | canonical geometry 抽象を追加する |
| 変更規模 | 中 |
| merge 条件 | label → `Field3D` が動き、既存 path を壊さない |

---

## PR-03. exact distance API 整備

| 項目 | 内容 |
|---|---|
| 含む Issue | I-04 |
| 目的 | signed / unsigned exact distance を明文化する |
| 変更規模 | 中 |
| merge 条件 | spacing-aware tests / sign tests / metadata tests が通る |

---

## PR-04. TSDF views + legacy shim

| 項目 | 内容 |
|---|---|
| 含む Issue | I-05 |
| 目的 | raw SDF canonical の上に 3-scale TSDF views を乗せる |
| 変更規模 | 小〜中 |
| merge 条件 | old TSDF path の regression を保つ |

---

## PR-05. role mapping（任意だが推奨）

| 項目 | 内容 |
|---|---|
| 含む Issue | I-06 |
| 目的 | material naming 爆発を防ぐ |
| 変更規模 | 小 |
| merge 条件 | strict / permissive 両モードが動く |

---

## PR-06. SEM unsigned `Obs2D`

| 項目 | 内容 |
|---|---|
| 含む Issue | I-07 |
| 目的 | open contour を自然に扱えるようにする |
| 変更規模 | 中 |
| merge 条件 | polyline / mask の signed / unsigned route が統一 API で使える |

---

## PR-07. `ObserverBundle` + similarity2d

| 項目 | 内容 |
|---|---|
| 含む Issue | I-08, I-09 |
| 目的 | 観測の標準束を整え、比較前整合を 1 本化する |
| 変更規模 | 中 |
| merge 条件 | topdown / slice / bundle が安定生成される |

> より小さく切るなら  
> `PR-07a = ObserverBundle`, `PR-07b = similarity2d` に分けてもよいです。

---

## PR-08. generic profiles

| 項目 | 内容 |
|---|---|
| 含む Issue | I-10 |
| 目的 | width / angle / curvature / gap / thickness を抽出可能にする |
| 変更規模 | 中 |
| merge 条件 | synthetic goldens で profile が意味を持つ |

---

## PR-09. generic corners

| 項目 | 内容 |
|---|---|
| 含む Issue | I-11 |
| 目的 | top/bottom corner の明示評価を可能にする |
| 変更規模 | 小〜中 |
| merge 条件 | rounded bottom / footing case で差が出る |

---

## PR-10. `MetricBundle`

| 項目 | 内容 |
|---|---|
| 含む Issue | I-12 |
| 目的 | field / curve / profile / corner を統合評価する |
| 変更規模 | 大 |
| merge 条件 | total + components + subreports が一貫して出る |

### 注意
この PR は大きくなりがちなので、必要なら

- PR-10a field/curve
- PR-10b profile/corner
- PR-10c bundle report

に分ける。

---

## PR-11. assimilation migration

| 項目 | 内容 |
|---|---|
| 含む Issue | I-13 |
| 目的 | objective evaluator を新基盤へ載せ替える |
| 変更規模 | 中 |
| merge 条件 | legacy summary と new component report が両立する |

---

## PR-12. surrogate export V2

| 項目 | 内容 |
|---|---|
| 含む Issue | I-14 |
| 目的 | dense/query/mesh/Obs2D/profile をまとめて export する |
| 変更規模 | 大 |
| merge 条件 | manifest / lineage / split が再現可能 |

---

## PR-13. tests / docs / goldens

| 項目 | 内容 |
|---|---|
| 含む Issue | I-15 |
| 目的 | 研究コードから基盤コードへ引き上げる |
| 変更規模 | 中 |
| merge 条件 | CI / examples / artifact sample が揃う |

---

## PR-14. optional backends / future hooks

| 項目 | 内容 |
|---|---|
| 含む Issue | I-16, I-17, I-18 |
| 目的 | optional 高度化と将来フック整理 |
| 変更規模 | 中 |
| merge 条件 | default path を壊さない |

---

## 6. 推奨 merge 順序

```mermaid
flowchart LR
    P1[PR-01] --> P2[PR-02]
    P2 --> P3[PR-03]
    P3 --> P4[PR-04]
    P4 --> P6[PR-06]
    P4 --> P5[PR-05]
    P6 --> P7[PR-07]
    P7 --> P8[PR-08]
    P7 --> P9[PR-09]
    P8 --> P10[PR-10]
    P9 --> P10
    P10 --> P11[PR-11]
    P10 --> P12[PR-12]
    P11 --> P13[PR-13]
    P12 --> P13
    P13 --> P14[PR-14]
```

---

## 7. 1 issue / 1 PR を書くときのテンプレート

## Issue template

```md
## 背景
何が困っているか。現状の設計・実装のどこがボトルネックか。

## 目的
この Issue で何を達成するか。

## スコープ
何を変えるか。
- in scope:
- out of scope:

## 変更対象
- files:
- artifacts:
- docs:

## 受け入れ条件
- [ ]
- [ ]
- [ ]

## テスト
- unit:
- regression:
- synthetic:

## 関連
- tasks:
- refs:
- blocked by:
```

## PR template

```md
## 何を変えたか
PR の要約。

## なぜ必要か
背景・目的。

## 含む機能
- [ ]
- [ ]
- [ ]

## 含まない機能
- [ ]
- [ ]

## backward compatibility
既存 API / artifact への影響。

## テスト
- [ ] unit
- [ ] regression
- [ ] examples
- [ ] docs updated

## artifact / report 変更
schema や保存物への影響。

## レビュー観点
特に見てほしい点。
```

---

## 8. レビュー時のチェック観点

| 観点 | チェック項目 |
|---|---|
| DS | semantic consistency, profile stability, export usefulness |
| Architect | spec strictness, schema clarity, backward compatibility |
| Process | width / angle / gap / thickness / corner が工程差を拾えているか |
| QA | fail-fast, report completeness, regression safety |

---

## 9. 最初の 3 本だけ選ぶなら

最初に merge すべき 3 本は次です。

1. `PR-01` Spec / validation / artifact hygiene  
2. `PR-02` `Field3D` core skeleton  
3. `PR-06` SEM unsigned `Obs2D`  

これだけでも、  
- 何が本当に動いているか明確になり  
- geometry canonical が整い  
- SEM open contour 比較が自然になる  
ため、以後の実装効率が大きく上がります。

---

## 10. 最終提案

Issue/PR 分解で一番大事なのは、**機能の数ではなく、merge 単位の分かりやすさ** です。  
本提案では、

- PR はテーマごと
- Issue は受け入れ条件つき
- optional future は後回し
- process-specific 分岐は入れない

という形にすることで、**汎用的で長く使える基盤** の実装へつなげやすくしています。
