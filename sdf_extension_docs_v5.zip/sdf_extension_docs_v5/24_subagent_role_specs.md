# 24. subagent role specs

この章は、Codex cloud task や並列実装で使う **役割分担の標準仕様** です。

---

## 1. 基本ルール

- 1 subagent = 1 concern
- subagent は自分の scope の deliverable だけを返す
- cross-cutting change は architect reviewer が最後に統合判断する
- docs / tests は code task の後追いではなく、各 wave に同伴させる

---

## 2. role 一覧

### A. architect / migration lead
**責務**
- public contract
- backward compatibility
- fail-fast / no-op 排除
- repo knowledge map の整合

**入力**
- `02_*`, `04_*`, `13_*`, `22_*`, `23_*`

**出力**
- file target list
- compatibility note
- migration note
- reject / accept criteria

---

### B. field / distance implementer
**責務**
- role mapping
- distance backend facade
- Field3D canonical
- distance view generation

**入力**
- `11_algorithm_specs_and_pseudocode.md`
- `13_public_api_contracts.md`
- `repo_patch_skeleton/overlay/wafergeo/core/*`
- `repo_patch_skeleton/overlay/wafergeo/sdf/*`

**出力**
- core additive files
- unit tests for sign / spacing / shape

---

### C. observer / SEM implementer
**責務**
- Obs2D contract
- SEM contour distance
- generic profiles
- generic corners

**入力**
- `03_methods_field_observer_metric.md`
- `12_third_party_handbook_and_examples.md`
- overlay observe / sem files

**出力**
- observer files
- synthetic contour tests
- profile diagnostics

---

### D. metrics / assimilation interface implementer
**責務**
- MetricComponent / MetricBundle
- field / curve / profile / corner losses
- scalarization hook
- assimilation-facing report shape

**入力**
- `03_*`, `05_*`, `13_*`
- overlay metrics files

**出力**
- metric files
- bundle tests
- note on scalarization policy

---

### E. tests / docs / export implementer
**責務**
- deterministic tests
- goldens
- surrogate export V2
- docs sync

**入力**
- `07_*`, `09_*`, `10_*`, `22_*`
- overlay tests / surrogate files

**出力**
- test files
- sample manifest
- docs sync patch

---

## 3. handoff ルール

各 subagent は最後に必ず次を返す。

```text
Changed files:
Acceptance covered:
Tests added/run:
Open risks:
Suggested next owner:
```

---

## 4. parallel waves の推奨

### wave 1
- architect
- field / distance
- tests / docs

### wave 2
- observer / SEM
- metrics / assimilation
- tests / docs

### wave 3
- export / regression / docs finalization

---

## 5. 失敗しやすい分担

### 悪い例
- architect が code まで全部抱える
- field と observer が別の shape / unit を勝手に採用する
- metrics 側だけで独自 profile semantics を定義する

### 良い例
- public contract は architect が固定
- field / observe / metrics はその contract 上で実装
- tests / docs role が drift を拾う
