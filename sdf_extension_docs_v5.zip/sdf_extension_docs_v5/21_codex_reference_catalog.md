# 21. Codex reference catalog

本章は、v4 で追加した Codex / MCP / skills / prompting 関連の参考情報を整理したものです。

---

## 1. OpenAI official docs

| Ref ID | 内容 | 使いどころ |
|---|---|---|
| Codex-01 | Codex cloud overview | Codex cloud の background / parallel task 前提 |
| Codex-02 | Agent internet access | internet allowlist と safety |
| Codex-03 | Docs MCP | OpenAI docs MCP の設定 |
| Codex-04 | OpenAI Codex CLI getting started | CLI の approval mode |
| Codex-05 | Reasoning best practices | prompt を直接的に書く方針 |
| Codex-06 | Code generation guide | Codex を coding agent として使う前提 |

### 1.1 Codex-01
- Title: Codex cloud
- URL: https://platform.openai.com/docs/codex

### 1.2 Codex-02
- Title: Agent internet access
- URL: https://platform.openai.com/docs/codex/agent-network

### 1.3 Codex-03
- Title: Docs MCP
- URL: https://platform.openai.com/docs/docs-mcp

### 1.4 Codex-04
- Title: OpenAI Codex CLI – Getting Started
- URL: https://help.openai.com/en/articles/11096431-openai-codex-ci-getting-started

### 1.5 Codex-05
- Title: Reasoning best practices
- URL: https://platform.openai.com/docs/guides/reasoning-best-practices

### 1.6 Codex-06
- Title: Code generation
- URL: https://platform.openai.com/docs/guides/code-generation

---

## 2. OpenAI / GitHub repository references

| Ref ID | 内容 | 使いどころ |
|---|---|---|
| Codex-Repo-01 | openai/codex `AGENTS.md` | repo-local AGENTS の書き方の参考 |
| Codex-Repo-02 | openai/skills README | skill の概念整理 |
| Codex-Repo-03 | openai/codex docs/skills | skills docs への導線 |
| Codex-Repo-04 | Codex issue on SKILL.md support | SKILL.md frontmatter 形の参考 |

### 2.1 Codex-Repo-01
- URL: https://github.com/openai/codex/blob/main/AGENTS.md

### 2.2 Codex-Repo-02
- URL: https://github.com/openai/skills

### 2.3 Codex-Repo-03
- URL: https://github.com/openai/codex/blob/main/docs/skills.md

### 2.4 Codex-Repo-04
- URL: https://github.com/openai/codex/issues/5291

---

## 3. v4 でこれらをどう使ったか

### Codex cloud overview
- 並列 task を reviewer / implementer 分離に使える、という前提に使用

### Agent internet access
- internet は基本 off、allowlist 最小化、GET/HEAD/OPTIONS 推奨、という運用方針に使用

### Docs MCP
- OpenAI docs MCP の設定例
- AGENTS.md に 1 行追加する運用
- `.codex/config.toml.example` と `.vscode/mcp.json.example`

### CLI getting started
- Suggest / Auto Edit / Full Auto の mode 運用の整理に使用

### Reasoning best practices
- prompt を simple / direct / delimiter-based / success-criteria-driven に書く方針に使用

### openai/skills
- custom skill を optional quick reference として同梱する設計に使用

---

## 4. まとめ

v4 で追加した Codex 資産は、OpenAI の公式 docs と openai/skills / openai/codex の公開情報に沿って、
- AGENTS.md
- Docs MCP
- simple direct prompts
- optional skills
- parallel role tasks
をまとめたものです。
