# 07. 付録: YAML / artifact / report 実例（v3 詳細版）

本章では、拡張版を **実際にどう設定し、どんな artifact / report が出るか** を、  
実装者と第三者が具体的に想像できるように例示します。

---

## 1. この章の使い方

この章は、次の目的で使います。

- spec 設計のレビュー
- artifact schema の合意
- 実装後の出力イメージ共有
- issue / PR の受け入れ条件作成
- 第三者への説明資料

---

## 2. 最小 spec 例

以下は、最小構成で `Field3D + 3scale TSDF + topdown + center/orthogonal slice + field/curve/profile/corner metric` を使う例です。

```yaml
version: 2.0

input:
  source_kind: label_volume
  path: data/sample_001.vti
  label_axis_order: zyx
  spacing_nm_zyx: [2.0, 2.0, 2.0]
  origin_nm_zyx: [0.0, 0.0, 0.0]

roles:
  void_role_id: 0
  role_id_to_name:
    0: void
    1: target
    2: mask
    3: liner_or_film
    4: fill_or_other
  raw_material_to_role:
    0: 0
    1: 1
    2: 2
    10: 3

field3d:
  backend: scipy_exact
  emit_udf: false
  emit_scalar_fields:
    - depth_from_top_nm
    - local_gap_nm
    - top_height_nm

views:
  tsdf_mu_nm:
    small: 5.0
    mid: 20.0
    large: 80.0
  emit_tanh: false
  emit_logsigned: false

observer_bundle:
  topdown_exposed:
    enabled: true
    target_role: 1
    signed_mode: true

  center_slice:
    enabled: true
    axis: y
    slab_thickness_nm: 0.0
    target_role: 1
    signed_mode: true

  orthogonal_slice:
    enabled: true
    axis: x
    slab_thickness_nm: 0.0
    target_role: 1
    signed_mode: true

  profiles:
    enabled: true
    smoothing_sigma_nm: 1.0
    functions:
      - width
      - centerline
      - wall_angle
      - curvature

  corners:
    enabled: true
    top_window_nm: 20.0
    bottom_window_nm: 20.0
    smoothing_sigma_nm: 1.0

metrics:
  field:
    enabled: true
    band_mode: union
    band_nm: 20.0
    robust: charbonnier
    scale_nm: 1.0

  curve:
    enabled: true
    mode: chamfer_hd95
    resample_step_nm: 1.0

  profile:
    enabled: true
    robust: huber
    per_function_scale:
      width: 2.0
      centerline: 2.0
      wall_angle_left: 1.0
      wall_angle_right: 1.0
      curvature_left: 0.02
      curvature_right: 0.02

  corner:
    enabled: true
    position_scale_nm: 2.0
    angle_scale_deg: 1.0
    radius_scale_nm: 2.0
    robust: huber

  topology:
    enabled: false

artifact:
  root_dir: artifacts/run_001
  save_effective_spec: true
  save_views: true
  save_observers: true
  save_metrics: true
```

---

## 3. open SEM contour 用 spec 例

```yaml
version: 2.0

input:
  source_kind: sem_contour
  path: data/sem/profile_polyline.csv
  contour_semantics: open_curve
  grid_shape_yx: [512, 512]
  spacing_nm_yx: [1.0, 1.0]
  origin_nm_yx: [0.0, 0.0]

sem_obs2d:
  mode: unsigned_curve
  simplify_tolerance_nm: 0.5
  smoothing_sigma_nm: 0.5

alignment:
  enabled: true
  mode: similarity2d
  init_strategy: centroid
  optimize_rotation: true
  optimize_scale: true

metrics:
  field:
    enabled: true
    band_mode: union
    band_nm: 20.0
    robust: charbonnier
    scale_nm: 1.0

  curve:
    enabled: true
    mode: chamfer_hd95
    resample_step_nm: 1.0

  profile:
    enabled: true
    robust: huber
    per_function_scale:
      width: 2.0
      wall_angle_left: 1.0
      wall_angle_right: 1.0

  corner:
    enabled: true
    position_scale_nm: 2.0
    angle_scale_deg: 1.0
    radius_scale_nm: 2.0
```

**重要:** open contour では `signed_region` にしないことがポイントです。

---

## 4. artifact tree 実例

```text
artifacts/
  run_001/
    spec.yaml
    effective_spec.yaml
    manifest.json

    field/
      field3d.npz
      field3d_meta.json
      qa_field.json

    views/
      tsdf_small.npz
      tsdf_mid.npz
      tsdf_large.npz
      views_meta.json

    observe/
      topdown_exposed.npz
      center_slice.npz
      orthogonal_slice.npz
      profiles.json
      corners.json
      qa_observe.json

    metrics/
      metric_bundle.json
      field_components.csv
      curve_components.csv
      profile_components.csv
      corner_components.csv

    export/
      surrogate_manifest.json
      query_samples.parquet
      profiles_table.parquet
      optional_mesh.ply
```

---

## 5. `manifest.json` 実例

```json
{
  "artifact_version": "2.0",
  "created_at": "2026-04-05T14:10:00+09:00",
  "package_name": "wafergeo",
  "source_run_id": "run_001",
  "spec_hash": "sha256:abc123...",
  "effective_spec_hash": "sha256:def456...",
  "files": {
    "field3d": "field/field3d.npz",
    "views_meta": "views/views_meta.json",
    "observer_bundle": "observe/profiles.json",
    "metric_bundle": "metrics/metric_bundle.json"
  }
}
```

---

## 6. `field3d_meta.json` 実例

```json
{
  "grid": {
    "shape_zyx": [128, 256, 256],
    "spacing_nm_zyx": [2.0, 2.0, 2.0],
    "origin_nm_zyx": [0.0, 0.0, 0.0],
    "axis_order": "zyx",
    "frame": "canonical"
  },
  "roles": {
    "void_role_id": 0,
    "role_id_to_name": {
      "0": "void",
      "1": "target",
      "2": "mask",
      "3": "liner_or_film",
      "4": "fill_or_other"
    }
  },
  "arrays": {
    "sdf_nm_shape": [5, 128, 256, 256],
    "scalar_fields": {
      "depth_from_top_nm": [128, 256, 256],
      "local_gap_nm": [128, 256, 256],
      "top_height_nm": [256, 256]
    }
  },
  "distance_semantics": "signed",
  "builder_backend": "scipy_exact"
}
```

---

## 7. `qa_field.json` 実例

```json
{
  "finite_ratio": 1.0,
  "spacing_nm_min": 2.0,
  "spacing_nm_max": 2.0,
  "roles_count": 5,
  "band_stats": {
    "role_1": {
      "band_nm": 10.0,
      "voxel_count": 43821,
      "grad_norm_mean": 0.98,
      "grad_norm_p95": 1.06
    }
  },
  "warnings": []
}
```

---

## 8. `profiles.json` 実例

```json
{
  "bundle_name": "center_slice",
  "coordinate_name": "z_nm",
  "coordinate_values_nm": [0.0, 2.0, 4.0, 6.0, 8.0],
  "values": {
    "width": [48.1, 47.8, 47.2, 46.5, 46.0],
    "centerline": [100.0, 100.0, 100.1, 100.2, 100.3],
    "wall_angle_left": [89.5, 89.2, 88.7, 88.0, 87.4],
    "wall_angle_right": [90.2, 90.1, 89.9, 89.4, 88.8],
    "curvature_left": [0.00, 0.01, 0.02, 0.03, 0.02],
    "curvature_right": [0.00, 0.00, 0.01, 0.01, 0.01]
  },
  "support_mask": {
    "width": [true, true, true, true, true],
    "wall_angle_left": [false, true, true, true, false]
  },
  "diagnostics": {
    "crossing_fail_count": 0,
    "smoothing_sigma_nm": 1.0
  }
}
```

---

## 9. `corners.json` 実例

```json
{
  "top_left": {
    "position_nm": [81.2, 4.0],
    "tangent_angle_deg": 92.0,
    "curvature_inv_nm": 0.12,
    "radius_like_nm": 8.3,
    "confidence": 0.97,
    "support_count": 14
  },
  "top_right": {
    "position_nm": [118.4, 4.2],
    "tangent_angle_deg": 88.9,
    "curvature_inv_nm": 0.11,
    "radius_like_nm": 9.1,
    "confidence": 0.95,
    "support_count": 13
  },
  "bottom_left": {
    "position_nm": [76.8, 95.8],
    "tangent_angle_deg": 178.0,
    "curvature_inv_nm": 0.20,
    "radius_like_nm": 5.0,
    "confidence": 0.91,
    "support_count": 11
  },
  "bottom_right": {
    "position_nm": [123.0, 95.3],
    "tangent_angle_deg": 2.1,
    "curvature_inv_nm": 0.22,
    "radius_like_nm": 4.5,
    "confidence": 0.89,
    "support_count": 10
  }
}
```

---

## 10. `metric_bundle.json` 実例

```json
{
  "field": {
    "center_slice_field": {
      "value": 0.84,
      "unit": "normalized",
      "support": {
        "pixels_used": 10322,
        "band_nm": 20.0
      }
    }
  },
  "curve": {
    "center_slice_curve": {
      "value": 1.42,
      "unit": "nm",
      "support": {
        "points_pred": 320,
        "points_ref": 315
      },
      "diagnostics": {
        "hd95_nm": 2.84,
        "chamfer_nm": 1.11
      }
    }
  },
  "profile": {
    "width": {
      "value": 0.62,
      "unit": "normalized",
      "support": {
        "valid_depth_count": 48
      }
    },
    "wall_angle_left": {
      "value": 0.95,
      "unit": "normalized",
      "support": {
        "valid_depth_count": 41
      }
    }
  },
  "corner": {
    "bottom_left": {
      "value": 1.31,
      "unit": "normalized",
      "support": {
        "confidence_pred": 0.91,
        "confidence_ref": 0.87
      }
    }
  },
  "total": {
    "value": 4.65,
    "unit": "normalized"
  }
}
```

---

## 11. `effective_spec.yaml` が必要な理由

設定ファイル `spec.yaml` に次のような option があったとしても、

```yaml
backend: itk_exact
```

実行環境に ITK が入っていなければ、そのままでは再現できません。  
そこで `effective_spec.yaml` では、実際に使われた backend や fallbacks を明示します。

```yaml
field3d:
  backend: scipy_exact
  requested_backend: itk_exact
  backend_resolution_reason: "itk_exact not available in current environment"
```

このファイルがあると、後から artifact を再評価するときに混乱しません。

---

## 12. synthetic golden case 例

### Case A: 直線側壁 trench
- 目的: baseline
- 期待: `wall_angle ≈ 90deg`, `curvature ≈ 0`

### Case B: bowing trench
- 目的: `width(z)` が中腹で大きくなることを確認
- 期待: center 付近の width loss が大きい

### Case C: rounded bottom
- 目的: corner/radius が効くことを確認
- 期待: CD は近いが corner loss が上がる

### Case D: conformal deposition
- 目的: `pair_separation(z)` がほぼ一定
- 期待: thickness profile が平坦

### Case E: overhang / pinch-off
- 目的: top corner と `gap(z)` が効くことを確認
- 期待: top corner radius / closure ratio が強く変化

---

## 13. report をどう読むか

### 13.1 field component が大きい
- broad shape の差がある
- alignment がずれている可能性
- narrow band 設定が過小/過大の可能性

### 13.2 curve component が大きい
- contour localization 差が大きい
- boundary 位置そのものがずれている

### 13.3 profile component が大きい
- 深さ依存の profile が合っていない
- CD 平均だけでは見えない mismatch

### 13.4 corner component が大きい
- edge / bottom rounding / overhang が悪い
- 工程的に重要な局所差を示唆

---

## 14. downstream export 例

```json
{
  "sample_id": "sample_001",
  "exports": {
    "field3d_npz": "field/field3d.npz",
    "tsdf_small_npz": "views/tsdf_small.npz",
    "tsdf_mid_npz": "views/tsdf_mid.npz",
    "topdown_obs2d_npz": "observe/topdown_exposed.npz",
    "center_slice_obs2d_npz": "observe/center_slice.npz",
    "profiles_parquet": "export/profiles_table.parquet",
    "query_samples_parquet": "export/query_samples.parquet",
    "mesh_ply": "export/optional_mesh.ply"
  },
  "split": "train",
  "group_id": "wafer_lot_A01"
}
```

---

## 15. この章の結論

本章のサンプルを見れば分かる通り、拡張版の出力は「多機能」ですが、  
**型と意味はかなり単純に保たれています。**

- canonical: `Field3D`
- view: `DistanceViews`
- observation: `Obs2D`
- metric: `MetricBundle`

この 4 段に分けて artifact を保存すると、  
第三者が見ても「どの段階で何が起きたか」を追いやすくなります。
