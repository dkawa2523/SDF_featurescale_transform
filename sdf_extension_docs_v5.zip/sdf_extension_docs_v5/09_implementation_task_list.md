# 09. 実装タスク一覧（WBS / マイルストーン / 受け入れ条件付き）v3

> v3 追記  
> この文書の詳細 WBS は v2 の粒度を維持しています。  
> ただし実装時には、以下の文書も合わせて参照してください。
>
> - 詳細設計: [02_extension_principles_and_design.md](02_extension_principles_and_design.md)
> - 手法背景: [03_methods_field_observer_metric.md](03_methods_field_observer_metric.md)
> - file別改修: [04_repo_modifications_implementation_plan.md](04_repo_modifications_implementation_plan.md)
> - 疑似コード: [11_algorithm_specs_and_pseudocode.md](11_algorithm_specs_and_pseudocode.md)
> - API契約: [13_public_api_contracts.md](13_public_api_contracts.md)

本章は、ここまでの拡張提案を **実際に実装へ落とすための作業分解版** です。  
単なる「やること一覧」ではなく、各タスクについて次を明記します。

- 何を変えるか
- なぜそれが必要か
- どのファイル / レイヤに効くか
- 何が終われば完了とみなすか
- どの価値が増えるか
- どの拡張は **今はやらない** か

> 重要方針  
> 本タスクリストは、**汎用性・シンプルさ・再現性** を優先します。  
> エッチ専用 / 成膜専用の複雑な分岐、プロセスごとの個別 observer 爆発、実験的 neural 学習 loop の core 混入は避けます。

---

## 0. この章の使い方

- 設計の全体像を知るには [02_extension_principles_and_design.md](02_extension_principles_and_design.md)
- 手法の意味を深く知るには [03_methods_field_observer_metric.md](03_methods_field_observer_metric.md)
- 既存 repo のどこをどう変えるかは [04_repo_modifications_implementation_plan.md](04_repo_modifications_implementation_plan.md)
- GitHub 上の Issue / PR 単位の運用案は [10_issue_pr_breakdown.md](10_issue_pr_breakdown.md)

この章は、**実装責任者・レビューア・計画担当** のための運用ドキュメントです。

---

## 1. 実装の基本原則

### 1.1 core に残す抽象は少なくする
実装の中心抽象は次の 4 つに限定します。

1. `Field3D`  
2. `Obs2D`  
3. `MetricBundle`  
4. `DatasetPackageV2`

これ以外は helper / adapter / shim として扱います。

### 1.2 process-specific 名称を API に埋め込まない
`extract_bowing_metric()` や `deposition_pinchoff_observer()` のような API は増やしません。  
代わりに `width(z)`, `wall_angle(z)`, `gap(z)`, `thickness(z)`, `curvature(z)`, `corner_radius_like` のような **幾何関数** を first-class にします。

### 1.3 canonical と view を分ける
- canonical: raw signed distance
- view: TSDF small / mid / large, unsigned distance, profile bundles

これにより、学習方式や最適化目的が増えても core を壊さずに済みます。

### 1.4 未実装 option を見せない
Spec に書けても実際には効かない、という状態を避けます。  
unsupported capability は validation error にします。

### 1.5 既存資産を活かしつつ段階移行する
全面リライトではなく、

```mermaid
flowchart LR
    A[現行 TSDF中心実装] --> B[Field3D を横に追加]
    B --> C[legacy API を shim 化]
    C --> D[observer / metrics を段階移行]
    D --> E[assimilation / surrogate を新基盤へ接続]
```

の順で進めます。

---

## 2. マイルストーン全体図

```mermaid
flowchart TD
    M0[Phase 0\nSpec / capability 整理] --> M1[Phase 1\nField3D + exact distance + TSDF views]
    M1 --> M2[Phase 2\nSEM unsigned route + ObserverBundle + alignment]
    M2 --> M3[Phase 3\nProfiles + Corners + MetricBundle]
    M3 --> M4[Phase 4\nAssimilation migration + Surrogate export V2]
    M4 --> M5[Phase 5\nOptional backends / interface fields / future hooks]
```

---

## 3. フェーズ別の狙い

| Phase | 主目的 | 代表成果物 | 価値 |
|---|---|---|---|
| 0 | Spec / 実装のズレ解消 | `effective_spec`, capability gating, no-op 排除 | 再現性・信頼性 |
| 1 | raw distance canonical 化 | `Field3D`, exact distance builders, TSDF views | 基盤整備 |
| 2 | 観測表現の強化 | unsigned `Obs2D`, `ObserverBundle`, similarity2d | SEM 比較の汎用化 |
| 3 | loss 基底の拡張 | profile / corner extraction, `MetricBundle` | bottom / sidewall / closure を見える化 |
| 4 | 実運用接続 | assimilation migration, surrogate export V2 | 最適化・学習準備の実用化 |
| 5 | optional 高度化 | exact GPU/ITK backend, interface fields, sparse watchlist | 将来拡張の余地 |

---

## 4. WBS サマリー表

| Task ID | Phase | Priority | Layer | 主目的 | Size | 主な依存 |
|---|---|---:|---|---|---|---|
| T0-01 | 0 | P0 | Spec / Validation | no-op option 排除、unsupported capability 明示 | M | なし |
| T0-02 | 0 | P0 | Artifact / Report | `effective_spec` / report schema 統一 | M | T0-01 |
| T1-01 | 1 | P0 | Field Core | `Field3D` 型と builder 導入 | L | T0-01 |
| T1-02 | 1 | P0 | Distance | exact distance API 整備 | M | T0-01 |
| T1-03 | 1 | P0 | Views / Compatibility | 3-scale TSDF views と legacy shim | M | T1-01, T1-02 |
| T1-04 | 1 | P1 | Role Mapping | raw material → canonical role mapping | S | T1-01 |
| T2-01 | 2 | P0 | SEM / Obs2D | unsigned curve distance route | M | T1-02 |
| T2-02 | 2 | P1 | Alignment | similarity2d alignment | M | T2-01 |
| T2-03 | 2 | P0 | Observe | `ObserverBundle` 導入 | M | T1-01, T2-01 |
| T3-01 | 3 | P0 | Profiles | width / angle / curvature / gap / thickness | L | T2-03 |
| T3-02 | 3 | P0 | Corners | generic corner feature extraction | M | T2-03 |
| T3-03 | 3 | P0 | Metrics | `field + curve + profile + corner` bundle | L | T3-01, T3-02 |
| T3-04 | 3 | P1 | Diagnostics | component-wise report / QA 強化 | M | T3-03 |
| T4-01 | 4 | P0 | Assimilation | objective evaluator を bundle 化 | M | T3-03 |
| T4-02 | 4 | P0 | Surrogate | export V2 (dense/query/mesh/Obs2D/profile) | L | T1-01, T2-03, T3-01 |
| T4-03 | 4 | P1 | Dataset QA | group split / manifest / schema hardening | M | T4-02 |
| T5-01 | 5 | P2 | Backend | optional ITK / CuPy exact backend | M | T1-02 |
| T5-02 | 5 | P2 | Geometry | interface fields | M | T1-01 |
| T5-03 | 5 | P2 | Performance | sparse / adaptive storage watchlist | M | T1-01 |
| TX-01 | X | P0 | Tests / Examples | synthetic goldens / CI / examples | L | 全タスクに横断 |

---

## 5. 詳細タスク

## T0-01. Spec / capability 整理

| 項目 | 内容 |
|---|---|
| ID | `T0-01` |
| 優先度 | P0 |
| 主担当 | Architect |
| 協力 | DS / Process reviewer |
| 目的 | 「設定できるが効かない」をなくす |
| 関連章 | 01, 02, 04, 08 |
| 関連文献 / ソース | Repo-03, Repo-06, Repo-07, Repo-08 |

### 目的
現状の提案・実装では、Spec に存在するが code path で効いていない option がありえます。  
この状態は、A/B テスト、再現実験、loss 改善の議論を壊します。

### 実装内容
- unsupported / unimplemented option を列挙する
- validation 時に **warning ではなく error** にする
- backend capability を runtime で明示する
- `effective_spec.yaml` を artifact に必ず保存する
- `strict_sim_grid` 以外 no-op の transform policy は一旦露出を止める

### 変更対象
- `wafergeo/config/*`
- spec dataclass / pydantic 相当
- artifact writer
- CLI / examples

### 受け入れ条件
- 未実装 option を指定したときに job が fail する
- artifact に `effective_spec.yaml` が保存される
- `available_backends()` / `available_capabilities()` 相当が存在する
- examples が通る

### 何が良くなるか
- 実験解釈が壊れない
- issue の再現が容易になる
- review 時に「その option 本当に効いているか」が明確になる

### 今はやらないこと
- backend を増やすこと自体
- process-specific validation を増やすこと

---

## T0-02. Artifact / report schema の統一

| 項目 | 内容 |
|---|---|
| ID | `T0-02` |
| 優先度 | P0 |
| 主担当 | Architect |
| 協力 | DS |
| 目的 | 各 layer の結果を同じ形式で追えるようにする |

### 実装内容
- `effective_spec.yaml`
- `capability_report.json`
- `run_manifest.json`
- `metric_bundle_report.json`
- `observer_bundle_report.json`

を標準 artifact として定義する。

### 受け入れ条件
- 1 run から上記 artifact が揃う
- `schema_version` が含まれる
- backward compatibility のため `legacy_summary.json` を optional で残せる

### 価値
- 同化・サロゲート・回帰テストで同じ report を参照できる
- 失敗時の root cause 調査が容易になる

---

## T1-01. `Field3D` 型と builder の導入

| 項目 | 内容 |
|---|---|
| ID | `T1-01` |
| 優先度 | P0 |
| 主担当 | Architect |
| 協力 | DS |
| 目的 | raw signed distance を canonical にする |

### 実装内容
新規 package `wafergeo/field/` を導入し、少なくとも以下を用意します。

- `types.py`
- `build.py`
- `views.py`
- `scalar_fields.py`
- `qa.py`

#### 最小型案
```python
@dataclass(frozen=True)
class Field3D:
    grid: GridSpec
    roles: RoleSpec
    sdf_nm: np.ndarray
    udf_nm: np.ndarray | None = None
    scalar_fields: dict[str, np.ndarray] | None = None
    meta: dict[str, Any] = field(default_factory=dict)
```

### 受け入れ条件
- label volume から `Field3D` が生成できる
- spacing / origin / axis order が明示される
- legacy TSDF build path とは独立に動く
- small synthetic case で SDF 符号が安定している

### 価値
- TSDF 以外の view を後から増やせる
- surrogate export で dense/query/mesh を同じ canonical から作れる
- data assimilation と surrogate が同じ geometry を参照できる

### 関連 refs
- Ref-B01, Ref-B03
- Ref-C01, Ref-C02

---

## T1-02. exact distance API 整備

| 項目 | 内容 |
|---|---|
| ID | `T1-02` |
| 優先度 | P0 |
| 主担当 | Architect |
| 協力 | DS |
| 目的 | distance 生成を明示的で検証可能にする |

### 実装内容
- `signed_distance_from_mask_exact(...)`
- `unsigned_distance_from_mask_exact(...)`
- `signed_distance_from_partial_volume(...)`（最初は TODO 可）
- spacing-aware exact EDT を標準化
- backend metadata (`exact`, `gpu`, `spacing_aware`) を結果に残す

### 受け入れ条件
- SciPy exact EDT 経路が常に動作する
- spacing を変えた synthetic case で物理距離が正しく変わる
- unsigned / signed semantics が artifact に残る

### 価値
- SEM unsigned route の基礎になる
- exact/approximate の混同を避けられる
- later backend 追加の土台になる

### 関連 refs
- Ref-B01, Ref-B02, Ref-B03, Ref-B04

---

## T1-03. fixed 3-scale TSDF view と legacy shim

| 項目 | 内容 |
|---|---|
| ID | `T1-03` |
| 優先度 | P0 |
| 主担当 | DS |
| 協力 | Architect |
| 目的 | raw SDF canonical を保ちながら既存 TSDF 資産を活かす |

### 実装内容
- `derive_tsdf_views(field3d, {"small": ..., "mid": ..., "large": ...})`
- `to_tanh_distance(...)` などの派生 encoding は optional
- 現行 `to_tsdf`, `from_tsdf`, `label_from_tsdf` は残しつつ、legacy path として位置づける
- `TSDFVolume` 的構造は `DistanceViews` として再解釈する

### 推奨固定スケール
- `small`: 角部 / rounding / thin film を見やすい
- `mid`: 標準比較
- `large`: 大域形状 / broad bowing / closure trend を見やすい

> 注意  
> ここでは **プロセスごとに μ を分岐させない**。  
> 基盤では固定 3 スケールにとどめ、必要なら downstream で選ぶ。

### 受け入れ条件
- 同一 `Field3D` から 3 つの TSDF view が生成される
- legacy API の regression test が通る
- report に各 scale の `mu_nm` が明記される

### 価値
- CD だけで見えない局所 / 大域差分を両立しやすい
- downstream model が必要な scale を選べる
- 既存資産との互換性を保てる

### 関連 refs
- Ref-C01, Ref-C02

---

## T1-04. canonical role mapping

| 項目 | 内容 |
|---|---|
| ID | `T1-04` |
| 優先度 | P1 |
| 主担当 | Architect |
| 協力 | Process reviewer |
| 目的 | 材料名の爆発を core に持ち込まない |

### 実装内容
upstream raw material id を、最小限の role 空間へ写像する設定を追加する。

例:
- `void`
- `target`
- `mask`
- `liner_or_film`
- `fill_or_other`

### 受け入れ条件
- role map が optional spec として記述できる
- 未定義材料を strict mode では error にできる
- report に raw material → role の写像が残る

### 価値
- process-specific 分岐を減らせる
- interface / observer / metric を generic に保ちやすい

---

## T2-01. SEM unsigned `Obs2D` route

| 項目 | 内容 |
|---|---|
| ID | `T2-01` |
| 優先度 | P0 |
| 主担当 | DS |
| 協力 | Architect / Process reviewer |
| 目的 | open contour を無理に signed mask にしない |

### 実装内容
- `build_obs2d_from_polyline(...)`
- `build_obs2d_from_mask(...)`
- `Obs2D.distance2d_nm`
- `Obs2D.distance_semantics: signed | unsigned`
- confidence map を geometry と分離して保存

### 受け入れ条件
- open contour から unsigned distance2d が作れる
- closed mask から signed distance2d が作れる
- same API で metrics に流せる
- semantic mismatch が検出される

### 価値
- SEM 輪郭処理が自然になる
- 境界が閉じない・部分的にしか見えないケースでも扱える
- マスク化による情報損失を減らせる

### 関連 refs
- Repo-08
- Ref-C03, Ref-C04

---

## T2-02. similarity2d alignment

| 項目 | 内容 |
|---|---|
| ID | `T2-02` |
| 優先度 | P1 |
| 主担当 | Architect |
| 協力 | DS |
| 目的 | 比較前の最低限の整合を generic に行う |

### 実装内容
- translation
- rotation
- isotropic scale

のみを core 実装する。

### 受け入れ条件
- transform parameter が artifact に保存される
- no-op と strict mode が選べる
- elastic / nonrigid は core に入れない

### 価値
- SEM / simulation の位置合わせが毎回 ad hoc にならない
- objective の解釈性を損なわずに使える

### 今はやらないこと
- deformable registration
- process-specific alignment heuristic

---

## T2-03. `ObserverBundle` 導入

| 項目 | 内容 |
|---|---|
| ID | `T2-03` |
| 優先度 | P0 |
| 主担当 | Architect |
| 協力 | DS / Process reviewer |
| 目的 | observer kind を増やさず観測の厚みを増やす |

### 実装内容
core observer kind は増やさず、
- `topdown_exposed`
- `slice_center`
- `slice_orthogonal`
- `profiles`

を標準 bundle として返す helper を導入する。

### 受け入れ条件
- 1 spec から bundle が安定生成される
- topdown / slice は単体でも従来通り使える
- bundle report に coverage / support が残る

### 価値
- buried feature や sidewall / bottom の情報が loss に出やすい
- observer explosion を避けられる
- SEM / simulation / surrogate の比較単位をそろえやすい

---

## T3-01. generic profile extraction

| 項目 | 内容 |
|---|---|
| ID | `T3-01` |
| 優先度 | P0 |
| 主担当 | DS |
| 協力 | Process reviewer |
| 目的 | 工程上重要な形状差を generic function として表す |

### 標準 profile
- `width(z)`
- `wall_angle_left(z)`
- `wall_angle_right(z)`
- `curvature(z)`
- `gap(z)`
- `thickness(z)`

### 実装方針
- contour または distance2d から抽出する
- support / coverage mask を同時に返す
- `extract_bowing_metric` のような専用 API は作らない
- bowing / necking / overhang / closure は downstream summary で表現する

### 受け入れ条件
- synthetic trench / bowed trench / overhang trench で挙動が直感と一致する
- support 不足区間を `NaN` ではなく mask で表現できる
- profile 抽出条件が report 化される

### 価値
- CD 一点では見えない形状差を objective に乗せられる
- etch / deposition を同じ profile 基底で評価できる
- data assimilation の説明性が上がる

### 関連 refs
- Ref-E01, Ref-E02, Ref-E03, Ref-E05

---

## T3-02. generic corner extraction

| 項目 | 内容 |
|---|---|
| ID | `T3-02` |
| 優先度 | P0 |
| 主担当 | DS |
| 協力 | Process reviewer |
| 目的 | top / bottom corner を明示的に比較できるようにする |

### 標準 anchor
- `top_left`
- `top_right`
- `bottom_left`
- `bottom_right`

### 抽出要素
- point position
- tangent
- local curvature
- radius-like descriptor

### 受け入れ条件
- bottom rounding case で corner 指標が変化する
- footing / notch / rounded bottom で anchor の意味が壊れない
- support 不足時は status を返す

### 価値
- 「CD は合うが bottom edge が悪い」を検出しやすくなる
- 丸み / edge sharpening / footing を objective に入れやすい

### 関連 refs
- Ref-E03, Ref-D01

---

## T3-03. `MetricBundle` 実装

| 項目 | 内容 |
|---|---|
| ID | `T3-03` |
| 優先度 | P0 |
| 主担当 | DS |
| 協力 | Architect |
| 目的 | 評価基底を CD 中心から拡張する |

### 標準 family
- `field`
- `curve`
- `profile`
- `corner`
- `topology`（optional）

### 役割分担
- `field`: narrow-band distance 差
- `curve`: Chamfer / HD95 / arc-length residual
- `profile`: function-level 差
- `corner`: angle / position / radius-like 差
- `topology`: closure / connectivity が重要な場合のみ

### 受け入れ条件
- total score と component score が返る
- component ごとの map / subreport が保存される
- `cd_metrics.py` は summary 指標として共存できる

### 価値
- optimizer が意味ある方向へ動きやすい
- 失敗の原因を component-wise に説明できる
- complex profile での見落としが減る

### 関連 refs
- Ref-D01, Ref-D02

---

## T3-04. component-wise diagnostics / QA

| 項目 | 内容 |
|---|---|
| ID | `T3-04` |
| 優先度 | P1 |
| 主担当 | DS |
| 協力 | Architect |
| 目的 | 「なぜ悪いか」を run 単位で説明可能にする |

### 実装内容
- profile coverage
- corner support status
- semantic mismatch
- alignment residual summary
- active band coverage
- contour sampling density summary

### 受け入れ条件
- bad run の原因が report だけである程度追える
- failure mode が silent にならない
- QA report が JSON で機械可読

### 価値
- 同化 / surrogate dataset 生成の品質管理が楽になる
- downstream の training failure を upstream で潰せる

---

## T4-01. Assimilation migration

| 項目 | 内容 |
|---|---|
| ID | `T4-01` |
| 優先度 | P0 |
| 主担当 | Architect |
| 協力 | DS |
| 目的 | optimizer 本体を入れずに objective evaluator を強くする |

### 実装内容
- assimilation layer は `MetricBundleSpec` を受ける
- `ObserverBundle` を内部で生成または受け取る
- alignment report と component report を返す
- scalar total score と structured diagnostics を両方返す

### 受け入れ条件
- 既存 objective evaluator と同等以上の API 明確性
- optimizer 未実装でも CLI / notebook から評価可能
- 既存 CD 中心 path との backward-compatible summary がある

### 価値
- SEM 同化で「どこを合わせに行っているか」が明確になる
- パラメータ探索の失敗理由を説明しやすい

---

## T4-02. Surrogate export V2

| 項目 | 内容 |
|---|---|
| ID | `T4-02` |
| 優先度 | P0 |
| 主担当 | DS |
| 協力 | Architect |
| 目的 | 将来のモデル選択を core から切り離す |

### export 形式
| 形式 | 用途 |
|---|---|
| dense field tensor | voxel CNN / 3D U-Net |
| point-query samples | neural implicit / SDF / UDF |
| mesh / point cloud | point / graph / mesh learning |
| Obs2D bundle | 2D surrogate / same-domain comparison |
| profile bundle | GP / BO / XGBoost / tabular |

### 受け入れ条件
- 1 sample から複数 export が生成できる
- manifest に export schema と field semantics が残る
- group split 単位で package 生成できる

### 価値
- モデル選定を後ろ倒しにできる
- 同じ geometry から複数 surrogate を試せる
- 学習コードを core へ入れずに済む

### 関連 refs
- Ref-C01, Ref-C02, Ref-C05, Ref-F01, Ref-F02

---

## T4-03. dataset manifest / split hardening

| 項目 | 内容 |
|---|---|
| ID | `T4-03` |
| 優先度 | P1 |
| 主担当 | DS |
| 協力 | Architect |
| 目的 | leak-free で追跡可能な dataset package を作る |

### 実装内容
- lot / wafer / seed / recipe grouping
- split manifest
- export checksum
- sample lineage
- generation spec hash

### 受け入れ条件
- split 再現が保証される
- train/val/test leakage を検査できる
- package から lineage を逆引きできる

### 価値
- surrogate 実験の信頼性が上がる
- 将来の active learning / BO に接続しやすい

---

## T5-01. optional exact backend 追加

| 項目 | 内容 |
|---|---|
| ID | `T5-01` |
| 優先度 | P2 |
| 主担当 | Architect |
| 協力 | DS |
| 目的 | performance / deployment options を増やす |

### 候補
- ITK Signed Maurer
- CuPy exact EDT

### 受け入れ条件
- SciPy と parity test が通る
- capability report に backend 差が残る
- backend 不在時も基盤は壊れない

### 価値
- optional performance 改善
- 大規模データや GPU 環境での運用余地

### 関連 refs
- Ref-B02, Ref-B03, Ref-B04

---

## T5-02. interface fields

| 項目 | 内容 |
|---|---|
| ID | `T5-02` |
| 優先度 | P2 |
| 主担当 | DS |
| 協力 | Process reviewer |
| 目的 | multi-material 境界の連続表現を強化する |

### 実装内容
- role pair ごとの界面場
- optional feature として保存
- core の必須要素にはしない

### 受け入れ条件
- `Field3D.interface_fields` が optional に持てる
- interface pair selection が spec 化される
- default off で基盤がシンプルに保たれる

### 価値
- 材料界面差を直接学習 / 評価しやすい
- 将来の multi-material surrogate に効く

---

## T5-03. sparse / adaptive storage watchlist

| 項目 | 内容 |
|---|---|
| ID | `T5-03` |
| 優先度 | P2 |
| 主担当 | Architect |
| 協力 | DS |
| 目的 | 将来の大規模化に備えた設計フックを残す |

### 実装内容
- 当面は full dense のまま
- ただし API は `FieldStorage` 抽象を意識する
- block sparse / narrow-band only / adaptive tree は watchlist として doc 化

### 受け入れ条件
- 現時点では本実装不要
- future extension point が設計文書に残る

### 価値
- いま過剰実装せず、将来の移行コストを下げる

---

## TX-01. テスト / synthetic goldens / examples

| 項目 | 内容 |
|---|---|
| ID | `TX-01` |
| 優先度 | P0 |
| 主担当 | Architect + DS |
| 協力 | Process reviewer |
| 目的 | 全タスクを実用可能な品質まで引き上げる |

### 必須 synthetic cases
- ideal trench
- bowed trench
- footed trench
- rounded-bottom trench
- overhang deposition
- pinch-off / closure case
- open polyline SEM case
- misaligned same-shape case

### 必須テスト
- unit
- regression
- parity
- schema validation
- artifact generation
- metric monotonic sanity check

### 受け入れ条件
- CI で最小セットが通る
- golden case report を docs に添付できる
- 新旧 metric の差が説明できる

### 価値
- 研究用途から基盤用途へ引き上げられる
- third party へ説明しやすい

---

## 6. 最小実装セット（まずここまでやれば価値が大きい）

最小でも価値が大きい順に並べると、次です。

1. `T0-01` Spec / capability 整理  
2. `T0-02` artifact/report 統一  
3. `T1-01` `Field3D` 導入  
4. `T1-02` exact distance API  
5. `T1-03` fixed 3-scale TSDF views  
6. `T2-01` SEM unsigned route  
7. `T2-03` `ObserverBundle`  
8. `T3-01` profiles  
9. `T3-02` corners  
10. `T3-03` `MetricBundle`  
11. `T4-01` assimilation migration  
12. `T4-02` surrogate export V2  
13. `TX-01` tests / goldens

この順で進めると、

- 既存 repo の資産を壊しにくい
- bottom / sidewall / closure の差が objective に出る
- future model selection を後ろ倒しにできる

という 3 つの利点を同時に取れます。

---

## 7. フェーズ完了ごとに何が可能になるか

| Phase 完了 | 可能になること |
|---|---|
| Phase 0 | 「設定したつもり」を排除し、run の意味を信頼できる |
| Phase 1 | raw distance canonical から任意 view を作れる |
| Phase 2 | SEM open contour を自然に比較できる |
| Phase 3 | CD だけでなく bottom / sidewall / rounded corner を評価できる |
| Phase 4 | 同化 objective と surrogate package が共通基盤で回る |
| Phase 5 | optional 高速化 / multi-material 強化へ進める |

---

## 8. 役割別レビュー観点

| 役割 | 重点確認点 |
|---|---|
| Data Scientist | scale choice, profile stability, semantic consistency, export usefulness |
| Architect | backward compatibility, spec strictness, capability gating, artifact schema |
| Process Specialist | width / angle / gap / thickness / corner が工程差を十分に反映するか |

---

## 9. タスクごとの関連文献・参照先まとめ

| Task | 主参照 |
|---|---|
| T0-01, T0-02 | Repo-03, Repo-06, Repo-07, Repo-09 |
| T1-01, T1-02 | Ref-B01, Ref-B03, Repo-04, Repo-05 |
| T1-03 | Ref-C01, Ref-C02, Repo-11 |
| T2-01 | Repo-08, Ref-C03, Ref-C04 |
| T2-02 | Repo-09 |
| T2-03 | Repo-06, Repo-15 |
| T3-01 | Ref-E01, Ref-E02, Ref-E03, Ref-E05 |
| T3-02 | Ref-E03, Ref-D01 |
| T3-03 | Ref-D01, Ref-D02, Repo-07 |
| T4-01 | Repo-09 |
| T4-02, T4-03 | Repo-10, Ref-C02, Ref-C05, Ref-F01, Ref-F02 |
| T5-01 | Ref-B02, Ref-B03 |
| T5-02 | Repo-04, Repo-13 |
| T5-03 | Repo-05 |

---

## 10. 非目標（この基盤ではやらないこと）

- process ごとの専用 observer / metric を大量に増やすこと
- neural training loop を core に入れること
- heavy SEM image formation model を core に入れること
- non-rigid registration を core に入れること
- sparse structure を初手から本実装すること
- research-only technique を production 前提で組み込むこと

---

## 11. 実装順の最終提案

```mermaid
flowchart LR
    A[T0-01 / T0-02\nspec + artifact] --> B[T1-01 / T1-02 / T1-03\nField3D + exact distance + TSDF views]
    B --> C[T2-01 / T2-03\nSEM unsigned + ObserverBundle]
    C --> D[T3-01 / T3-02 / T3-03\nProfiles + Corners + MetricBundle]
    D --> E[T4-01 / T4-02\nAssimilation + Surrogate export]
    E --> F[T5-01 / T5-02 / T5-03\nOptional future hooks]
```

この順で進めると、**複雑さを抑えながら価値を早く取り出せます**。
