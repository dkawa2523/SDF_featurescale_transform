# 04. 既存 repo への具体的改修内容と実装ロードマップ（v3 詳細版）

本章では、`SDF_featurescale_transform` / `wafergeo` に対して、  
**何を・どのファイルで・どう変えるか** を、実装に着手できる粒度で具体化します。

本章の目的は次の 3 つです。

1. 既存 repo を全面リライトせずに拡張する道筋を示す  
2. file-by-file に何を追加・変更・維持するかを明確にする  
3. pull request を安全に切れる単位へ落とす  

---

## 1. 改修の基本戦略

### 1.1 全面リライトしない
既存 repo には次の資産があります。

- layer separation の思想
- artifact-driven の設計
- observer / metric / assimilation / surrogate の責務分離
- docs に将来拡張の構想が整理されている

このため、最も筋が良いのは **追加 → shim → 内部移行** です。

```mermaid
flowchart LR
    A[現行 TSDF中心] --> B[Field3D を横に追加]
    B --> C[legacy API を shim 化]
    C --> D[Observer / Metrics を新基盤へ段階移行]
    D --> E[Assimilation / Surrogate を MetricBundle / ExportV2へ移行]
```

### 1.2 先に直すべきもの
最初にやるべきは fancy feature ではなく、**設計上の齟齬の整理** です。

- spec に書けるのに実装で無効な option
- registry に見えるのに stub な backend
- no-op な transform policy
- canonical と view の曖昧さ

これを先に整理しないと、後段の比較や検証が不安定になります。

---

## 2. 既存 repo と拡張後 repo の関係

### 2.1 既存の主要レイヤ
- `wafergeo/sdf/`
- `wafergeo/observe/`
- `wafergeo/metrics/`
- `wafergeo/assimilation/`
- `wafergeo/surrogate/`

### 2.2 拡張後に追加したい中核
- `wafergeo/core/grid.py`
- `wafergeo/core/roles.py`
- `wafergeo/core/field3d.py`
- `wafergeo/core/views.py`
- `wafergeo/observe/profiles.py`
- `wafergeo/observe/corners.py`
- `wafergeo/metrics/bundle.py`
- `wafergeo/metrics/profile_loss.py`
- `wafergeo/metrics/corner_loss.py`
- `wafergeo/sem/obs2d_from_contour.py`

### 2.3 なぜ `core/` を増やすのか
いまの repo では TSDF がかなり前面に出ています。  
新設する `core/` は、TSDF でも observer でも metric でもない  
**geometry canonical** を置くための層です。

---

## 3. 目標ディレクトリ構成

```text
wafergeo/
  core/
    __init__.py
    grid.py
    roles.py
    field3d.py
    views.py
    validation.py
    artifact_io.py

  sdf/
    edt.py
    tsdf.py
    boundary_features.py
    engines/
      __init__.py
      scipy_exact.py
      itk_exact.py         # optional
      cupy_exact.py        # optional

  observe/
    topdown.py
    slice.py
    profiles.py
    corners.py
    bundle.py

  sem/
    obs2d_from_mask.py
    obs2d_from_contour.py
    alignment.py

  metrics/
    field_loss.py
    curve_loss.py
    profile_loss.py
    corner_loss.py
    bundle.py
    cd_metrics.py          # legacy summary / compatibility

  assimilation/
    objective.py
    reports.py

  surrogate/
    export_v2.py
    query_samples.py
    mesh_export.py
```

**重要:** 既存 module を削除するのではなく、まずは責務を明確にする方向で整理します。

---

## 4. file-by-file 改修方針

## 4.1 `wafergeo/sdf/tsdf.py`

### 現状
- `to_tsdf(phi, mu)`
- `from_tsdf(tsdf, mu)`
- `label_from_tsdf(...)`

### 改修後の位置づけ
この file は削除しません。  
**legacy compatibility + distance view generator** として残します。

### 追加したい関数
```python
def to_tsdf_views(
    phi_nm: np.ndarray,
    mu_nm: dict[str, float],
    out_dtype: np.dtype | type[np.floating] = np.float16,
) -> dict[str, np.ndarray]:
    ...

def to_tanh_distance(phi_nm: np.ndarray, mu_nm: float) -> np.ndarray:
    ...

def to_logsigned_distance(
    phi_nm: np.ndarray,
    eps: float = 1e-6,
) -> tuple[np.ndarray, np.ndarray]:
    ...
```

### 実装方針
- `to_tsdf` / `from_tsdf` は保持
- `label_from_tsdf` も保持
- ただし新規コードは `Field3D.sdf_nm` から呼ぶ
- `TSDFVolume` builder は `Field3D -> DistanceViews` 経由へ誘導

### テスト
- `to_tsdf_views` の scale ごとの shape / range
- inverse consistency (`from_tsdf(to_tsdf(phi))`) narrow band 内で期待どおりか
- non-finite `mu` で fail-fast するか

---

## 4.2 `wafergeo/sdf/edt.py`

### 現状
- signed distance を mask から組み立てる要の層
- backend registry があるが、利用可能能力を表す contract が弱い

### 改修後の責務
- exact / approximate を含む distance backend facade
- spacing-aware の signed / unsigned distance API
- capability gating

### 推奨 public API
```python
@dataclass(frozen=True)
class DistanceBackendCaps:
    name: str
    exact: bool
    supports_signed: bool
    supports_unsigned: bool
    supports_spacing: bool
    supports_gpu: bool

def available_distance_backends() -> list[DistanceBackendCaps]:
    ...

def signed_distance_from_mask(
    mask: np.ndarray,
    spacing_nm: tuple[float, ...],
    *,
    backend: str = "scipy_exact",
    inside_negative: bool = True,
) -> np.ndarray:
    ...

def unsigned_distance_from_mask(
    mask: np.ndarray,
    spacing_nm: tuple[float, ...],
    *,
    backend: str = "scipy_exact",
) -> np.ndarray:
    ...
```

### 重要な変更点
- registry にある = 使える、ではなく  
  `available_distance_backends()` が実際の capability を返す
- unsupported backend 名は runtime fallback せず error
- `sampling` / `spacing` は明示引数に固定

### テスト
- SciPy exact backend の基礎ケース
- anisotropic spacing の距離一致
- empty / full mask での edge behavior
- unsupported backend で validation error

---

## 4.3 `wafergeo/core/field3d.py`（新規）

### 役割
canonical geometry を保持する最重要層です。

### 推奨内容
- `GridMeta`
- `RoleSpec`
- `Field3D`
- `build_field3d_from_label_volume(...)`
- `build_field3d_from_mesh(...)` は将来 hook
- `validate_field3d(...)`

### 推奨 builder API
```python
def build_field3d_from_labels(
    labels_zyx: np.ndarray,
    spacing_nm_zyx: tuple[float, float, float],
    role_spec: RoleSpec,
    *,
    backend: str = "scipy_exact",
    emit_udf: bool = False,
    emit_scalar_fields: list[str] | None = None,
) -> Field3D:
    ...
```

### builder の内部手順
1. raw material id を role id へ写像
2. role ごと binary mask を作る
3. 各 role の signed distance を計算
4. optional scalar fields を派生
5. QA を計算
6. `Field3D` を返す

### なぜ `Field3D` が別 file なのか
TSDF / EDT / observer と分けておくことで、  
canonical が何かを構造的に明確にできます。

---

## 4.4 `wafergeo/core/views.py`（新規）

### 役割
raw SDF から派生 view を作る層です。

### API 例
```python
@dataclass
class ViewSpec:
    tsdf_mu_nm: dict[str, float] | None = None
    tanh_mu_nm: dict[str, float] | None = None
    emit_logsigned: bool = False

def build_distance_views(field: Field3D, spec: ViewSpec) -> DistanceViews:
    ...
```

### 実装上の注意
- view の出力 dtype を軽くできる
- canonical の再現性は raw SDF 側で担保
- spec を artifact に保存

---

## 4.5 `wafergeo/observe/topdown.py`

### 現状
top exposure を見て mask / tsdf / contour を生成する

### 改修後
`Obs2D.distance2d_nm` 中心に寄せます。

### 推奨 public API
```python
def observe_topdown_exposed(
    field: Field3D,
    *,
    target_role: int | None = None,
    view_axis: str = "z-",
    signed_mode: bool = True,
) -> Obs2D:
    ...
```

### 追加すべき debug_maps
- `exposed_role_id`
- `top_height_nm`
- `hit_index_z`
- `valid_observation_mask`

### 変更理由
topdown は有用ですが、最終比較対象は mask ではなく `distance2d_nm` に寄せた方が downstream が統一されます。

---

## 4.6 `wafergeo/observe/slice.py`

### 現状
固定断面 observer がある

### 改修後
`Obs2D.distance2d_nm` を返し、profile/corner extractor の前段として使います。

### 推奨 API
```python
def observe_slice(
    field: Field3D,
    *,
    axis: str,
    position_nm: float | None = None,
    slab_thickness_nm: float = 0.0,
    target_role: int | None = None,
    signed_mode: bool = True,
) -> Obs2D:
    ...
```

### 実装方針
- `position_nm is None` の場合は center slice
- `slab_thickness_nm > 0` なら slab union
- output は `distance2d_nm`
- debug として sampled indices や slab support を保持

---

## 4.7 `wafergeo/observe/profiles.py`（新規）

### 役割
断面 `Obs2D` から generic profile 関数群を抽出します。

### 推奨 API
```python
@dataclass
class ProfileSpec:
    coordinate_axis: str = "z"
    smoothing_sigma_nm: float = 1.0
    functions: tuple[str, ...] = (
        "width",
        "centerline",
        "wall_angle",
        "curvature",
        "pair_separation",
    )

def extract_profiles(
    obs: Obs2D,
    *,
    spec: ProfileSpec,
) -> ProfileBundle:
    ...
```

### 実装上のキモ
- zero-crossing の検出方法を統一
- support mask を関数ごとに返す
- smoothing は spec に持たせる
- signed/unsigned で使える code path を分けすぎない

### 最初に実装すべき関数
- `width`
- `centerline`
- `wall_angle_left/right`
- `curvature_left/right`

`pair_separation` は phase 2 でよいです。

---

## 4.8 `wafergeo/observe/corners.py`（新規）

### 役割
断面輪郭から corner descriptor を抽出します。

### API 例
```python
@dataclass
class CornerSpec:
    top_window_nm: float
    bottom_window_nm: float
    smoothing_sigma_nm: float = 1.0
    side_split_mode: str = "centerline"

def extract_corners(obs: Obs2D, *, spec: CornerSpec) -> CornerBundle:
    ...
```

### 実装方針
- contour がある場合は contour 優先
- contour がない場合は distance2d の zero level から contour を再構成
- confidence / support count を返す
- noisy case に備えて percentile curvature を採用可能にする

---

## 4.9 `wafergeo/sem/obs2d_from_contour.py`（新規）

### 役割
SEM contour を signed/unsigned `Obs2D` に変換します。

### なぜ新規 module にするのか
SEM は geometry source として特殊であり、  
mask-based observer と切り分けた方が semantics が明確だからです。

### 推奨 API
```python
def obs2d_from_polyline(
    polyline_xy_nm: np.ndarray,
    *,
    grid_shape_yx: tuple[int, int],
    spacing_nm_yx: tuple[float, float],
    origin_nm_yx: tuple[float, float],
    mode: str = "unsigned_curve",
) -> Obs2D:
    ...
```

### mode
- `unsigned_curve`
- `signed_region`（閉曲線が保証される場合のみ）

---

## 4.10 `wafergeo/sem/alignment.py`（新規）

### 役割
SEM と simulation observation の比較前 alignment を担当します。

### core に入れる自由度
**2D similarity transform のみ** を推奨します。

- translation
- rotation
- isotropic scale

### 入れないもの
- nonrigid warp
- projective transform
- elastic registration

### 理由
自由度を増やすほど objective の解釈が壊れます。  
core では minimal にとどめる方が安全です。

---

## 4.11 `wafergeo/metrics/field_loss.py`

### 役割
2D / 3D distance field 同士の比較

### 推奨 API
```python
@dataclass
class FieldLossSpec:
    band_mode: str = "union"
    band_nm: float = 20.0
    robust: str = "charbonnier"
    scale_nm: float = 1.0

def field_loss(
    pred: Obs2D | np.ndarray,
    ref: Obs2D | np.ndarray,
    *,
    spec: FieldLossSpec,
) -> MetricComponent:
    ...
```

### 変更点
- `tsdf_loss.py` 的な責務を `field_loss.py` に一般化
- TSDF 固有より distance field 一般へ広げる
- signed / unsigned は input metadata でチェック

---

## 4.12 `wafergeo/metrics/curve_loss.py`（既存 contour metric を整理）

### 推奨 API
```python
@dataclass
class CurveLossSpec:
    mode: str = "chamfer_hd95"
    resample_step_nm: float = 1.0

def curve_loss(pred: Obs2D, ref: Obs2D, *, spec: CurveLossSpec) -> MetricComponent:
    ...
```

### 備考
- existing `contour_metrics.py` はここへ集約または adapter 化
- output は `MetricComponent`
- diagnostics に sample count / HD95 / mean normal deviation を保存

---

## 4.13 `wafergeo/metrics/profile_loss.py`（新規）

### 推奨 API
```python
@dataclass
class ProfileLossSpec:
    robust: str = "huber"
    per_function_scale: dict[str, float] = None

def profile_loss(
    pred: ProfileBundle,
    ref: ProfileBundle,
    *,
    spec: ProfileLossSpec,
) -> dict[str, MetricComponent]:
    ...
```

### 重要な方針
- support intersection だけで比較する
- 比較できなかった深さは diagnostics に記録
- scale は無次元化のために使う

---

## 4.14 `wafergeo/metrics/corner_loss.py`（新規）

### 推奨 API
```python
@dataclass
class CornerLossSpec:
    position_scale_nm: float = 2.0
    angle_scale_deg: float = 1.0
    radius_scale_nm: float = 2.0
    robust: str = "huber"

def corner_loss(
    pred: CornerBundle,
    ref: CornerBundle,
    *,
    spec: CornerLossSpec,
) -> dict[str, MetricComponent]:
    ...
```

### diagnostics
- missing corners
- confidence threshold
- support counts

---

## 4.15 `wafergeo/metrics/bundle.py`（新規）

### 役割
component metric をまとめ、total score を構成します。

### API 例
```python
@dataclass
class MetricBundleSpec:
    field_weight: float = 1.0
    curve_weight: float = 1.0
    profile_weight: float = 1.0
    corner_weight: float = 1.0
    topology_weight: float = 0.0

def build_metric_bundle(... ) -> MetricBundle:
    ...
```

### 方針
- weight は最小限
- total だけでなく component を保存
- objective evaluator は `MetricBundle` を返し、最終 scalar も持たせる

---

## 4.16 `wafergeo/metrics/cd_metrics.py`

### 現状
line-scan CD 指標

### 改修後
削除しません。  
ただし **legacy summary metric** に格下げします。

### 理由
CD は依然 useful ですが、中心ではなく summary と位置づけるべきです。

---

## 4.17 `wafergeo/assimilation/objective.py`

### 役割
optimizer に渡す objective evaluator

### 改修後の責務
- simulation output から `Field3D` を構築
- observer bundle を作る
- metric bundle を計算
- scalar objective と component report を返す

### 推奨 API
```python
def evaluate_objective(
    sim_output: Any,
    measurement_bundle: ObserverBundle,
    *,
    spec: "AssimilationSpec",
) -> MetricBundle:
    ...
```

### なぜ `MetricBundle` を返すのか
optimizer は scalar を使えばよいですが、  
開発者と工程担当者は component 分解を見たいからです。

---

## 4.18 `wafergeo/surrogate/export_v2.py`

### 役割
サロゲート学習や解析へ渡す dataset package 生成

### 推奨出力
- raw SDF
- TSDF small/mid/large
- 2D Obs2D
- profile tables
- corner tables
- optional mesh
- optional query samples
- meta / split / provenance

### ポイント
学習器を内蔵しない代わりに、**教師形式を豊富にする** ことで downstream flexibility を確保します。

---

## 5. 既存 docs / spec に対する改修

### 5.1 `2_sdf.md`
- canonical と view の区別を明記
- raw SDF first の説明を追加
- TSDF は derived view と明記

### 5.2 `4_observer.md`
- `Obs2D.distance2d_nm` を中心概念に格上げ
- observer kind を増やさず profile/corner extractor を補助機能として追記

### 5.3 `5_Metrics.md`
- `field + curve + profile + corner (+ topology)` へ拡張
- component report の重要性を追加
- CD は legacy summary として説明

### 5.4 `6_SEM_prepare.md`
- `unsigned_curve` route を明確に first-class 化
- open contour を closed mask に無理に変換しない方針を明記

### 5.5 `7_assimilation.md`
- objective evaluator が `MetricBundle` を返す設計へ更新
- transform は similarity2d のみ core 実装と記述

### 5.6 `8_surrogate.md`
- export V2 の payload と split / manifest を追記

---

## 6. 互換戦略

### 6.1 残すべき API
- `to_tsdf`
- `from_tsdf`
- `label_from_tsdf`
- existing contour/CD metric entry point

### 6.2 変えるべき実装中心
- internal canonical → `Field3D`
- observer output center → `Obs2D.distance2d_nm`
- assimilation objective → `MetricBundle`

### 6.3 shim の方針
旧 API は新 API を内部で呼ぶようにします。  
これにより downstream を一気に壊さずに済みます。

---

## 7. テスト戦略

### 7.1 synthetic golden cases
最低限、次の synthetic case を作るとよいです。

1. 直線側壁 trench
2. bowing trench
3. rounded bottom trench
4. microtrench 付き trench
5. conformal film
6. top-heavy overhang film
7. pinch-off 直前 / 直後
8. open contour SEM

### 7.2 各 case で検証すること
- raw SDF の符号
- TSDF views の range
- topdown / slice observer 出力
- `width/angle/curvature` の expected trend
- corner descriptor の位置と半径傾向
- metric component の大小関係

### 7.3 regression
- spec hash と effective spec
- artifact schema version
- profile support coverage
- numeric drift tolerance

---

## 8. 推奨マージ順

### PR1
- spec validation
- effective spec
- backend capability registry

### PR2
- `Field3D`
- `build_field3d_from_labels`
- distance views

### PR3
- SEM unsigned route
- `Obs2D` contract
- topdown / slice observer migration

### PR4
- profile extractor
- corner extractor

### PR5
- `field_loss / curve_loss / profile_loss / corner_loss`
- `MetricBundle`

### PR6
- assimilation migration
- surrogate export V2
- docs/examples/tests

この順にすると、レビューしやすく互換性も保ちやすいです。

---

## 9. 実装完了の定義

この提案が「実装完了」と言えるための条件は次です。

1. `Field3D` が raw SDF canonical として機能する  
2. `TSDFVolume` 系 API が shim 経由で動く  
3. SEM contour を unsigned `Obs2D` として扱える  
4. `ObserverBundle` が topdown + slice + profile + corner を返せる  
5. `MetricBundle` が component と total を返せる  
6. assimilation が `MetricBundle` ベースで動く  
7. surrogate export V2 が multi-format teacher を出せる  
8. docs / examples / goldens が揃っている  

---

## 10. 本章の結論

本章の要点は次です。

- 既存 repo は壊さずに拡張できる
- 核心は `Field3D` の導入と `Obs2D.distance2d_nm` 中心化
- process-specific class を増やさなくても、profile/corner/metric bundle で十分表現力を出せる
- file-by-file に見ると、やるべきことはかなり明確
- PR を小さく切れば安全に導入できる

次の `11_algorithm_specs_and_pseudocode.md` では、ここで定義した各機能を  
さらに一段細かく、**疑似コード・計算手順・入出力・失敗条件** まで落として説明します。
