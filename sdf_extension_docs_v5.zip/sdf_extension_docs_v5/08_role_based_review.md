# 08. 観点別レビュー: データサイエンティスト / アーキテクト / 半導体製造専門家

本章では、これまでの提案を 3 つの職能観点から見直し、  
「どこに価値があり、どこにリスクがあり、どう改善すべきか」を整理します。

---

## 1. データサイエンティスト観点

### 1.1 価値
- geometry canonical が統一される
- signed / unsigned semantics が明確になる
- same sample から複数 teacher を生成できる
- objective が component-wise になる
- failure analysis がしやすくなる

### 1.2 課題
- spec drift が残ると A/B テストが壊れる
- no-op option が残ると再現性を損なう
- profile extraction が不安定だと downstream が不安定になる
- SEM confidence と geometry が混ざると学習バイアスが入る

### 1.3 改善
- `effective_spec` を必ず保存
- unsigned / signed semantics を厳密化
- profile coverage / support mask を必須 report 化
- confidence map を geometry から分離
- canonical を raw SDF に寄せる

---

## 2. アーキテクト観点

### 2.1 価値
- layer separation を維持したまま拡張できる
- observer kind の爆発を避けられる
- backward compatibility を保ちやすい
- optional backend / downstream export の境界が明確

### 2.2 課題
- registry と実装能力がズレると危険
- process-specific class を入れ始めると保守不能
- alignment 自由度を増やしすぎると objective 解釈が崩れる
- artifact schema が曖昧だと downstream 依存が増える

### 2.3 改善
- capability gating
- `Field3D` / `Obs2D` / `MetricBundle` / `DatasetPackageV2` に抽象を限定
- similarity2d のみ core 実装
- artifact schema と spec version を厳密化
- shim で段階移行

---

## 3. 半導体製造専門家観点

### 3.1 価値
- CD 以外の重要形状差を objective に乗せられる
- bottom / corner / sidewall / closure が見える
- etch / deposition を共通 profile 基底で扱える
- explanation しやすい

### 3.2 課題
- SEM 像強度を geometry と混同しやすい
- topdown だけでは buried feature が見えない
- process 固有 terminology をそのまま core に入れると汎用性が落ちる
- topology loss を常用すると過剰設計になりうる

### 3.3 改善
- observer bundle に slice / profile を追加
- profile は width / angle / thickness / gap / curvature へ汎用化
- process 名ではなく geometry function へ落とす
- topology は optional に留める

---

## 4. 三者合意としての最終案

3 観点を合わせると、最終的に残る提案は非常にシンプルです。

1. raw SDF canonical
2. fixed 3-scale TSDF views
3. signed / unsigned Obs2D
4. standard observer bundle
5. field + curve + profile + corner metrics
6. export diversity
7. strict spec / capability / artifact

これが最もバランスが良く、長く使える形です。
