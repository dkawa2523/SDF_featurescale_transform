# 23. AGENTS / skills 最適化ノート

本章では、v4 の AGENTS / skills を v5 でどうブラッシュアップしたかを説明します。

---

## 1. root AGENTS を短くした理由

v5 では root `AGENTS.md` を「百科事典」ではなく **map** として書き直しています。
理由は単純で、長すぎる instruction は task / code / docs の可視性を落とすからです。

改善の方向は次の通りです。

- root AGENTS
  - repo の目的
  - 最重要 invariant
  - 読むべき docs
  - task routing
  - done checklist
- deeper detail
  - `docs/sdf_extension/*`
  - nested `AGENTS.md`
  - task-specific `SKILL.md`

この分離により、Codex が最初に読む情報は短く安定し、
必要なときだけ deeper context へ進めます。

---

## 2. nested AGENTS を追加した理由

Codex の AGENTS は directory tree scope で効きます。
そのため、`wafergeo/sdf/`, `wafergeo/observe/`, `wafergeo/metrics/`, `tests/` に
**局所ルール** を置くと、task ごとに relevant な制約だけを与えられます。

### 例
- `wafergeo/sdf/AGENTS.md`
  - no hidden fallback
  - exact / approximate semantics を metadata に残す
  - spacing-aware distance を壊さない
- `wafergeo/observe/AGENTS.md`
  - signed / unsigned semantics を明示
  - process-specific observer kind を増やしすぎない
- `wafergeo/metrics/AGENTS.md`
  - field / curve / profile / corner に分解
  - no giant scalar loss first
- `tests/AGENTS.md`
  - deterministic / tiny goldens / optional dependency isolation

---

## 3. skills を modular に分割した理由

v4 の skills は README 中心でしたが、v5 では **実際に trigger しやすい skill directory** へ分割しました。

### 分割方針
1. planner / migration
2. Field3D / distance
3. observer / SEM / profile / corner
4. MetricBundle / assimilation-facing losses
5. tests / goldens / export

### メリット
- trigger 説明を task area ごとに最適化できる
- 不要 skill が context を汚しにくい
- subagent ごとに attach しやすい

---

## 4. SKILL.md の書き方で意識したこと

- frontmatter の `name` と `description` に
  - repo 名
  - module 名
  - problem keyword
  - deliverable keyword
  を入れる
- body は「読む順」「やること」「やらないこと」「acceptance」を短く書く
- 長い説明は `references/*.md` に逃がす

---

## 5. 実装品質にどう効くか

### 5.1 AGENTS が短いと良い点
- task の本体が埋もれない
- stale な detail が root に残りにくい
- docs を system-of-record にしやすい

### 5.2 nested AGENTS があると良い点
- observe を直す task に metrics の細かい rules を押し付けない
- tests を直す task に process semantics を押し付けない

### 5.3 skill 分割が効く点
- Field3D task と export task で読むべき checklist が変わる
- reviewer task でも relevant skill を attach しやすい

---

## 6. v5 のおすすめ運用

1. repo root に `overlay/AGENTS.md` を置く
2. `overlay/docs/sdf_extension/*` を repo 内 docs として入れる
3. nested AGENTS も置く
4. code task では relevant skill を 1〜2 個だけ attach する
5. review task では reviewer prompt + relevant skill を attach する
6. root AGENTS を肥大化させず、detail は docs / skills に追加する
