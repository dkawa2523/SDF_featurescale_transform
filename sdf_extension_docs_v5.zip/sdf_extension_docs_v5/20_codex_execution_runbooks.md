# 20. Codex execution runbooks

本章では、この docs bundle を実際に Codex に食べさせて実装を進めるときの **運用 runbook** を示します。

---

## Runbook A. 初回セットアップ

### 目的
docs bundle と Codex assets を repo から使える状態にする。

### 手順
1. docs bundle を repo から参照できる場所へ置く
2. `codex_assets/AGENTS.md` を repo root にコピーまたは統合する
3. 必要なら OpenAI docs MCP を設定する
4. `codex_assets/prompts/00_master_orchestrator.md` を ask mode で流す
5. 出てきた最初の issue を採用する

### 完了条件
- AGENTS.md が有効
- docs bundle が repo から読める
- 初回 issue が決まった

---

## Runbook B. 1 issue を PR まで進める

### 手順
1. 対象 issue prompt を code mode で流す
2. Codex に short plan を出させる
3. 実装
4. architect / QA reviewer を別 task で流す
5. 必要なら implementer task へ差し戻す
6. `94_pr_body_and_finish.md` を流す
7. PR 本文を作る

### 推奨
- reviewer は ask mode
- implementer は code mode
- PR は 1 theme に絞る

---

## Runbook C. Phase 0〜1 を最短で進める

### 推奨順
1. I-01 fail-fast validation
2. I-02 backend capability registry
3. I-03 Field3D core
4. I-04 exact distance API
5. I-05 3-scale TSDF views
6. I-06 canonical role mapping

### なぜこの順か
- まず何が本当に動くか明確にする
- 次に canonical geometry を入れる
- その上で distance API と TSDF views を整理する
- role mapping は最後でも差し支えない

---

## Runbook D. SEM / Obs2D / Metric を進める

### 推奨順
1. I-07 signed / unsigned Obs2D
2. I-08 similarity2d alignment
3. I-09 ObserverBundle
4. I-10 generic profiles
5. I-11 generic corners
6. I-12 MetricBundle

### ポイント
- I-07 の semantics を曖昧にしない
- I-09 で observer kind を増やしすぎない
- I-10 / I-11 は generic geometry function に限定する
- I-12 は bundle report を重視する

---

## Runbook E. assimilation / surrogate / future を進める

### 推奨順
1. I-13 assimilation objective migration
2. I-14 surrogate export V2
3. I-15 goldens / regression / examples
4. I-16 optional exact backends
5. I-17 interface fields
6. I-18 sparse/adaptive watchlist doc

### ポイント
- optimizer 本体は触らず objective evaluator を強くする
- export は model-agnostic に保つ
- optional backend は default path を壊さない
- future work は docs 先行でよい

---

## Runbook F. reviewer の回し方

### 最小セット
- architect review
- QA review

### geometry-heavy issue
- DS / Process review も追加

### export / report-heavy issue
- docs / artifact review も追加

---

## Runbook G. 失敗しやすいパターン

### 失敗 1: issue をまたいで大きく実装する
対策:
- 1 issue / 1 theme に絞る
- finish prompt で scope creep を確認する

### 失敗 2: docs を更新しない
対策:
- prompt に docs / artifact 更新を必須で入れている
- docs reviewer を回す

### 失敗 3: process-specific function を増やす
対策:
- architect review を必ず通す
- generic geometry function に戻す

### 失敗 4: signed / unsigned semantics が崩れる
対策:
- I-07 以降は Obs2D contract を毎回確認する
- tests で semantics を固定する

---

## Runbook H. PR 最終確認 checklist

- [ ] acceptance criteria を満たした
- [ ] tests を追加または更新した
- [ ] docs を更新した
- [ ] artifact / schema 変更を明記した
- [ ] backward compatibility を説明した
- [ ] follow-up issue を列挙した

---

## まとめ

runbook を使う目的は、Codex が賢いことに期待するのではなく、  
**人間が merge しやすい単位で Codex を動かすこと** です。
