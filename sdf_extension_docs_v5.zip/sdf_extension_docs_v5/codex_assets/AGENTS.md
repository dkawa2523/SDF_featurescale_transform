# AGENTS.md

この repo の目的は、`dkawa2523/SDF_featurescale_transform` を
**raw SDF canonical / generic observer / MetricBundle / surrogate export** の方向へ、
既存 TSDF path を壊さず段階的に拡張することです。

## 最初に読むもの
- `02_extension_principles_and_design.md`
- `04_repo_modifications_implementation_plan.md`
- `11_algorithm_specs_and_pseudocode.md`
- `13_public_api_contracts.md`
- `22_repo_patch_skeleton_overview.md`
- 対象 task の issue prompt

## repo knowledge の考え方
- この AGENTS は **map** です
- 詳説は docs と skills に置きます
- rule を増やすより、relevant doc へ案内してください

## 最重要 invariant
1. canonical geometry は raw signed distance
2. TSDF は canonical ではなく derived view
3. signed / unsigned semantics は metadata 必須
4. process-specific API を core に増やしすぎない
5. unsupported capability / no-op option は fail-fast
6. backward compatibility は shim で守る
7. docs / tests / artifact shape を code と同期する

## task routing
- Field3D / distance / role mapping:
  - `wafergeo-field3d-distance`
- Obs2D / SEM contour / profile / corner:
  - `wafergeo-observer-sem-profiles`
- MetricBundle / loss / assimilation objective:
  - `wafergeo-metricbundle-losses`
- export / goldens / regression:
  - `wafergeo-tests-goldens-export`
- wave planning / minimal patching:
  - `wafergeo-implementation-planner`

## 実装の進め方
1. task の acceptance を 3〜7 行で要約する
2. changed files を先に列挙する
3. additive patch を優先する
4. existing behavior を壊す変更は shim / migration note を付ける
5. code と同時に test と docs を更新する

## やらないこと
- core に etch 専用 / deposition 専用分岐を増やす
- giant root AGENTS に詳細ルールを詰め込む
- weight 調整だけで難しい形状差を解決しようとする
- hidden fallback や silent behavior change を入れる

## done checklist
- changed files は最小か
- public contract を壊していないか
- sign / spacing / shape の test があるか
- docs / artifacts / reports を更新したか
- open risks を明記したか
