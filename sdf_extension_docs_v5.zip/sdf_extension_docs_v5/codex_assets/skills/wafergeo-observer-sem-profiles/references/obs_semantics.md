# observation semantics

- `distance_semantics` must be explicit (`signed` or `unsigned`)
- open SEM contours should remain unsigned by default
- signed observation from contours requires either a trustworthy mask or a clearly defined inside/outside rule
- profile names should be generic geometry names: width, edge position, wall angle, curvature, gap, thickness
