---
name: wafergeo-observer-sem-profiles
description: Use when implementing Obs2D, SEM contour to distance conversion, signed or unsigned 2D observation routes, generic profile extraction, corner extraction, topdown or slice observation bundles, or contour-based diagnostics for dkawa2523/SDF_featurescale_transform / wafergeo.
---
# wafergeo observer / sem / profiles

## Use this skill when
- touching `wafergeo/observe/*` or `wafergeo/sem/*`
- comparing SEM contours against simulation
- adding signed or unsigned observation routes
- extracting width, wall angle, curvature, corners

## Read first
- `03_methods_field_observer_metric.md`
- `12_third_party_handbook_and_examples.md`
- `13_public_api_contracts.md`
- overlay observe / sem files

## Required invariants
- `distance_semantics` is mandatory
- open contours are not forced closed by default
- observer names stay generic
- profile functions are geometry-based, not process-name-based

## Minimum outputs
- `Obs2D`
- `ProfileBundle`
- `CornerBundle`
- useful diagnostics in `debug_maps` or `diagnostics`

## Minimum tests
- contour distance image smoke test
- signed vs unsigned route behavior
- simple width profile on a rectangle
- corner extraction on a box-like mask
