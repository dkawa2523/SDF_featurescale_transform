# wafergeo Codex skills (v5)

このフォルダは、`SDF_featurescale_transform` 拡張向けに最適化した custom skill pack です。

## 設計方針
- 1 skill = 1 concern
- `SKILL.md` は trigger しやすい frontmatter を重視
- 長い説明は `references/` に逃がす
- root AGENTS は map、skill は task-specific workflow として使う

## 含まれる skill
- `wafergeo-implementation-planner`
- `wafergeo-field3d-distance`
- `wafergeo-observer-sem-profiles`
- `wafergeo-metricbundle-losses`
- `wafergeo-tests-goldens-export`

## 推奨運用
1. root / nested AGENTS を repo に置く
2. task に対応する skill を 1〜2 個だけ attach する
3. reviewer task でも same concern の skill を attach する
4. skill に長い設計書を埋め込まず `references/` へ分離する

## frontmatter について
Codex の skill trigger は `SKILL.md` frontmatter の `name` と `description` が重要です。
そのため、description には **repo 名、module 名、problem keyword、deliverable keyword** を明示しています。
