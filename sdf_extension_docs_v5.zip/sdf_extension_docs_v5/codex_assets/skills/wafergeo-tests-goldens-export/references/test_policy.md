# test policy

- use tiny synthetic fixtures first
- keep optional dependencies out of default tests when possible
- prefer exact, hand-checkable expectations
- export tests should verify manifest fields, units, and file presence
