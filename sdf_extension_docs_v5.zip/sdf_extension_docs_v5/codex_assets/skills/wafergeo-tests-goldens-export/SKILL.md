---
name: wafergeo-tests-goldens-export
description: Use when implementing deterministic tests, tiny synthetic goldens, surrogate export manifests, dataset package V2, or documentation synchronization for dkawa2523/SDF_featurescale_transform / wafergeo. Covers repo_patch_skeleton tests, artifact manifests, and regression-friendly sample outputs.
---
# wafergeo tests / goldens / export

## Use this skill when
- adding or updating tests
- adding tiny synthetic fixtures
- implementing `surrogate/export_v2.py`
- keeping docs and artifacts aligned

## Read first
- `07_appendix_example_specs_and_reports.md`
- `09_implementation_task_list.md`
- `22_repo_patch_skeleton_overview.md`
- overlay tests / export files

## Required invariants
- tests are deterministic and tiny
- optional dependency paths are isolated
- manifests are explicit about semantics / units / shapes
- docs examples match actual public contract names

## Minimum outputs
- pytest unit tests
- one sample manifest
- one export smoke test
- docs sync note in the final summary
