---
name: wafergeo-implementation-planner
description: Use when planning or scoping code changes for dkawa2523/SDF_featurescale_transform / wafergeo. Covers minimal patch planning, migration waves, backward-compatible shims, AGENTS/docs/tests sync, and issue-to-file mapping for Field3D, Obs2D, MetricBundle, and surrogate export work.
---
# wafergeo implementation planner

## Use this skill when
- you need to choose the smallest good patch
- you are mapping issue/task docs to concrete files
- you need a migration plan from legacy TSDF-centric code to Field3D-centric code
- you are deciding additive files vs. replacement vs. shim

## Read first
- `04_repo_modifications_implementation_plan.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `22_repo_patch_skeleton_overview.md`

## Workflow
1. Restate the task in one paragraph.
2. List target files and classify each as:
   - additive
   - shim
   - integration-only
   - docs/tests
3. State the acceptance criteria.
4. Name the risks and non-goals.
5. Only then write code.

## Keep these invariants
- canonical stays raw signed distance
- no process-specific core API
- no hidden fallback
- docs/tests move with code

## Deliverable format
```text
Scope:
Files:
Acceptance:
Non-goals:
Risks:
```
