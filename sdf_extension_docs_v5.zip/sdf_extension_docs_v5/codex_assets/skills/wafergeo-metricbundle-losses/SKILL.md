---
name: wafergeo-metricbundle-losses
description: Use when implementing MetricComponent, MetricBundle, field or curve or profile or corner losses, or assimilation-facing scalar objectives for dkawa2523/SDF_featurescale_transform / wafergeo. Covers decomposed losses, diagnostics, profile-function comparison, corner comparison, and scalarization hooks without process-specific branching.
---
# wafergeo metricbundle / losses

## Use this skill when
- touching `wafergeo/metrics/*`
- designing the assimilation objective
- converting shape differences into diagnostic loss components

## Read first
- `03_methods_field_observer_metric.md`
- `05_data_assimilation_surrogate_future.md`
- `13_public_api_contracts.md`
- overlay metrics files

## Required invariants
- keep field / curve / profile / corner separated
- do not hide everything inside one giant scalar loss
- store support and diagnostics per component
- scalarization is an explicit later step

## Minimum outputs
- MetricComponent dataclass
- MetricBundle dataclass
- one function per concern
- optional scalarization hook with caller-provided normalizers

## Minimum tests
- field narrow-band error
- contour chamfer / tail
- profile interpolation and comparison
- corner matching and support behavior
