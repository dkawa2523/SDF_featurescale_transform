# metric component policy

Prefer decomposed components:
- field
- curve
- profile
- corner
- topology (optional)

Every component should carry:
- value
- unit
- support summary
- diagnostics

Scalarization is a later, explicit step.
