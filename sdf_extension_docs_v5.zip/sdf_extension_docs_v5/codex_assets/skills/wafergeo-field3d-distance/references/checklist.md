# checklist

- Scope is explicit
- Changed files are listed first
- Public contract invariants are named
- Tests are added or updated
- Docs / artifacts are synced
- Residual risks are stated
