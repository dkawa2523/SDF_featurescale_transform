# field / distance invariants

- raw SDF is canonical
- TSDF is a derived view only
- role order must be explicit and stable
- sign convention must be tested
- anisotropic spacing must be preserved
- exact vs approximate backend capability must be surfaced, not hidden
