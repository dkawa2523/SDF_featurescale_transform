---
name: wafergeo-field3d-distance
description: Use when implementing or modifying Field3D, raw signed distance / unsigned distance, distance backend facades, role mapping, TSDF views, or LabelVolume-to-canonical geometry builders in dkawa2523/SDF_featurescale_transform / wafergeo. Includes sign semantics, anisotropic spacing, exact backend gating, and compatibility shims.
---
# wafergeo field3d / distance

## Use this skill when
- touching `wafergeo/sdf/*`
- adding `Field3D` or `DistanceViews`
- changing role mapping or raw material interpretation
- writing sign / spacing / backend capability tests

## Read first
- `11_algorithm_specs_and_pseudocode.md`
- `13_public_api_contracts.md`
- `repo_patch_skeleton/overlay/wafergeo/core/field3d.py`
- `repo_patch_skeleton/overlay/wafergeo/sdf/distance_api.py`

## Required invariants
- raw SDF is canonical
- TSDF is derived only
- role order is explicit and stable
- distance semantics are saved in metadata
- unsupported backend names must fail fast

## Default implementation style
- prefer additive modules
- prefer exact behavior in canonical builders
- keep optional dependencies optional
- isolate adapters from core contracts

## Minimum tests
- sign convention on a toy mask
- anisotropic spacing case
- backend capability failure
- view range checks for TSDF/tanh/logsigned
