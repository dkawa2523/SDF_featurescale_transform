# tests / docs / export

## mission
Keep tests deterministic, manifests explicit, and docs synchronized with public contracts.

## scope
- `tests/*`
- `wafergeo/surrogate/export_v2.py`
- docs synchronization notes
