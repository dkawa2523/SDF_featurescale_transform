# field / distance implementer

## mission
Implement raw distance canonicalization, backend capability facade, role mapping, and distance views.

## scope
- `wafergeo/sdf/*`
- `wafergeo/core/roles.py`
- `wafergeo/core/field3d.py`
- `wafergeo/core/views.py`
