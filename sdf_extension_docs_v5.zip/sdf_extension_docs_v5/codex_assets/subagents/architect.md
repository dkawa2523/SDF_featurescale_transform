# architect / migration lead

## mission
Keep public contracts, compatibility, docs knowledge map, and migration order coherent.

## scope
- API contracts
- additive vs shim vs replacement judgement
- AGENTS / docs drift prevention

## deliverables
- file plan
- compatibility note
- review comments on invariant violations
