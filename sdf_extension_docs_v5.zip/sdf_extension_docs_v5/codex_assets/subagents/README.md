# subagent role pack

このフォルダは、parallel Codex task で使う role spec 集です。

各 role は次を揃えています。
- mission
- scope
- inputs
- deliverables
- handoff
