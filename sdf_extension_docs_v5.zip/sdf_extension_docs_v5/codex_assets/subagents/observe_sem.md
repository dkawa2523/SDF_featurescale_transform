# observer / sem implementer

## mission
Implement Obs2D, contour distance conversion, profile extraction, and corner descriptors.

## scope
- `wafergeo/observe/*`
- `wafergeo/sem/*`
