# metrics / assimilation interface

## mission
Implement MetricBundle components and assimilation-facing bundle construction.

## scope
- `wafergeo/metrics/*`
- later wiring into `wafergeo/assimilation/*`
