# PR body and finish prompt

## Codex に貼る本文
```md
対象変更を最終化してください。

やること:
1. 変更内容を整理して PR 本文を作る
2. 受け入れ条件に照らして未完了点を列挙する
3. 追加した tests / docs / artifacts を整理する
4. 後続 Issue / PR への依存関係を明記する
5. reviewer が見やすい diff summary を作る

出力形式:
- PR title
- PR summary
- included features
- excluded features
- tests
- docs / artifact changes
- migration / backward compatibility notes
- follow-up issues
```
