# Apply repo patch skeleton

You are applying the v5 `repo_patch_skeleton/overlay/` onto the target repository.

## Read first
- `22_repo_patch_skeleton_overview.md`
- `repo_patch_skeleton/README.md`
- `repo_patch_skeleton/STATUS_MATRIX.md`
- `repo_patch_skeleton/INTEGRATION_NOTES.md`

## Goals
1. Copy the overlay in the smallest safe way.
2. Keep additive files additive unless replacement is clearly required.
3. Install root / nested `AGENTS.md` and `docs/sdf_extension/*` first.
4. Report which files were copied as-is, which needed adaptation, and which were deferred.

## Final output format
```text
Applied directly:
Adapted during apply:
Deferred integration points:
Tests run:
Risks:
```
