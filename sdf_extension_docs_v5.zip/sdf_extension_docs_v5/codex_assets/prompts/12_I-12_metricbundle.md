# I-12 / MetricBundle と component report を実装

このプロンプトは、`dkawa2523/SDF_featurescale_transform` を SDF 拡張設計に沿って段階実装するための **Codex 用タスクプロンプト** です。  
前提は、同梱 docs を repo 直下または `docs/sdf_extension_docs_v4/` などで参照できることです。  
docs の配置が違う場合は、**同名ファイルを検索して読む**ようにしてください。


## 推奨設定

| 項目 | 推奨 |
|---|---|
| Phase | Phase 3 |
| Mode | code |
| Reasoning effort | high |
| Internet | off |
| 推奨 branch 名 | `feat/i-12-metricbundle` |

## このタスクの狙い

評価の中心を CD 単体から field + curve + profile + corner (+ optional topology) の bundle へ上げる。

## 先に読む文書

- `02_extension_principles_and_design.md`
- `03_methods_field_observer_metric.md`
- `04_repo_modifications_implementation_plan.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `11_algorithm_specs_and_pseudocode.md`
- `13_public_api_contracts.md`

## 主な変更対象

- `wafergeo/metrics/field_loss.py or tsdf_loss.py`
- `wafergeo/metrics/contour_metrics.py`
- `wafergeo/metrics/profile_loss.py`
- `wafergeo/metrics/corner_loss.py`
- `wafergeo/metrics/bundle.py`
- `tests / reports`

## 期待する artifact / report

- `metric_bundle_report.json`

## このタスクの必須要件

1. MetricBundleSpec と MetricBundleResult を定義する
2. field / curve / profile / corner の component score と map/status を返す
3. cd_metrics.py は summary metric として共存させる
4. signed/unsigned Obs2D の両方で動くようにする

## 受け入れ条件

- [ ] total + components + subreports が一貫して返る
- [ ] Obs2D signed/unsigned 両対応
- [ ] component 別診断が report で見える
- [ ] legacy CD summary が残る

## このタスクでやらないこと

- プロセス別 loss 名を API に入れない
- 重み調整で複雑さを増やしすぎない
- topology loss を default 必須にしない

## 並列で回すと有用な reviewer prompt

- `90_review_architect.md`
- `91_review_ds_process.md`
- `92_review_tests_and_regression.md`

## 相性のよい custom skill

- `wafergeo-metricbundle-profiles-corners`
- `wafergeo-process-geometry-review`
- `wafergeo-regression-goldens`

## Codex に貼る本文

```md
あなたは `dkawa2523/SDF_featurescale_transform` を段階拡張している実装担当です。
今回の対象は **I-12 / MetricBundle と component report を実装** です。

最初にやること:
1. `AGENTS.md` を読む
2. docs bundle の以下を読む
   - 02_extension_principles_and_design.md
   - 03_methods_field_observer_metric.md
   - 04_repo_modifications_implementation_plan.md
   - 09_implementation_task_list.md
   - 10_issue_pr_breakdown.md
   - 11_algorithm_specs_and_pseudocode.md
   - 13_public_api_contracts.md
3. 変更対象ファイルを repo から特定する
4. 変更前に「触るファイル」「実装方針」「テスト方針」を 8 行以内でまとめる

実装目的:
評価の中心を CD 単体から field + curve + profile + corner (+ optional topology) の bundle へ上げる。

守る設計原則:
- canonical geometry は raw SDF / `Field3D`
- process-specific branch を core に入れない
- signed / unsigned semantics を明示する
- unsupported capability は fail-fast
- backward compatibility は必要なら shim で守る
- docs / artifact / schema を同期する

主な変更対象:
- wafergeo/metrics/field_loss.py or tsdf_loss.py
- wafergeo/metrics/contour_metrics.py
- wafergeo/metrics/profile_loss.py
- wafergeo/metrics/corner_loss.py
- wafergeo/metrics/bundle.py
- tests / reports

必須要件:
- MetricBundleSpec と MetricBundleResult を定義する
- field / curve / profile / corner の component score と map/status を返す
- cd_metrics.py は summary metric として共存させる
- signed/unsigned Obs2D の両方で動くようにする

受け入れ条件:
- total + components + subreports が一貫して返る
- Obs2D signed/unsigned 両対応
- component 別診断が report で見える
- legacy CD summary が残る

このタスクでやらないこと:
- プロセス別 loss 名を API に入れない
- 重み調整で複雑さを増やしすぎない
- topology loss を default 必須にしない

実装の進め方:
1. 既存コードの入口と依存関係を確認する
2. docs と矛盾しない最小構成を決める
3. 実装する
4. unit / regression / synthetic tests を追加または更新する
5. docs / report sample / schema を同期する
6. 最後に acceptance coverage を明示する

最後の出力形式:
- plan summary
- changed files
- implementation notes
- tests added or run
- docs / artifact changes
- acceptance criteria coverage
- remaining risks / follow-up

必要なら reviewer prompt も別タスクで回し、結果を踏まえて追加修正してください。
```
