# Parallel subagents wave 1

Launch or simulate parallel work for:
- architect
- field / distance
- tests / docs

Each role must use `24_subagent_role_specs.md` and return a handoff summary.
