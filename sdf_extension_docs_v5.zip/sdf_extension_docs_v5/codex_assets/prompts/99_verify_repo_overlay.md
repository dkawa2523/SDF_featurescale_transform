# Verify repo overlay

Verify that the applied overlay still respects the v5 public contracts.

## Check
- root and nested AGENTS are present and not contradictory
- public contract names match docs
- sign / spacing / shape tests exist
- docs/sdf_extension reflects the new code
- skills still point to the right files and concepts
