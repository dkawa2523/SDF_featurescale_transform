# Install repo AGENTS and skills

Install the optimized AGENTS / nested AGENTS / skills assets from v5 into the repository or workspace.

## Goals
- root AGENTS stays short and acts as a map
- nested AGENTS are added only where scope-specific rules help
- skills are installed modularly, not as one giant prompt blob
- do not duplicate long design docs into AGENTS
