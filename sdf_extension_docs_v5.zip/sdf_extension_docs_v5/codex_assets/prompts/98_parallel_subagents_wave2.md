# Parallel subagents wave 2

Launch or simulate parallel work for:
- observe / sem
- metrics / assimilation
- tests / docs

Ensure public contracts remain identical across roles.
