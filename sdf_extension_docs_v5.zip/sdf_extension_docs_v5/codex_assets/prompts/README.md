# prompts

このフォルダには、Codex へそのまま流しやすい prompt をまとめています。

## 構成

- `00_master_orchestrator.md`
  - まず全体 plan を作るための prompt
- `01_...` 〜 `18_...`
  - Issue 単位の実装 prompt
- `90_...` 以降
  - reviewer / finish 用 prompt

## 使い方

1. `AGENTS.md` を repo root に置く
2. 必要なら OpenAI docs MCP を設定する
3. `00_master_orchestrator.md` を ask mode で流す
4. 実装したい Issue の prompt を code mode で流す
5. 並列で reviewer prompt を別タスクとして流す
6. 最後に `94_pr_body_and_finish.md` を流して PR まとめを作る

## 推奨
- docs bundle は repo から読める場所に置く
- prompt 内の docs ファイル名は **同名検索で見つけられるように** しておく
- reviewer prompt は別タスクで走らせると有用
