# I-07 / SEM polyline / mask から signed / unsigned Obs2D を構築

このプロンプトは、`dkawa2523/SDF_featurescale_transform` を SDF 拡張設計に沿って段階実装するための **Codex 用タスクプロンプト** です。  
前提は、同梱 docs を repo 直下または `docs/sdf_extension_docs_v4/` などで参照できることです。  
docs の配置が違う場合は、**同名ファイルを検索して読む**ようにしてください。


## 推奨設定

| 項目 | 推奨 |
|---|---|
| Phase | Phase 2 |
| Mode | code |
| Reasoning effort | high |
| Internet | off |
| 推奨 branch 名 | `feat/i-07-sem-obs2d-signed-unsigned` |

## このタスクの狙い

open contour を無理に閉じず、polyline から unsigned distance2d、mask から signed distance2d を統一 API で扱えるようにする。

## 先に読む文書

- `02_extension_principles_and_design.md`
- `03_methods_field_observer_metric.md`
- `04_repo_modifications_implementation_plan.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `11_algorithm_specs_and_pseudocode.md`
- `13_public_api_contracts.md`

## 主な変更対象

- `wafergeo/sem_prepare/*`
- `wafergeo/observe/*`
- `Obs2D type definition`
- `tests for polyline/mask routes`

## 期待する artifact / report

- `obs2d_report.json with distance_semantics`

## このタスクの必須要件

1. Obs2D.distance2d_nm を signed/unsigned 両対応にする
2. distance_semantics を metadata/report に残す
3. polyline 解析距離 or robust distance path を入れる
4. mask route と polyline route を同じ Obs2D 契約で返す

## 受け入れ条件

- [ ] polyline -> unsigned Obs2D が動く
- [ ] mask -> signed Obs2D が動く
- [ ] same contour で両者の semantics の差が説明できる
- [ ] open SEM 用 synthetic test が追加される

## このタスクでやらないこと

- open contour を強制的に閉じない
- SEM 像強度ベースの重み設計まで同時実装しない
- Observer kind を増やしすぎない

## 並列で回すと有用な reviewer prompt

- `90_review_architect.md`
- `91_review_ds_process.md`
- `92_review_tests_and_regression.md`

## 相性のよい custom skill

- `wafergeo-sem-obs2d`
- `wafergeo-process-geometry-review`

## Codex に貼る本文

```md
あなたは `dkawa2523/SDF_featurescale_transform` を段階拡張している実装担当です。
今回の対象は **I-07 / SEM polyline / mask から signed / unsigned Obs2D を構築** です。

最初にやること:
1. `AGENTS.md` を読む
2. docs bundle の以下を読む
   - 02_extension_principles_and_design.md
   - 03_methods_field_observer_metric.md
   - 04_repo_modifications_implementation_plan.md
   - 09_implementation_task_list.md
   - 10_issue_pr_breakdown.md
   - 11_algorithm_specs_and_pseudocode.md
   - 13_public_api_contracts.md
3. 変更対象ファイルを repo から特定する
4. 変更前に「触るファイル」「実装方針」「テスト方針」を 8 行以内でまとめる

実装目的:
open contour を無理に閉じず、polyline から unsigned distance2d、mask から signed distance2d を統一 API で扱えるようにする。

守る設計原則:
- canonical geometry は raw SDF / `Field3D`
- process-specific branch を core に入れない
- signed / unsigned semantics を明示する
- unsupported capability は fail-fast
- backward compatibility は必要なら shim で守る
- docs / artifact / schema を同期する

主な変更対象:
- wafergeo/sem_prepare/*
- wafergeo/observe/*
- Obs2D type definition
- tests for polyline/mask routes

必須要件:
- Obs2D.distance2d_nm を signed/unsigned 両対応にする
- distance_semantics を metadata/report に残す
- polyline 解析距離 or robust distance path を入れる
- mask route と polyline route を同じ Obs2D 契約で返す

受け入れ条件:
- polyline -> unsigned Obs2D が動く
- mask -> signed Obs2D が動く
- same contour で両者の semantics の差が説明できる
- open SEM 用 synthetic test が追加される

このタスクでやらないこと:
- open contour を強制的に閉じない
- SEM 像強度ベースの重み設計まで同時実装しない
- Observer kind を増やしすぎない

実装の進め方:
1. 既存コードの入口と依存関係を確認する
2. docs と矛盾しない最小構成を決める
3. 実装する
4. unit / regression / synthetic tests を追加または更新する
5. docs / report sample / schema を同期する
6. 最後に acceptance coverage を明示する

最後の出力形式:
- plan summary
- changed files
- implementation notes
- tests added or run
- docs / artifact changes
- acceptance criteria coverage
- remaining risks / follow-up

必要なら reviewer prompt も別タスクで回し、結果を踏まえて追加修正してください。
```
