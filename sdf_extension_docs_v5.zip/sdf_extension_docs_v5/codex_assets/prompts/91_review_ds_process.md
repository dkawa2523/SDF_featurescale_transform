# Data science + process geometry review prompt

## 目的
このレビューは、変更が **学習しやすさ / loss としての意味 / 半導体形状評価としての妥当性** を持つかを確認するためのものです。

## 先に読むもの
- `03_methods_field_observer_metric.md`
- `05_data_assimilation_surrogate_future.md`
- `08_role_based_review.md`
- `12_third_party_handbook_and_examples.md`
- 対象 Issue prompt と差分

## Codex に貼る本文
```md
あなたは DS / semiconductor geometry review の担当です。

観点:
- この変更で何が「見える」ようになったか
- etch / deposition の両方に generic に効くか
- profile / corner / field / curve の意味が一貫しているか
- 学習データとして export したときの価値があるか
- 同化 loss として diagnostic value が上がっているか

特に確認:
1. width(z), wall_angle(z), curvature(z), gap(z), thickness(z) の意味が曖昧でないか
2. signed / unsigned semantics が混ざっていないか
3. bottom rounding, footing, overhang, closure などの差が見える設計か
4. 重み調整だけに依存せず、observable / representation を増やしているか
5. support mask / missing status / diagnostics が返るか

出力形式:
- DS/process verdict: pass / pass-with-fixes / fail
- what new signal becomes observable
- what remains blind
- required fixes
- synthetic tests to add
- downstream value for assimilation / surrogate
```
