# I-01 / Fail-fast validation と effective_spec 導入

このプロンプトは、`dkawa2523/SDF_featurescale_transform` を SDF 拡張設計に沿って段階実装するための **Codex 用タスクプロンプト** です。  
前提は、同梱 docs を repo 直下または `docs/sdf_extension_docs_v4/` などで参照できることです。  
docs の配置が違う場合は、**同名ファイルを検索して読む**ようにしてください。


## 推奨設定

| 項目 | 推奨 |
|---|---|
| Phase | Phase 0 |
| Mode | code |
| Reasoning effort | high |
| Internet | off |
| 推奨 branch 名 | `feat/i-01-fail-fast-validation` |

## このタスクの狙い

Spec と実装のズレを無くし、「設定できるが効かない」を禁止する。artifact に effective_spec と schema_version を残す。

## 先に読む文書

- `02_extension_principles_and_design.md`
- `04_repo_modifications_implementation_plan.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `13_public_api_contracts.md`

## 主な変更対象

- `wafergeo/config/*`
- `wafergeo/io/artifact*.py`
- `CLI / examples / manifests`

## 期待する artifact / report

- `effective_spec.yaml`
- `run_manifest.json`
- `capability_report.json`

## このタスクの必須要件

1. unsupported / unimplemented option は warning ではなく validation error にする
2. effective_spec.yaml と run/report schema version を必ず保存する
3. 実際に有効な capability だけが report / validation に現れるようにする
4. 既存 examples が fail-fast 挙動を示すように更新する

## 受け入れ条件

- [ ] 未実装 option 指定で job が失敗する
- [ ] artifact に effective_spec.yaml が残る
- [ ] report に schema_version が残る
- [ ] 回帰テストと examples が通る

## このタスクでやらないこと

- process-specific validation を増やさない
- backend 実装追加までこの Issue に混ぜない
- 曖昧な warning で通さない

## 並列で回すと有用な reviewer prompt

- `90_review_architect.md`
- `92_review_tests_and_regression.md`

## 相性のよい custom skill

- `wafergeo-core-architecture`
- `wafergeo-regression-goldens`

## Codex に貼る本文

```md
あなたは `dkawa2523/SDF_featurescale_transform` を段階拡張している実装担当です。
今回の対象は **I-01 / Fail-fast validation と effective_spec 導入** です。

最初にやること:
1. `AGENTS.md` を読む
2. docs bundle の以下を読む
   - 02_extension_principles_and_design.md
   - 04_repo_modifications_implementation_plan.md
   - 09_implementation_task_list.md
   - 10_issue_pr_breakdown.md
   - 13_public_api_contracts.md
3. 変更対象ファイルを repo から特定する
4. 変更前に「触るファイル」「実装方針」「テスト方針」を 8 行以内でまとめる

実装目的:
Spec と実装のズレを無くし、「設定できるが効かない」を禁止する。artifact に effective_spec と schema_version を残す。

守る設計原則:
- canonical geometry は raw SDF / `Field3D`
- process-specific branch を core に入れない
- signed / unsigned semantics を明示する
- unsupported capability は fail-fast
- backward compatibility は必要なら shim で守る
- docs / artifact / schema を同期する

主な変更対象:
- wafergeo/config/*
- wafergeo/io/artifact*.py
- CLI / examples / manifests

必須要件:
- unsupported / unimplemented option は warning ではなく validation error にする
- effective_spec.yaml と run/report schema version を必ず保存する
- 実際に有効な capability だけが report / validation に現れるようにする
- 既存 examples が fail-fast 挙動を示すように更新する

受け入れ条件:
- 未実装 option 指定で job が失敗する
- artifact に effective_spec.yaml が残る
- report に schema_version が残る
- 回帰テストと examples が通る

このタスクでやらないこと:
- process-specific validation を増やさない
- backend 実装追加までこの Issue に混ぜない
- 曖昧な warning で通さない

実装の進め方:
1. 既存コードの入口と依存関係を確認する
2. docs と矛盾しない最小構成を決める
3. 実装する
4. unit / regression / synthetic tests を追加または更新する
5. docs / report sample / schema を同期する
6. 最後に acceptance coverage を明示する

最後の出力形式:
- plan summary
- changed files
- implementation notes
- tests added or run
- docs / artifact changes
- acceptance criteria coverage
- remaining risks / follow-up

必要なら reviewer prompt も別タスクで回し、結果を踏まえて追加修正してください。
```
