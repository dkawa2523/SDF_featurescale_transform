# I-14 / surrogate export V2 を追加

このプロンプトは、`dkawa2523/SDF_featurescale_transform` を SDF 拡張設計に沿って段階実装するための **Codex 用タスクプロンプト** です。  
前提は、同梱 docs を repo 直下または `docs/sdf_extension_docs_v4/` などで参照できることです。  
docs の配置が違う場合は、**同名ファイルを検索して読む**ようにしてください。


## 推奨設定

| 項目 | 推奨 |
|---|---|
| Phase | Phase 4 |
| Mode | code |
| Reasoning effort | high |
| Internet | off |
| 推奨 branch 名 | `feat/i-14-surrogate-export-v2` |

## このタスクの狙い

どのモデルで学ぶかを core から切り離し、同一 sample から dense/query/mesh/Obs2D/profile を export できる V2 パッケージを作る。

## 先に読む文書

- `02_extension_principles_and_design.md`
- `04_repo_modifications_implementation_plan.md`
- `05_data_assimilation_surrogate_future.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `13_public_api_contracts.md`

## 主な変更対象

- `wafergeo/surrogate/package_v2.py`
- `wafergeo/surrogate/export_dense.py`
- `wafergeo/surrogate/export_query.py`
- `wafergeo/surrogate/export_mesh.py`
- `wafergeo/surrogate/export_profiles.py`
- `manifests / tests`

## 期待する artifact / report

- `surrogate_package_manifest.json`

## このタスクの必須要件

1. dense field / point-query / mesh or point cloud / Obs2D bundle / profile bundle を export する
2. manifest / lineage / split を残す
3. learning code を含めない
4. same sample から複数 export を再現可能にする

## 受け入れ条件

- [ ] 複数 export が同一 sample ID から生成される
- [ ] manifest と lineage が残る
- [ ] group split を保持できる
- [ ] docs / examples / schema が更新される

## このタスクでやらないこと

- 学習 loop や model code を入れない
- export format を process-specific にしない
- sample lineage を省略しない

## 並列で回すと有用な reviewer prompt

- `90_review_architect.md`
- `91_review_ds_process.md`
- `93_review_docs_and_artifacts.md`

## 相性のよい custom skill

- `wafergeo-surrogate-export-v2`
- `wafergeo-core-architecture`

## Codex に貼る本文

```md
あなたは `dkawa2523/SDF_featurescale_transform` を段階拡張している実装担当です。
今回の対象は **I-14 / surrogate export V2 を追加** です。

最初にやること:
1. `AGENTS.md` を読む
2. docs bundle の以下を読む
   - 02_extension_principles_and_design.md
   - 04_repo_modifications_implementation_plan.md
   - 05_data_assimilation_surrogate_future.md
   - 09_implementation_task_list.md
   - 10_issue_pr_breakdown.md
   - 13_public_api_contracts.md
3. 変更対象ファイルを repo から特定する
4. 変更前に「触るファイル」「実装方針」「テスト方針」を 8 行以内でまとめる

実装目的:
どのモデルで学ぶかを core から切り離し、同一 sample から dense/query/mesh/Obs2D/profile を export できる V2 パッケージを作る。

守る設計原則:
- canonical geometry は raw SDF / `Field3D`
- process-specific branch を core に入れない
- signed / unsigned semantics を明示する
- unsupported capability は fail-fast
- backward compatibility は必要なら shim で守る
- docs / artifact / schema を同期する

主な変更対象:
- wafergeo/surrogate/package_v2.py
- wafergeo/surrogate/export_dense.py
- wafergeo/surrogate/export_query.py
- wafergeo/surrogate/export_mesh.py
- wafergeo/surrogate/export_profiles.py
- manifests / tests

必須要件:
- dense field / point-query / mesh or point cloud / Obs2D bundle / profile bundle を export する
- manifest / lineage / split を残す
- learning code を含めない
- same sample から複数 export を再現可能にする

受け入れ条件:
- 複数 export が同一 sample ID から生成される
- manifest と lineage が残る
- group split を保持できる
- docs / examples / schema が更新される

このタスクでやらないこと:
- 学習 loop や model code を入れない
- export format を process-specific にしない
- sample lineage を省略しない

実装の進め方:
1. 既存コードの入口と依存関係を確認する
2. docs と矛盾しない最小構成を決める
3. 実装する
4. unit / regression / synthetic tests を追加または更新する
5. docs / report sample / schema を同期する
6. 最後に acceptance coverage を明示する

最後の出力形式:
- plan summary
- changed files
- implementation notes
- tests added or run
- docs / artifact changes
- acceptance criteria coverage
- remaining risks / follow-up

必要なら reviewer prompt も別タスクで回し、結果を踏まえて追加修正してください。
```
