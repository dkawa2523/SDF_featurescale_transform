# 00 / Master orchestrator prompt

このプロンプトは、Codex に **全体 plan と実装順** を作らせるためのものです。  
最初に 1 回だけ流し、以後は issue prompt を個別に流す想定です。

## 推奨設定

| 項目 | 推奨 |
|---|---|
| Mode | ask → 必要なら code |
| Reasoning effort | high |
| Internet | off |
| 出力 | issue / PR / branch / parallel reviewer 計画 |

## 先に読む文書

- `00_README.md`
- `02_extension_principles_and_design.md`
- `03_methods_field_observer_metric.md`
- `04_repo_modifications_implementation_plan.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `14_codex_prompt_pack_overview.md`
- `15_codex_orchestration_and_parallel_roles.md`
- `19_codex_prompt_index.md`

## Codex に貼る本文

```md
あなたは `dkawa2523/SDF_featurescale_transform` の拡張実装を段階的に進めるオーケストレータです。
まず docs bundle を読み、repo の現状を軽く確認した上で、実装順と PR の切り方を提案してください。

必ず守ること:
- 一度に大きく実装しすぎない
- 1 issue / 1 theme の単位で切る
- process-specific branch を core に入れない
- raw SDF canonical を崩さない
- fail-fast validation と artifact hygiene を最優先する
- tests / docs / artifact sample まで含める

やること:
1. docs bundle を読んで全体像を把握する
2. repo 内の該当モジュールを確認する
3. Issue / PR / branch の順序を提案する
4. 並列で回せる reviewer task を提案する
5. 最初に着手すべき issue を 1 つ選び、その理由を述べる
6. 以後の prompt の使い分けを提案する

出力形式:
- repo state summary
- recommended merge order
- first issue to implement next
- branch plan
- parallel reviewer plan
- risk register
```
