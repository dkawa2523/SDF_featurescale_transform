# I-03 / Field3D core types と builder skeleton を追加

このプロンプトは、`dkawa2523/SDF_featurescale_transform` を SDF 拡張設計に沿って段階実装するための **Codex 用タスクプロンプト** です。  
前提は、同梱 docs を repo 直下または `docs/sdf_extension_docs_v4/` などで参照できることです。  
docs の配置が違う場合は、**同名ファイルを検索して読む**ようにしてください。


## 推奨設定

| 項目 | 推奨 |
|---|---|
| Phase | Phase 1 |
| Mode | code |
| Reasoning effort | high |
| Internet | off |
| 推奨 branch 名 | `feat/i-03-field3d-core` |

## このタスクの狙い

TSDF ではなく raw signed distance を canonical geometry とする最小の Field3D 抽象を導入する。

## 先に読む文書

- `02_extension_principles_and_design.md`
- `04_repo_modifications_implementation_plan.md`
- `09_implementation_task_list.md`
- `10_issue_pr_breakdown.md`
- `11_algorithm_specs_and_pseudocode.md`
- `13_public_api_contracts.md`

## 主な変更対象

- `wafergeo/field/types.py or wafergeo/core/field3d.py`
- `wafergeo/field/build.py`
- `wafergeo/field/__init__.py`
- `tests for Field3D`

## 期待する artifact / report

- `field3d_manifest.json or equivalent field metadata`

## このタスクの必須要件

1. Field3D が grid / spacing / origin / roles / sdf_nm / optional udf_nm / scalar_fields / meta を持てるようにする
2. label volume から Field3D を生成する minimal builder を実装する
3. 既存 TSDF path を壊さず shim で共存させる準備をする
4. module 配置は repo に一貫した形に寄せる

## 受け入れ条件

- [ ] label volume -> Field3D が動く
- [ ] Field3D の shape / dtype / meta 契約が tests で固定される
- [ ] legacy TSDF path は壊れない
- [ ] docs と API 契約が更新される

## このタスクでやらないこと

- interface fields や sparse storage をこの段階で入れない
- process-specific field 名を入れない
- Field3D に学習専用 state を入れない

## 並列で回すと有用な reviewer prompt

- `90_review_architect.md`
- `91_review_ds_process.md`
- `92_review_tests_and_regression.md`

## 相性のよい custom skill

- `wafergeo-core-architecture`
- `wafergeo-field3d-builder`

## Codex に貼る本文

```md
あなたは `dkawa2523/SDF_featurescale_transform` を段階拡張している実装担当です。
今回の対象は **I-03 / Field3D core types と builder skeleton を追加** です。

最初にやること:
1. `AGENTS.md` を読む
2. docs bundle の以下を読む
   - 02_extension_principles_and_design.md
   - 04_repo_modifications_implementation_plan.md
   - 09_implementation_task_list.md
   - 10_issue_pr_breakdown.md
   - 11_algorithm_specs_and_pseudocode.md
   - 13_public_api_contracts.md
3. 変更対象ファイルを repo から特定する
4. 変更前に「触るファイル」「実装方針」「テスト方針」を 8 行以内でまとめる

実装目的:
TSDF ではなく raw signed distance を canonical geometry とする最小の Field3D 抽象を導入する。

守る設計原則:
- canonical geometry は raw SDF / `Field3D`
- process-specific branch を core に入れない
- signed / unsigned semantics を明示する
- unsupported capability は fail-fast
- backward compatibility は必要なら shim で守る
- docs / artifact / schema を同期する

主な変更対象:
- wafergeo/field/types.py or wafergeo/core/field3d.py
- wafergeo/field/build.py
- wafergeo/field/__init__.py
- tests for Field3D

必須要件:
- Field3D が grid / spacing / origin / roles / sdf_nm / optional udf_nm / scalar_fields / meta を持てるようにする
- label volume から Field3D を生成する minimal builder を実装する
- 既存 TSDF path を壊さず shim で共存させる準備をする
- module 配置は repo に一貫した形に寄せる

受け入れ条件:
- label volume -> Field3D が動く
- Field3D の shape / dtype / meta 契約が tests で固定される
- legacy TSDF path は壊れない
- docs と API 契約が更新される

このタスクでやらないこと:
- interface fields や sparse storage をこの段階で入れない
- process-specific field 名を入れない
- Field3D に学習専用 state を入れない

実装の進め方:
1. 既存コードの入口と依存関係を確認する
2. docs と矛盾しない最小構成を決める
3. 実装する
4. unit / regression / synthetic tests を追加または更新する
5. docs / report sample / schema を同期する
6. 最後に acceptance coverage を明示する

最後の出力形式:
- plan summary
- changed files
- implementation notes
- tests added or run
- docs / artifact changes
- acceptance criteria coverage
- remaining risks / follow-up

必要なら reviewer prompt も別タスクで回し、結果を踏まえて追加修正してください。
```
