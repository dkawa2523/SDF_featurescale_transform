# 15. Codex orchestration and parallel roles

本章では、Codex を使ってこの repo を段階実装するときの **並列運用モデル** を定義します。  
ここでいう「サブエージェント」は、Codex に built-in の subagent 機能があると断定するものではなく、**並列 task と role prompt を組み合わせた運用パターン** を指します。

---

## 1. なぜ並列ロールが有効か

この repo の拡張は、単純なコード追加ではありません。  
少なくとも次の 4 観点が衝突します。

- Architect: 抽象の増やしすぎを防ぐ
- DS: 学習しやすさ・loss 表現・observability
- Process specialist: 半導体形状差が本当に見えているか
- QA: regression / deterministic / artifact integrity

1 本の task に全部載せると、どれかが漏れやすいです。  
そこで、本 pack では reviewer prompt を role ごとに分けています。

---

## 2. 並列ロール構成

```mermaid
flowchart LR
    O[Orchestrator] --> I[Implementer]
    I --> A[Architect reviewer]
    I --> D[DS / Process reviewer]
    I --> Q[QA / Regression reviewer]
    I --> R[Docs / Artifact reviewer]
    A --> M[Merge-ready revision]
    D --> M
    Q --> M
    R --> M
```

### 2.1 Orchestrator
- docs bundle を読む
- 今どの issue をやるべきか決める
- PR の切り方を提案する
- reviewer を誰に割り振るか決める

使用 prompt:
- `codex_assets/prompts/00_master_orchestrator.md`

### 2.2 Implementer
- 対象 issue の実装を進める
- tests / docs / artifacts まで更新する

使用 prompt:
- `codex_assets/prompts/01_...` 〜 `18_...`

### 2.3 Architect reviewer
- abstraction / fail-fast / schema / compatibility をチェックする

使用 prompt:
- `codex_assets/prompts/90_review_architect.md`

### 2.4 DS / Process reviewer
- observability / metric meaning / semiconductor geometry capture をチェックする

使用 prompt:
- `codex_assets/prompts/91_review_ds_process.md`

### 2.5 QA / Regression reviewer
- unit / synthetic / deterministic / report integrity をチェックする

使用 prompt:
- `codex_assets/prompts/92_review_tests_and_regression.md`

### 2.6 Docs / Artifact reviewer
- third-party readability / artifact schema / examples をチェックする

使用 prompt:
- `codex_assets/prompts/93_review_docs_and_artifacts.md`

---

## 3. どの issue で reviewer を並列に走らせるべきか

| Phase | Issue | Implementer の他に最低限ほしい reviewer |
|---|---|---|
| 0 | I-01, I-02 | Architect, QA |
| 1 | I-03, I-04, I-05 | Architect, DS, QA |
| 1 | I-06 | Architect, DS |
| 2 | I-07, I-08, I-09 | Architect, DS, QA |
| 3 | I-10, I-11 | DS / Process, QA |
| 3 | I-12 | Architect, DS, QA |
| 4 | I-13, I-14 | Architect, DS, Docs |
| 4 | I-15 | QA, Docs |
| 5 | I-16 | Architect, QA, Docs |
| 5 | I-17 | Architect, DS |
| 5 | I-18 | Architect, Docs |

---

## 4. 推奨の実行パターン

### パターン A: 1 issue を堅く進める
1. master prompt で次の issue を決める
2. issue prompt を code mode で実行
3. architect reviewer を別 task で実行
4. QA reviewer を別 task で実行
5. 差分を反映
6. PR finish prompt でまとめる

### パターン B: Phase 単位で流す
1. master prompt で Phase の順序を整理
2. Phase 内の issue を依存順で分ける
3. 実装可能な issue だけ code mode で動かす
4. reviewer prompt は各 issue 後に回す
5. 次 issue に進む

### パターン C: docs 先行レビュー
1. ask mode で設計差分を先に出す
2. architect reviewer で妥当性を見る
3. code mode へ移行する

---

## 5. 「手動サブエージェント」としての使い方

Codex cloud は task を並列に走らせやすいので、  
次のような **親 task + 子 task** の使い方が実務的です。

```mermaid
sequenceDiagram
    participant U as User
    participant O as Orchestrator Task
    participant I as Implementer Task
    participant A as Architect Review Task
    participant D as DS Review Task
    participant Q as QA Review Task

    U->>O: master prompt
    O-->>U: 次にやる Issue と reviewer 計画
    U->>I: issue prompt
    U->>A: architect review prompt
    U->>D: DS review prompt
    U->>Q: QA review prompt
    I-->>U: 実装差分
    A-->>U: architecture 指摘
    D-->>U: observability / geometry 指摘
    Q-->>U: test / regression 指摘
    U->>I: 指摘を反映して finish
```

この方式の利点は、review 観点が prompt に固定されるため、  
「毎回 reviewer の観点がぶれる」問題を抑えやすいことです。

---

## 6. 並列にしやすい task / しにくい task

### 並列にしやすい
- I-01 / I-02 と QA review
- I-10 / I-11 の profile / corner review
- I-14 の export 設計と docs review
- I-15 の synthetic goldens と docs sample review

### 並列にしにくい
- I-03 Field3D core
- I-04 exact distance API
- I-12 MetricBundle 統合
- I-13 assimilation objective migration

これらは abstraction の中心なので、まず implementer が形を作り、後から reviewer を入れる方が安定します。

---

## 7. reviewer に期待する出力

reviewer prompt の出力は、次のように揃えると使いやすいです。

- verdict: `pass / pass-with-fixes / fail`
- major findings
- required fixes
- optional improvements
- risk notes
- tests to add
- docs/artifact notes

このフォーマットを固定しておくと、implementer が後で統合しやすくなります。

---

## 8. 実運用上の注意

### 8.1 reviewer は code edit させなくてもよい
reviewer は ask mode で十分なことが多いです。  
むしろ review 専用にすると、diff を汚さず観点だけ得られます。

### 8.2 設計中心 task は先に architect reviewer を入れる
Field3D, Obs2D, MetricBundle, DatasetPackageV2 まわりは、  
後から直すと ripple が大きいので、先に architect reviewer を回すのが安全です。

### 8.3 geometry meaning が絡む task は DS / Process reviewer を必ず入れる
profile / corner / metric 周辺は、実装が正しくても geometry の意味が弱いことがあります。  
この観点は分離した方がよいです。

---

## 9. まとめ

本 pack における「サブエージェント」は、  
**専用の role prompt を与えた並列 task の運用** として捉えるのが最も実務的です。  
この方式なら、Codex の環境差に依らず、

- 実装
- architecture review
- DS / process review
- QA / docs review

を分離できます。
