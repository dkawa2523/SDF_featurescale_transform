# 13. 公開 API 契約・shape・error・artifact 契約

本章では、拡張版で外部から参照される public API について、  
**型・shape・semantics・エラー条件・互換方針** を定義します。

この章の目的は、実装者間で「同じ名前だが意味が違う」状態を防ぐことです。

---

## 1. 基本ルール

### 1.1 shape は必ず明記する
- 3D volume は `[Z, Y, X]`
- role stack は `[R, Z, Y, X]`
- 2D map は `[Y, X]`
- contour は `[N, 2]` with `(x_nm, y_nm)`

### 1.2 座標系は nm を標準単位とする
- 距離
- 原点
- contour 座標
- profile 座標

は nm を使います。  
内部 index は diagnostics に持ってもよいですが、public 契約は nm 優先です。

### 1.3 signed / unsigned semantics は metadata に必須保存する
- `distance_semantics: "signed" | "unsigned"`

---

## 2. Public dataclass 契約

## 2.1 `GridMeta`
```python
@dataclass(frozen=True)
class GridMeta:
    shape_zyx: tuple[int, int, int]
    spacing_nm_zyx: tuple[float, float, float]
    origin_nm_zyx: tuple[float, float, float]
    axis_order: Literal["zyx"] = "zyx"
    frame: Literal["simulation", "measurement", "canonical"] = "canonical"
```

### 契約
- `shape_zyx` の各要素は正整数
- `spacing_nm_zyx` の各要素は有限かつ正
- `axis_order` は現時点 `"zyx"` のみ
- `origin_nm_zyx` は grid index `(0,0,0)` の物理位置

---

## 2.2 `RoleSpec`
```python
@dataclass(frozen=True)
class RoleSpec:
    raw_material_to_role: dict[int, int]
    role_id_to_name: dict[int, str]
    void_role_id: int
```

### 契約
- `void_role_id` は `role_id_to_name` に含まれる
- `raw_material_to_role` の値はすべて `role_id_to_name` の key に含まれる
- role 名は stable であることを推奨

---

## 2.3 `Field3D`
```python
@dataclass
class Field3D:
    grid: GridMeta
    roles: RoleSpec
    sdf_nm: np.ndarray                 # shape [R,Z,Y,X], float32
    udf_nm: np.ndarray | None = None   # shape [R,Z,Y,X], float32
    scalar_fields: dict[str, np.ndarray] = field(default_factory=dict)
    interface_fields: dict[str, np.ndarray] = field(default_factory=dict)
    support_mask: np.ndarray | None = None   # shape [Z,Y,X], bool
    qa: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)
```

### 契約
- `sdf_nm.dtype == float32` を推奨
- `sdf_nm.shape[0] == len(roles.role_id_to_name)`
- `udf_nm` がある場合 shape は `sdf_nm` と一致
- `support_mask` がある場合 shape は `[Z,Y,X]`
- `scalar_fields` の各 array は
  - `[Z,Y,X]` または
  - `[R,Z,Y,X]` または
  - `[Y,X]`（topdown 派生を保存する場合）
- `meta["distance_semantics"] = "signed"` を必須とする

---

## 2.4 `DistanceViews`
```python
@dataclass
class DistanceViews:
    tsdf_views: dict[str, np.ndarray]
    tanh_views: dict[str, np.ndarray]
    logsigned_views: dict[str, tuple[np.ndarray, np.ndarray]]
    meta: dict[str, Any]
```

### 契約
- 各 TSDF view は shape `[R,Z,Y,X]`
- 各 TSDF view の値域は `[-1,1]`
- `logsigned_views[name] = (sign, mag)`
  - `sign.shape == mag.shape == [R,Z,Y,X]`
  - `sign.dtype == int8`
  - `mag.dtype == float32`

---

## 2.5 `Obs2D`
```python
@dataclass
class Obs2D:
    grid2d_shape_yx: tuple[int, int]
    spacing_nm_yx: tuple[float, float]
    origin_nm_yx: tuple[float, float]
    axis_order: str
    distance2d_nm: np.ndarray          # [Y,X], float32
    mask2d: np.ndarray | None = None   # [Y,X], bool
    contours_xy_nm: list[np.ndarray] | None = None
    confidence: np.ndarray | None = None
    transform: dict[str, Any] | None = None
    debug_maps: dict[str, np.ndarray] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)
```

### 契約
- `distance2d_nm.shape == grid2d_shape_yx`
- `meta["distance_semantics"]` は必須
- `mask2d` がある場合 shape は `[Y,X]`
- `confidence` がある場合 shape は `[Y,X]`
- contour は各要素が `[N,2]` で `(x_nm, y_nm)` 順

---

## 2.6 `ProfileBundle`
```python
@dataclass
class ProfileBundle:
    coordinate_name: str
    coordinate_nm: np.ndarray
    values: dict[str, np.ndarray]
    support_mask: dict[str, np.ndarray]
    diagnostics: dict[str, Any] = field(default_factory=dict)
```

### 契約
- `coordinate_nm.shape == [K]`
- 各 `values[name].shape == [K]`
- 各 `support_mask[name].shape == [K]`
- `np.nan` は未定義値として許可
- support が `False` の位置は loss 対象にしない

---

## 2.7 `CornerDescriptor` / `CornerBundle`
```python
@dataclass
class CornerDescriptor:
    name: str
    position_nm: tuple[float, float]
    tangent_angle_deg: float
    curvature_inv_nm: float
    radius_like_nm: float
    confidence: float
    support_count: int

@dataclass
class CornerBundle:
    corners: dict[str, CornerDescriptor]
```

### 契約
- 標準 corner 名: `top_left`, `top_right`, `bottom_left`, `bottom_right`
- `confidence` は `[0,1]` を推奨
- missing corner は `confidence=0` で表現してよい

---

## 2.8 `MetricComponent` / `MetricBundle`
```python
@dataclass
class MetricComponent:
    name: str
    value: float
    unit: str
    support: dict[str, float]
    diagnostics: dict[str, Any] = field(default_factory=dict)

@dataclass
class MetricBundle:
    field: dict[str, MetricComponent] = field(default_factory=dict)
    curve: dict[str, MetricComponent] = field(default_factory=dict)
    profile: dict[str, MetricComponent] = field(default_factory=dict)
    corner: dict[str, MetricComponent] = field(default_factory=dict)
    topology: dict[str, MetricComponent] = field(default_factory=dict)
    total: MetricComponent | None = None
    meta: dict[str, Any] = field(default_factory=dict)
```

### 契約
- `total` は最終 scalar objective
- 各 component は support と diagnostics を持つ
- diagnostics は reproducibility / debugging 用で、loss そのものの意味を壊さないこと

---

## 3. Public function 契約

## 3.1 `build_field3d_from_labels`
```python
def build_field3d_from_labels(
    labels_zyx: np.ndarray,
    spacing_nm_zyx: tuple[float, float, float],
    role_spec: RoleSpec,
    *,
    backend: str = "scipy_exact",
    emit_udf: bool = False,
    emit_scalar_fields: list[str] | None = None,
) -> Field3D:
    ...
```

### エラー条件
- `InvalidGridError`
- `UnknownMaterialError`
- `UnsupportedBackendError`
- `ShapeMismatchError`

---

## 3.2 `build_distance_views`
```python
def build_distance_views(field: Field3D, spec: ViewSpec) -> DistanceViews:
    ...
```

### エラー条件
- `InvalidMuError`
- `FieldValidationError`

---

## 3.3 `observe_topdown_exposed`
```python
def observe_topdown_exposed(
    field: Field3D,
    *,
    target_role: int | None = None,
    view_axis: str = "z-",
    signed_mode: bool = True,
) -> Obs2D:
    ...
```

### エラー条件
- `UnknownRoleError`
- `UnsupportedAxisError`

---

## 3.4 `observe_slice`
```python
def observe_slice(
    field: Field3D,
    *,
    axis: str,
    position_nm: float | None = None,
    slab_thickness_nm: float = 0.0,
    target_role: int | None = None,
    signed_mode: bool = True,
) -> Obs2D:
    ...
```

### エラー条件
- `UnsupportedAxisError`
- `InvalidSlicePositionError`
- `UnknownRoleError`

---

## 3.5 `obs2d_from_polyline`
```python
def obs2d_from_polyline(
    polyline_xy_nm: np.ndarray,
    *,
    grid_shape_yx: tuple[int, int],
    spacing_nm_yx: tuple[float, float],
    origin_nm_yx: tuple[float, float],
    mode: str = "unsigned_curve",
) -> Obs2D:
    ...
```

### エラー条件
- `InvalidContourError`
- `InvalidGridError`
- `UnsupportedSemanticsError`

---

## 3.6 `extract_profiles`
```python
def extract_profiles(obs: Obs2D, *, spec: ProfileSpec) -> ProfileBundle:
    ...
```

### エラー条件
- `InsufficientContourSupportError`
- `UnsupportedProfileFunctionError`
- `InvalidObservationError`

---

## 3.7 `extract_corners`
```python
def extract_corners(obs: Obs2D, *, spec: CornerSpec) -> CornerBundle:
    ...
```

### エラー条件
- `InsufficientContourSupportError`
- `InvalidObservationError`

---

## 3.8 `field_loss`, `curve_loss`, `profile_loss`, `corner_loss`
それぞれ `MetricComponent` または `dict[str, MetricComponent]` を返します。

### 共通エラー条件
- `DistanceSemanticsMismatchError`
- `ShapeMismatchError`
- `InsufficientSupportError`

---

## 4. semantics 契約

## 4.1 signed / unsigned
- `Field3D.sdf_nm`: signed only
- `Field3D.udf_nm`: unsigned only
- `Obs2D.distance2d_nm`: signed or unsigned
- metric は signed/unsigned 混在比較を許さない

## 4.2 units
- 距離: nm
- 角度: degree
- 曲率: 1/nm
- 無次元化 loss: `unit="normalized"`

## 4.3 role order
`Field3D.sdf_nm[r,...]` の role 順序は、`RoleSpec.role_id_to_name` と一致している必要があります。  
artifact へも role order を保存します。

---

## 5. artifact 契約

## 5.1 必須ファイル
- `spec.yaml`
- `effective_spec.yaml`
- `manifest.json`

## 5.2 `Field3D` 保存
- `.npz` で保存
- key:
  - `sdf_nm`
  - optional `udf_nm`
  - optional scalar fields

## 5.3 `Obs2D` 保存
- `.npz` または `.json + .npy`
- 必須 key:
  - `distance2d_nm`
  - metadata

## 5.4 `MetricBundle` 保存
- `metric_bundle.json`
- component CSV は optional だが推奨

---

## 6. backward compatibility 契約

### 6.1 旧 API の扱い
- `to_tsdf`, `from_tsdf`, `label_from_tsdf` は維持
- 旧 observer / metric entry points は deprecation しつつ adapter を噛ませる

### 6.2 壊してよいもの
- silent ignore の挙動
- 未実装 option の no-op 受理
- artifact に semantics が無い曖昧 format

---

## 7. warning / fail-fast 契約

## 7.1 warning でよいもの
- profile 有効深さが少ない
- corner confidence が低い
- optional export を省略した

## 7.2 fail-fast すべきもの
- signed/unsigned mismatch
- shape mismatch
- role 不整合
- backend 非対応
- contour 空
- spacing 非正

---

## 8. versioning 契約

- `artifact_version`
- `spec_version`
- `api_version`

を区別して保存することを推奨します。

### 理由
artifact schema の変化と public API の変化は、必ずしも同じではないためです。

---

## 9. 本章の結論

この章で定義した shape / semantics / error 条件は、  
実装そのもの以上に重要です。

なぜなら、geometry 系の基盤では  
**「計算が動くこと」より「同じ意味で動くこと」** が長期的に重要だからです。

この契約を先に固定しておけば、

- PR review がしやすい
- artifact の互換性を維持しやすい
- downstream 連携が安定する
- 第三者にも説明しやすい

という大きな利点があります。
