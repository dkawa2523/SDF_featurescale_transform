# 17. AGENTS.md and repo instruction strategy

本章では、同梱した `codex_assets/AGENTS.md` を **なぜ置くのか / どう使うのか / どこをカスタマイズしてよいか** を説明します。

---

## 1. AGENTS.md を置く理由

Issue prompt だけだと、毎回同じ guardrail を繰り返し書く必要があります。  
この repo では、繰り返し守るべき原則が多いです。

- canonical = raw SDF
- TSDF = view
- process-specific branch を core に入れない
- signed / unsigned semantics 明示
- fail-fast validation
- backward compatibility は shim で守る
- docs / artifact / schema を一緒に更新する

これらを毎 prompt に長く書くと、task 固有の要求が薄れます。  
そのため、常駐ルールは `AGENTS.md` に寄せています。

---

## 2. 同梱 AGENTS.md の中身

### 2.1 最重要原則
repo 全体で守る invariant を短く列挙しています。

### 2.2 実装前に読む docs
Codex が最初に参照すべき docs 名を固定しています。

### 2.3 ワークフロー
実装時に

1. 読む
2. plan を出す
3. 実装
4. tests
5. docs / artifact 更新
6. 残リスク整理

という順を強制しています。

### 2.4 禁止事項
process-specific API や nonrigid alignment など、  
この基盤に入れたくないものを明示しています。

---

## 3. どこをカスタマイズしてよいか

### カスタマイズしてよい
- repo 内の実ファイルパス
- test command
- formatter / linter
- CI / artifact 出力パス
- branch naming rules

### なるべく維持したい
- canonical raw SDF 原則
- fail-fast 原則
- generic geometry function 原則
- signed / unsigned semantics 明示
- artifact / schema 同期

---

## 4. 既存 AGENTS.md がある場合

既存 repo root に `AGENTS.md` がある場合は、丸ごと上書きではなく、次の順で統合してください。

1. 既存の repo 固有ルールを残す
2. v4 の architecture guardrail を追加する
3. OpenAI docs MCP 1 行を追加する
4. test / docs / artifact 更新ルールを追記する

---

## 5. この repo で AGENTS.md に残す価値が高い情報

- repo の拡張目的
- core abstraction 数を増やしすぎない方針
- Field3D / Obs2D / MetricBundle / DatasetPackageV2 の役割
- process-specific branch を避ける理由
- tests / synthetic goldens / docs / artifact まで更新するルール
- reviewer 観点

---

## 6. AGENTS.md と Issue prompt の関係

```mermaid
flowchart LR
    A[AGENTS.md
常駐 guardrail] --> C[Codex]
    B[Issue prompt
task-specific scope] --> C[Codex]
    D[docs bundle
background design] --> C[Codex]
```

- `AGENTS.md`: 常に効く
- Issue prompt: 今回だけの task 条件
- docs bundle: 背景知識

この 3 層で運用するのが最も安定します。

---

## 7. まとめ

この repo のように、設計原則が多く、かつ process-specific 分岐を避けたい基盤では、  
`AGENTS.md` は単なる style guide ではなく **architecture guardrail** として機能します。
